
import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

// Rate limiting map - in production use Redis or similar
const rateLimitMap = new Map<string, { count: number; lastReset: number }>();
const RATE_LIMIT_WINDOW = 60000; // 1 minute
const RATE_LIMIT_MAX_REQUESTS = 10; // Max 10 requests per minute per user

function checkRateLimit(userId: string): boolean {
  const now = Date.now();
  const userLimit = rateLimitMap.get(userId);
  
  if (!userLimit || now - userLimit.lastReset > RATE_LIMIT_WINDOW) {
    rateLimitMap.set(userId, { count: 1, lastReset: now });
    return true;
  }
  
  if (userLimit.count >= RATE_LIMIT_MAX_REQUESTS) {
    return false;
  }
  
  userLimit.count++;
  return true;
}

function validateWebhookUrl(url: string): boolean {
  try {
    const urlObj = new URL(url);
    
    // Only allow HTTP/HTTPS
    if (!['http:', 'https:'].includes(urlObj.protocol)) {
      return false;
    }
    
    // Block private IP ranges for security
    const hostname = urlObj.hostname;
    if (hostname === 'localhost' || 
        hostname === '127.0.0.1' || 
        hostname.startsWith('192.168.') ||
        hostname.startsWith('10.') ||
        hostname.match(/^172\.(1[6-9]|2\d|3[01])\./)) {
      // Allow localhost only in development
      const isDev = Deno.env.get('ENVIRONMENT') === 'development';
      return isDev;
    }
    
    return true;
  } catch {
    return false;
  }
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    // Get authorization header
    const authorization = req.headers.get('Authorization')
    if (!authorization) {
      return new Response(JSON.stringify({ error: 'Authorization header required' }), {
        status: 401,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      })
    }

    // Verify user session
    const { data: { user }, error: authError } = await supabase.auth.getUser(
      authorization.replace('Bearer ', '')
    )

    if (authError || !user) {
      return new Response(JSON.stringify({ error: 'Unauthorized' }), {
        status: 401,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      })
    }

    // Apply rate limiting
    if (!checkRateLimit(user.id)) {
      console.warn(`Rate limit exceeded for user: ${user.id}`)
      return new Response(JSON.stringify({ error: 'Rate limit exceeded' }), {
        status: 429,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      })
    }

    // Fetch user configurations with proper user isolation
    const { data: configuracoes, error: configError } = await supabase
      .from('configuracoes')
      .select('webhook_verificacao_instancia, webhook_verificacao_instancia_habilitado')
      .eq('user_id', user.id)
      .maybeSingle()

    if (configError) {
      console.error('Error fetching configurations:', configError)
      return new Response(JSON.stringify({ error: 'Error fetching configurations' }), {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      })
    }

    // If no configurations found
    if (!configuracoes) {
      return new Response(JSON.stringify({ error: 'Configurations not found' }), {
        status: 404,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      })
    }

    // Check if webhook is enabled
    if (!configuracoes.webhook_verificacao_instancia_habilitado || !configuracoes.webhook_verificacao_instancia) {
      return new Response(JSON.stringify({ message: 'Webhook disabled or not configured' }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      })
    }

    // Validate webhook URL for security
    if (!validateWebhookUrl(configuracoes.webhook_verificacao_instancia)) {
      console.warn(`Invalid webhook URL for user ${user.id}: ${configuracoes.webhook_verificacao_instancia}`)
      return new Response(JSON.stringify({ error: 'Invalid webhook URL' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      })
    }

    // Prepare webhook data
    const webhookData = {
      timestamp: new Date().toISOString(),
      action: 'verify_instances',
      user_id: user.id
    }

    // Send POST to webhook with timeout and security headers
    try {
      const response = await fetch(configuracoes.webhook_verificacao_instancia, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'User-Agent': 'Supabase-Webhook/1.0',
          'X-Webhook-Source': 'instance-verification'
        },
        body: JSON.stringify(webhookData),
        signal: AbortSignal.timeout(15000) // 15 second timeout
      })

      if (!response.ok) {
        console.error(`Webhook error for user ${user.id}:`, response.status, response.statusText)
        return new Response(JSON.stringify({ 
          error: 'Webhook request failed',
          status: response.status 
        }), {
          status: 502,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        })
      }

      console.log(`Instance verification webhook sent successfully for user: ${user.id}`)

      return new Response(JSON.stringify({ 
        success: true, 
        message: 'Webhook sent successfully',
        timestamp: webhookData.timestamp 
      }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      })

    } catch (fetchError: any) {
      console.error(`Webhook fetch error for user ${user.id}:`, fetchError)
      
      let errorMessage = 'Webhook request failed';
      if (fetchError.name === 'AbortError') {
        errorMessage = 'Webhook request timeout';
      } else if (fetchError.name === 'TypeError') {
        errorMessage = 'Network error';
      }

      return new Response(JSON.stringify({ 
        error: errorMessage,
        details: fetchError.message 
      }), {
        status: 502,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      })
    }

  } catch (error: any) {
    console.error('Function error:', error)
    return new Response(JSON.stringify({ 
      error: 'Internal server error',
      timestamp: new Date().toISOString()
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    })
  }
})
