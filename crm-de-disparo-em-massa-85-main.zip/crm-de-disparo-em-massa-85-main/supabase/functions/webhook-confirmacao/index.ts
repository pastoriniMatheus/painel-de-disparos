
import { serve } from "https://deno.land/std@0.190.0/http/server.ts"
import { createClient } from "https://esm.sh/@supabase/supabase-js@2"

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders })
  }

  try {
    console.log('=== WEBHOOK CONFIRMAÇÃO INICIADO ===')
    console.log('Método:', req.method)
    console.log('URL:', req.url)
    console.log('Headers:', Object.fromEntries(req.headers.entries()))

    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    if (req.method !== 'POST') {
      console.log('Método não permitido:', req.method)
      return new Response(
        JSON.stringify({ error: 'Método não permitido' }), 
        { 
          status: 405, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      )
    }

    const body = await req.json()
    console.log('=== BODY RECEBIDO ===')
    console.log('Body completo:', JSON.stringify(body, null, 2))

    // Verificar se é confirmação de disparo completo ou lead individual
    if (body.disparo_id && !body.lead_id) {
      console.log('=== PROCESSANDO CONCLUSÃO DE DISPARO ===')
      console.log('Disparo ID:', body.disparo_id)
      
      // Webhook de conclusão de disparo completo
      const { data, error } = await supabase.rpc('process_disparo_completion', {
        disparo_uuid: body.disparo_id
      })

      console.log('Resultado da função process_disparo_completion:')
      console.log('Data:', data)
      console.log('Error:', error)

      if (error) {
        console.error('=== ERRO AO PROCESSAR CONCLUSÃO DO DISPARO ===')
        console.error('Erro completo:', error)
        return new Response(
          JSON.stringify({ 
            error: 'Erro interno do servidor',
            details: error.message 
          }), 
          { 
            status: 500, 
            headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
          }
        )
      }

      console.log('=== CONCLUSÃO DE DISPARO PROCESSADA COM SUCESSO ===')
      console.log('Resultado:', data)

      return new Response(
        JSON.stringify({ 
          success: true, 
          message: 'Conclusão de disparo processada com sucesso',
          data 
        }), 
        { 
          status: 200, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      )
    }

    // Webhook de confirmação de lead individual
    console.log('=== PROCESSANDO CONFIRMAÇÃO DE LEAD INDIVIDUAL ===')
    const { lead_id, status, error_details } = body

    if (!lead_id || !status) {
      console.log('Dados incompletos - lead_id:', lead_id, 'status:', status)
      return new Response(
        JSON.stringify({ error: 'lead_id e status são obrigatórios' }), 
        { 
          status: 400, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      )
    }

    // Validar status
    if (!['enviado', 'erro'].includes(status)) {
      console.log('Status inválido:', status)
      return new Response(
        JSON.stringify({ error: 'Status deve ser "enviado" ou "erro"' }), 
        { 
          status: 400, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      )
    }

    console.log('Processando confirmação de lead:', { lead_id, status, error_details })

    // Chamar a função do banco para processar a confirmação do lead
    const { data, error } = await supabase.rpc('process_webhook_confirmation', {
      lead_uuid: lead_id,
      new_status: status,
      error_details: error_details || null
    })

    console.log('Resultado da função process_webhook_confirmation:')
    console.log('Data:', data)
    console.log('Error:', error)

    if (error) {
      console.error('=== ERRO AO PROCESSAR CONFIRMAÇÃO DE LEAD ===')
      console.error('Erro completo:', error)
      return new Response(
        JSON.stringify({ 
          error: 'Erro interno do servidor',
          details: error.message 
        }), 
        { 
          status: 500, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      )
    }

    console.log('=== CONFIRMAÇÃO DE LEAD PROCESSADA COM SUCESSO ===')
    console.log('Resultado:', data)

    return new Response(
      JSON.stringify({ 
        success: true, 
        message: 'Confirmação de lead processada com sucesso',
        data 
      }), 
      { 
        status: 200, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    )

  } catch (error) {
    console.error('=== ERRO GERAL NO WEBHOOK ===')
    console.error('Erro:', error)
    console.error('Stack:', error.stack)
    return new Response(
      JSON.stringify({ 
        error: 'Erro interno do servidor',
        details: error.message 
      }), 
      { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    )
  }
})
