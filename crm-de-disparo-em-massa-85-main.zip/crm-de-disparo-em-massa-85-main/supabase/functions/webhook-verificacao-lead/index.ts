
import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.7.1'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders })
  }

  try {
    console.log('=== WEBHOOK VERIFICAÇÃO LEAD INICIADO ===');
    console.log('Método:', req.method);
    console.log('URL:', req.url);

    const body = await req.json();
    console.log('=== BODY RECEBIDO ===');
    console.log('Body completo:', JSON.stringify(body, null, 2));

    const { lead_id, status, error_details = '' } = body;

    console.log('Processando verificação de lead:', {
      lead_id,
      status,
      error_details
    });

    // Criar cliente Supabase com service role
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Buscar o lead
    const { data: lead, error: fetchError } = await supabase
      .from('leads')
      .select('id, verificado, user_id')
      .eq('id', lead_id)
      .single();

    if (fetchError || !lead) {
      console.error('Lead não encontrado:', fetchError);
      return new Response(
        JSON.stringify({ error: 'Lead não encontrado' }),
        { 
          status: 404, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        }
      );
    }

    console.log('Lead encontrado:', {
      id: lead.id,
      verificado: lead.verificado,
      user_id: lead.user_id
    });

    let updateData: any = {
      updated_at: new Date().toISOString()
    };

    // Processar baseado no status - IMPORTANTE: não marcar como enviado durante verificação
    if (status === 'verificado') {
      updateData.verificado = true;
      updateData.erro = null;
      // NÃO definir enviado = true aqui, pois isso é apenas verificação
    } else if (status === 'erro') {
      updateData.verificado = false;
      updateData.erro = error_details || 'Erro na verificação';
      
      // Se for WhatsApp inexistente, mover para lixeira
      if (error_details && error_details.includes('WhatsApp inexistente')) {
        updateData.deleted_at = new Date().toISOString();
        updateData.delete_reason = 'WhatsApp inexistente - Verificação automática';
      }
    }

    // Atualizar o lead
    const { error: updateError } = await supabase
      .from('leads')
      .update(updateData)
      .eq('id', lead_id);

    if (updateError) {
      console.error('Erro ao atualizar lead:', updateError);
      return new Response(
        JSON.stringify({ error: 'Erro ao atualizar lead' }),
        { 
          status: 500, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        }
      );
    }

    console.log('Lead atualizado:', {
      lead_id,
      verificado: updateData.verificado,
      status: status === 'verificado' ? 'verificado' : 'erro'
    });

    console.log('=== VERIFICAÇÃO PROCESSADA COM SUCESSO ===');

    return new Response(
      JSON.stringify({ 
        success: true, 
        message: 'Lead processado com sucesso',
        lead_id,
        status: updateData.verificado ? 'verificado' : 'erro'
      }),
      { 
        status: 200, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    );

  } catch (error) {
    console.error('Erro no webhook:', error);
    return new Response(
      JSON.stringify({ error: 'Erro interno do servidor' }),
      { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    );
  }
});
