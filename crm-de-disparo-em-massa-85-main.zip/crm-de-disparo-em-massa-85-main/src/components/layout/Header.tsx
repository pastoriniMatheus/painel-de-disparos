
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/useAuth";
import { useUserProfile } from "@/hooks/useUserProfile";
import { useAppearanceSettings } from "@/hooks/useAppearanceSettings";
import { LogOut, User, Shield } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const Header = () => {
  const { user, signOut } = useAuth();
  const { profile } = useUserProfile();
  const { settings } = useAppearanceSettings();
  const { toast } = useToast();

  const handleSignOut = async () => {
    try {
      console.log('Iniciando logout...');
      await signOut();
      console.log('Logout realizado com sucesso');
      toast({
        title: "Logout realizado",
        description: "Você foi desconectado com sucesso."
      });
    } catch (error) {
      console.error('Erro no logout:', error);
      toast({
        title: "Erro no logout",
        description: "Ocorreu um erro ao tentar fazer logout. Tente novamente.",
        variant: "destructive"
      });
    }
  };

  return (
    <header className="bg-white border-b border-gray-200 px-4 py-3">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <div className="flex items-center">
          {settings?.logo_url ? (
            <img 
              src={settings.logo_url} 
              alt="Logo"
              className="h-10 w-auto"
              onError={(e) => {
                // Fallback para texto se a imagem não carregar
                const target = e.target as HTMLImageElement;
                target.style.display = 'none';
                const fallback = target.parentElement?.querySelector('.fallback-title');
                if (fallback) {
                  (fallback as HTMLElement).style.display = 'block';
                }
              }}
            />
          ) : null}
          <h1 
            className={`text-xl font-semibold ${settings?.logo_url ? 'fallback-title hidden' : ''}`}
            style={{ color: settings?.secondary_color || '#004a99' }}
          >
            Sistema de Gerenciamento de Leads
          </h1>
        </div>
        
        {user && (
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 text-sm text-gray-600">
              {profile?.role === 'admin' ? (
                <Shield className="h-4 w-4" style={{ color: settings?.primary_color || '#00cc68' }} />
              ) : (
                <User className="h-4 w-4" />
              )}
              <span>{user.email}</span>
              {profile?.role === 'admin' && (
                <span 
                  className="font-medium"
                  style={{ color: settings?.primary_color || '#00cc68' }}
                >
                  (Admin)
                </span>
              )}
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={handleSignOut}
              className="flex items-center gap-2 hover:bg-gray-50"
              style={{ 
                borderColor: settings?.secondary_color || '#004a99',
                color: settings?.secondary_color || '#004a99'
              }}
            >
              <LogOut className="h-4 w-4" />
              Sair
            </Button>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;
