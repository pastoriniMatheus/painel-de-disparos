
import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Pagination, PaginationContent, PaginationItem, PaginationLink, PaginationNext, PaginationPrevious } from "@/components/ui/pagination";
import { Trash2, Eye, Search, CheckCircle, XCircle, Clock, Send, RotateCcw, TrashIcon } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import SendMessageDialog from "./SendMessageDialog";
import VerificationStatusDialog from "./VerificationStatusDialog";

const LEADS_PER_PAGE = 50;

const LeadsTab = () => {
  const [selectedLeads, setSelectedLeads] = useState<string[]>([]);
  const [filtroNome, setFiltroNome] = useState("");
  const [filtroCidade, setFiltroCidade] = useState("todas");
  const [filtroCategoria, setFiltroCategoria] = useState("todas");
  const [filtroStatus, setFiltroStatus] = useState("todos");
  const [showSendDialog, setShowSendDialog] = useState(false);
  const [showVerificationDialog, setShowVerificationDialog] = useState(false);
  const [verificationResults, setVerificationResults] = useState<{
    verificados: any[];
    invalidos: any[];
    isLoading: boolean;
  }>({
    verificados: [],
    invalidos: [],
    isLoading: false
  });
  const [currentPage, setCurrentPage] = useState(1);
  const [viewMode, setViewMode] = useState<'active' | 'trash'>('active');
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { user } = useAuth();

  // Query principal que busca leads ativos ou da lixeira
  const { data: allLeads = [], isLoading } = useQuery({
    queryKey: ['leads', filtroNome, filtroCidade, filtroCategoria, filtroStatus, viewMode, user?.id],
    queryFn: async () => {
      if (!user?.id) {
        console.log('No user ID available');
        return [];
      }

      let query = supabase.from('leads').select('*').eq('user_id', user.id);
      
      // Filtrar por modo de visualização (ativos ou lixeira)
      if (viewMode === 'active') {
        query = query.is('deleted_at', null);
      } else {
        query = query.not('deleted_at', 'is', null);
      }
      
      // Aplicar filtros apenas quando selecionados explicitamente
      if (filtroNome && filtroNome.trim()) {
        query = query.ilike('nome', `%${filtroNome}%`);
      }
      
      if (filtroCidade && filtroCidade !== "todas") {
        query = query.eq('cidade', filtroCidade);
      }
      
      if (filtroCategoria && filtroCategoria !== "todas") {
        query = query.eq('categoria', filtroCategoria);
      }
      
      // Aplicar filtro de status apenas quando explicitamente selecionado
      if (viewMode === 'active') {
        if (filtroStatus === "enviados") {
          query = query.eq('enviado', true);
        } else if (filtroStatus === "pendentes") {
          query = query.eq('enviado', false).is('erro', null);
        } else if (filtroStatus === "com-erro") {
          query = query.not('erro', 'is', null);
        }
      }
      
      const { data, error } = await query.order('created_at', { ascending: false });
      
      if (error) {
        console.error('Error fetching leads:', error);
        throw error;
      }
      
      console.log('Leads encontrados:', data?.length || 0);
      return data || [];
    },
    enabled: !!user?.id
  });

  // Calcular paginação
  const totalPages = Math.ceil(allLeads.length / LEADS_PER_PAGE);
  const startIndex = (currentPage - 1) * LEADS_PER_PAGE;
  const endIndex = startIndex + LEADS_PER_PAGE;
  const leads = allLeads.slice(startIndex, endIndex);

  // Reset página quando filtros mudarem
  const resetPagination = () => {
    setCurrentPage(1);
    setSelectedLeads([]);
  };

  // Watch for filter changes and reset pagination
  useState(() => {
    resetPagination();
  });

  const { data: configuracoes } = useQuery({
    queryKey: ['configuracoes', user?.id],
    queryFn: async () => {
      if (!user?.id) return null;
      
      const { data, error } = await supabase
        .from('configuracoes')
        .select('*')
        .eq('user_id', user.id)
        .single();
      
      if (error && error.code !== 'PGRST116') {
        console.error('Error fetching configuracoes:', error);
        throw error;
      }
      return data;
    },
    enabled: !!user?.id
  });

  // Query para buscar instâncias conectadas
  const { data: instanciasConectadas = [] } = useQuery({
    queryKey: ['instancias-conectadas', user?.id],
    queryFn: async () => {
      if (!user?.id) return [];
      
      const { data, error } = await supabase
        .from('instancias_whatsapp')
        .select('*')
        .eq('user_id', user.id)
        .eq('status', 'conectado');
      
      if (error) {
        console.error('Error fetching connected instances:', error);
        return [];
      }
      
      return data || [];
    },
    enabled: !!user?.id
  });

  const deleteMutation = useMutation({
    mutationFn: async (ids: string[]) => {
      if (!user?.id) throw new Error('User not authenticated');
      
      if (viewMode === 'active') {
        // Mover para lixeira
        const { error } = await supabase
          .from('leads')
          .update({ 
            deleted_at: new Date().toISOString(),
            delete_reason: 'Manual deletion'
          })
          .in('id', ids)
          .eq('user_id', user.id);
        
        if (error) throw error;
      } else {
        // Exclusão permanente
        const { error } = await supabase
          .from('leads')
          .delete()
          .in('id', ids)
          .eq('user_id', user.id);
        
        if (error) throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['leads'] });
      setSelectedLeads([]);
      toast({
        title: "Sucesso",
        description: viewMode === 'active' 
          ? "Leads movidos para lixeira com sucesso!" 
          : "Leads excluídos permanentemente!"
      });
    },
    onError: (error: any) => {
      console.error('Error deleting leads:', error);
      toast({
        title: "Erro",
        description: "Erro ao excluir leads",
        variant: "destructive"
      });
    }
  });

  const restoreMutation = useMutation({
    mutationFn: async (ids: string[]) => {
      if (!user?.id) throw new Error('User not authenticated');
      
      const { error } = await supabase
        .from('leads')
        .update({ 
          deleted_at: null,
          delete_reason: null
        })
        .in('id', ids)
        .eq('user_id', user.id);
      
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['leads'] });
      setSelectedLeads([]);
      toast({
        title: "Sucesso",
        description: "Leads restaurados com sucesso!"
      });
    },
    onError: (error: any) => {
      console.error('Error restoring leads:', error);
      toast({
        title: "Erro",
        description: "Erro ao restaurar leads",
        variant: "destructive"
      });
    }
  });

  const verificarContatosMutation = useMutation({
    mutationFn: async (leadsIds: string[]) => {
      if (!configuracoes?.webhook_verificacao) {
        throw new Error("URL de verificação não configurada");
      }

      if (instanciasConectadas.length === 0) {
        throw new Error("Nenhuma instância do WhatsApp conectada");
      }

      const leadsParaVerificar = allLeads.filter(lead => leadsIds.includes(lead.id));
      
      console.log('Enviando leads para verificação:', leadsParaVerificar.length);
      
      // Sanitize webhook URL
      const webhookUrl = configuracoes.webhook_verificacao.trim();
      if (!webhookUrl.startsWith('https://')) {
        throw new Error("URL de webhook deve usar HTTPS");
      }

      // Mostrar tela de carregamento
      setVerificationResults({
        verificados: [],
        invalidos: [],
        isLoading: true
      });
      setShowVerificationDialog(true);

      try {
        const response = await fetch(webhookUrl, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            data: leadsParaVerificar.map(lead => ({
              id: lead.id,
              nome: lead.nome?.trim() || '',
              telefone: lead.telefone?.trim() || ''
            })),
            instancias: instanciasConectadas.map(instancia => ({
              id: instancia.id,
              nome: instancia.nome,
              apikey: instancia.apikey
            }))
          })
        });

        if (!response.ok) {
          throw new Error(`Erro HTTP: ${response.status}`);
        }

        // A resposta será processada via webhook
        return { message: "Verificação iniciada" };
      } catch (error) {
        console.error('Webhook verification error:', error);
        throw new Error("Erro na verificação de contatos");
      }
    },
    onSuccess: () => {
      toast({
        title: "Verificação iniciada",
        description: "Aguardando resposta da verificação..."
      });
      setSelectedLeads([]);
    },
    onError: (error: any) => {
      setShowVerificationDialog(false);
      toast({
        title: "Erro",
        description: error.message || "Erro ao verificar contatos",
        variant: "destructive"
      });
    }
  });

  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      setSelectedLeads(leads.map(lead => lead.id));
    } else {
      setSelectedLeads([]);
    }
  };

  const handleSelectLead = (leadId: string, checked: boolean) => {
    if (checked) {
      setSelectedLeads([...selectedLeads, leadId]);
    } else {
      setSelectedLeads(selectedLeads.filter(id => id !== leadId));
    }
  };

  const getStatusIcon = (lead: any) => {
    if (lead.enviado) {
      return <CheckCircle className="h-4 w-4 text-green-600" />;
    }
    if (lead.erro) {
      return <XCircle className="h-4 w-4 text-red-600" />;
    }
    return <Clock className="h-4 w-4 text-gray-400" />;
  };

  const getStatusBadge = (lead: any) => {
    if (viewMode === 'trash') {
      return <Badge variant="outline">Lixeira</Badge>;
    }
    
    if (lead.enviado) {
      return <Badge variant="secondary" className="bg-green-100 text-green-800">Enviado</Badge>;
    }
    if (lead.erro) {
      return <Badge variant="destructive">{lead.erro}</Badge>;
    }
    return <Badge variant="outline">Pendente</Badge>;
  };

  // Listas para os filtros baseadas em TODOS os leads (sem filtros)
  const cidades = [...new Set(allLeads.map(lead => lead.cidade).filter(cidade => cidade && cidade.trim() !== ''))];
  const categorias = [...new Set(allLeads.map(lead => lead.categoria).filter(categoria => categoria && categoria.trim() !== ''))];

  if (!user) {
    return (
      <Card>
        <CardContent className="p-8 text-center">
          <p>Você precisa estar logado para visualizar os leads.</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          <CardTitle>
            {viewMode === 'active' ? 'Gerenciar Leads' : 'Lixeira de Leads'}
          </CardTitle>
          <div className="flex flex-wrap gap-2">
            <Button 
              onClick={() => setViewMode(viewMode === 'active' ? 'trash' : 'active')}
              variant="outline"
            >
              {viewMode === 'active' ? (
                <>
                  <TrashIcon className="h-4 w-4 mr-2" />
                  Ver Lixeira
                </>
              ) : (
                <>
                  <RotateCcw className="h-4 w-4 mr-2" />
                  Ver Ativos
                </>
              )}
            </Button>
            
            {viewMode === 'active' ? (
              <>
                <Button 
                  onClick={() => setShowSendDialog(true)}
                  disabled={allLeads.length === 0}
                  variant="default"
                >
                  <Send className="h-4 w-4 mr-2" />
                  Enviar Mensagem
                </Button>
                <Button 
                  onClick={() => verificarContatosMutation.mutate(selectedLeads)}
                  disabled={selectedLeads.length === 0 || verificarContatosMutation.isPending}
                  variant="outline"
                >
                  <Eye className="h-4 w-4 mr-2" />
                  {verificarContatosMutation.isPending ? 'Verificando...' : 'Verificar Contatos'}
                </Button>
                <Button 
                  onClick={() => deleteMutation.mutate(selectedLeads)}
                  disabled={selectedLeads.length === 0 || deleteMutation.isPending}
                  variant="destructive"
                >
                  <Trash2 className="h-4 w-4 mr-2" />
                  Mover para Lixeira
                </Button>
              </>
            ) : (
              <>
                <Button 
                  onClick={() => restoreMutation.mutate(selectedLeads)}
                  disabled={selectedLeads.length === 0 || restoreMutation.isPending}
                  variant="outline"
                >
                  <RotateCcw className="h-4 w-4 mr-2" />
                  Restaurar
                </Button>
                <Button 
                  onClick={() => deleteMutation.mutate(selectedLeads)}
                  disabled={selectedLeads.length === 0 || deleteMutation.isPending}
                  variant="destructive"
                >
                  <Trash2 className="h-4 w-4 mr-2" />
                  Excluir Permanentemente
                </Button>
              </>
            )}
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {viewMode === 'active' && (
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Buscar por nome..."
                value={filtroNome}
                onChange={(e) => {
                  setFiltroNome(e.target.value);
                  resetPagination();
                }}
                className="pl-10"
              />
            </div>
            <Select value={filtroCidade} onValueChange={(value) => {
              setFiltroCidade(value);
              resetPagination();
            }}>
              <SelectTrigger>
                <SelectValue placeholder="Filtrar por cidade" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="todas">Todas as cidades</SelectItem>
                {cidades.map(cidade => (
                  <SelectItem key={cidade} value={cidade}>{cidade}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={filtroCategoria} onValueChange={(value) => {
              setFiltroCategoria(value);
              resetPagination();
            }}>
              <SelectTrigger>
                <SelectValue placeholder="Filtrar por categoria" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="todas">Todas as categorias</SelectItem>
                {categorias.map(categoria => (
                  <SelectItem key={categoria} value={categoria}>{categoria}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={filtroStatus} onValueChange={(value) => {
              setFiltroStatus(value);
              resetPagination();
            }}>
              <SelectTrigger>
                <SelectValue placeholder="Filtrar por status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="todos">Todos os status</SelectItem>
                <SelectItem value="pendentes">Pendentes</SelectItem>
                <SelectItem value="enviados">Enviados</SelectItem>
                <SelectItem value="com-erro">Com Erro</SelectItem>
              </SelectContent>
            </Select>
          </div>
        )}

        {/* Informações de paginação */}
        <div className="flex justify-between items-center mb-4">
          <p className="text-sm text-gray-600">
            Exibindo {startIndex + 1}-{Math.min(endIndex, allLeads.length)} de {allLeads.length} leads
          </p>
          <p className="text-sm text-gray-600">
            Página {currentPage} de {totalPages}
          </p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b">
                <th className="text-left p-3">
                  <Checkbox
                    checked={selectedLeads.length === leads.length && leads.length > 0}
                    onCheckedChange={handleSelectAll}
                  />
                </th>
                <th className="text-left p-3">Status</th>
                <th className="text-left p-3">Nome</th>
                <th className="text-left p-3">Telefone</th>
                <th className="text-left p-3">Cidade</th>
                <th className="text-left p-3">Categoria</th>
                <th className="text-left p-3">Data/Hora</th>
                {viewMode === 'trash' && <th className="text-left p-3">Motivo</th>}
              </tr>
            </thead>
            <tbody>
              {isLoading ? (
                <tr>
                  <td colSpan={viewMode === 'trash' ? 8 : 7} className="text-center p-8">
                    Carregando leads...
                  </td>
                </tr>
              ) : leads.length === 0 ? (
                <tr>
                  <td colSpan={viewMode === 'trash' ? 8 : 7} className="text-center p-8">
                    {viewMode === 'active' ? 'Nenhum lead encontrado' : 'Lixeira vazia'}
                  </td>
                </tr>
              ) : (
                leads.map((lead) => (
                  <tr key={lead.id} className="border-b hover:bg-gray-50">
                    <td className="p-3">
                      <Checkbox
                        checked={selectedLeads.includes(lead.id)}
                        onCheckedChange={(checked) => handleSelectLead(lead.id, checked as boolean)}
                      />
                    </td>
                    <td className="p-3">
                      <div className="flex items-center gap-2">
                        {getStatusIcon(lead)}
                        {getStatusBadge(lead)}
                      </div>
                    </td>
                    <td className="p-3 font-medium">{lead.nome}</td>
                    <td className="p-3">{lead.telefone}</td>
                    <td className="p-3">{lead.cidade}, {lead.estado}</td>
                    <td className="p-3">{lead.categoria}</td>
                    <td className="p-3">{lead.data_hora}</td>
                    {viewMode === 'trash' && (
                      <td className="p-3 text-sm text-gray-500">{lead.delete_reason}</td>
                    )}
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Paginação */}
        {totalPages > 1 && (
          <div className="mt-6 flex justify-center">
            <Pagination>
              <PaginationContent>
                <PaginationItem>
                  <PaginationPrevious 
                    href="#"
                    onClick={(e) => {
                      e.preventDefault();
                      if (currentPage > 1) {
                        setCurrentPage(currentPage - 1);
                        setSelectedLeads([]);
                      }
                    }}
                    className={currentPage <= 1 ? "pointer-events-none opacity-50" : ""}
                  />
                </PaginationItem>
                
                {/* Mostrar páginas */}
                {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                  let pageNumber;
                  if (totalPages <= 5) {
                    pageNumber = i + 1;
                  } else if (currentPage <= 3) {
                    pageNumber = i + 1;
                  } else if (currentPage >= totalPages - 2) {
                    pageNumber = totalPages - 4 + i;
                  } else {
                    pageNumber = currentPage - 2 + i;
                  }
                  
                  return (
                    <PaginationItem key={pageNumber}>
                      <PaginationLink
                        href="#"
                        onClick={(e) => {
                          e.preventDefault();
                          setCurrentPage(pageNumber);
                          setSelectedLeads([]);
                        }}
                        isActive={currentPage === pageNumber}
                      >
                        {pageNumber}
                      </PaginationLink>
                    </PaginationItem>
                  );
                })}
                
                <PaginationItem>
                  <PaginationNext 
                    href="#"
                    onClick={(e) => {
                      e.preventDefault();
                      if (currentPage < totalPages) {
                        setCurrentPage(currentPage + 1);
                        setSelectedLeads([]);
                      }
                    }}
                    className={currentPage >= totalPages ? "pointer-events-none opacity-50" : ""}
                  />
                </PaginationItem>
              </PaginationContent>
            </Pagination>
          </div>
        )}
      </CardContent>

      <SendMessageDialog
        open={showSendDialog}
        onOpenChange={setShowSendDialog}
        leads={allLeads}
      />

      <VerificationStatusDialog
        open={showVerificationDialog}
        onOpenChange={setShowVerificationDialog}
        results={verificationResults}
        onResultsUpdate={setVerificationResults}
      />
    </Card>
  );
};

export default LeadsTab;
