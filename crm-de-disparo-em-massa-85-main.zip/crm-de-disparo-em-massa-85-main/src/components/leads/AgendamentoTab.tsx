
import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Calendar, Clock, Trash2, Edit } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import EditScheduledDispatchDialog from "./disparo/EditScheduledDispatchDialog";

const AgendamentoTab = () => {
  const [editingDispatch, setEditingDispatch] = useState<any>(null);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const { toast } = useToast();
  const { user } = useAuth();
  const queryClient = useQueryClient();

  const { data: agendamentos = [] } = useQuery({
    queryKey: ['agendamentos', user?.id],
    queryFn: async () => {
      if (!user?.id) throw new Error("Usuário não autenticado");
      
      const { data, error } = await supabase
        .from('disparos_agendados')
        .select('*')
        .eq('user_id', user.id)
        .order('data_agendada', { ascending: true });
      
      if (error) throw error;
      return data || [];
    },
    enabled: !!user?.id
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      if (!user?.id) throw new Error("Usuário não autenticado");
      
      const { error } = await supabase
        .from('disparos_agendados')
        .delete()
        .eq('id', id)
        .eq('user_id', user.id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['agendamentos'] });
      toast({
        title: "Sucesso",
        description: "Agendamento cancelado!"
      });
    },
    onError: (error: any) => {
      toast({
        title: "Erro",
        description: "Erro ao cancelar agendamento: " + error.message,
        variant: "destructive"
      });
    }
  });

  const editMutation = useMutation({
    mutationFn: async (updatedDispatch: any) => {
      if (!user?.id) throw new Error("Usuário não autenticado");
      
      const { error } = await supabase
        .from('disparos_agendados')
        .update({
          conteudo: updatedDispatch.conteudo,
          imagem_url: updatedDispatch.imagem_url,
          data_agendada: updatedDispatch.data_agendada
        })
        .eq('id', updatedDispatch.id)
        .eq('user_id', user.id);
      
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['agendamentos'] });
      toast({
        title: "Sucesso",
        description: "Agendamento atualizado!"
      });
    },
    onError: (error: any) => {
      toast({
        title: "Erro",
        description: "Erro ao atualizar agendamento: " + error.message,
        variant: "destructive"
      });
    }
  });

  const formatarDataAgendamento = (dataString: string) => {
    return new Date(dataString).toLocaleString('pt-BR');
  };

  const handleEdit = (agendamento: any) => {
    setEditingDispatch(agendamento);
    setIsEditDialogOpen(true);
  };

  const handleSaveEdit = (updatedDispatch: any) => {
    editMutation.mutate(updatedDispatch);
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="h-5 w-5" />
            Disparos Agendados
          </CardTitle>
        </CardHeader>
        <CardContent>
          {agendamentos.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              <Clock className="h-12 w-12 mx-auto mb-4 text-gray-300" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                Nenhum disparo agendado
              </h3>
              <p className="text-gray-500">
                Quando você agendar disparos, eles aparecerão aqui
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {agendamentos.map((agendamento) => (
                <div key={agendamento.id} className="border rounded-lg p-4">
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <Badge variant={agendamento.status === 'agendado' ? 'default' : 'secondary'}>
                        {agendamento.status}
                      </Badge>
                      <p className="text-sm text-gray-600 mt-1">
                        {formatarDataAgendamento(agendamento.data_agendada)}
                      </p>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleEdit(agendamento)}
                        disabled={editMutation.isPending}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button
                        size="sm"
                        variant="destructive"
                        onClick={() => deleteMutation.mutate(agendamento.id)}
                        disabled={deleteMutation.isPending}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                  
                  <p className="text-sm mb-2">
                    {agendamento.conteudo.length > 100 
                      ? agendamento.conteudo.substring(0, 100) + '...'
                      : agendamento.conteudo
                    }
                  </p>
                  
                  {agendamento.imagem_url && (
                    <div className="mt-2">
                      <img 
                        src={agendamento.imagem_url} 
                        alt="Imagem da mensagem" 
                        className="max-w-32 h-auto rounded border"
                        onError={(e) => {
                          e.currentTarget.style.display = 'none';
                        }}
                      />
                    </div>
                  )}
                  
                  <p className="text-xs text-gray-500 mt-2">
                    {(agendamento.leads_selecionados as any[]).length} contatos selecionados
                  </p>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <EditScheduledDispatchDialog
        open={isEditDialogOpen}
        onOpenChange={setIsEditDialogOpen}
        dispatch={editingDispatch}
        onSave={handleSaveEdit}
      />
    </div>
  );
};

export default AgendamentoTab;
