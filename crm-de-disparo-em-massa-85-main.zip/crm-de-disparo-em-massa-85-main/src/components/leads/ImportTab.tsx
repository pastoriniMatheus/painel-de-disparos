import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Progress } from "@/components/ui/progress";
import { Upload, Plus, FileText, AlertCircle } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { 
  sanitizeString, 
  sanitizePhone, 
  sanitizeUrl, 
  validatePhone, 
  validateUrl,
  sanitizeCsvData 
} from "@/utils/validation";
import { createSafeError } from "@/utils/errorHandling";

// Chunk size for batch processing - reduced for better stability
const BATCH_SIZE = 50;
const MAX_TOTAL_RECORDS = 2000;

const ImportTab = () => {
  const [formData, setFormData] = useState({
    nome: "",
    cidade: "",
    estado: "",
    categoria: "",
    telefone: "",
    url: "",
    campanha: ""
  });
  const [csvData, setCsvData] = useState("");
  const [validationErrors, setValidationErrors] = useState<Record<string, string>>({});
  const [importProgress, setImportProgress] = useState(0);
  const [isImporting, setIsImporting] = useState(false);
  const [isVerifying, setIsVerifying] = useState(false);
  const [importStats, setImportStats] = useState<{
    total: number;
    processed: number;
    errors: string[];
    duplicates: number;
    success: number;
  }>({ total: 0, processed: 0, errors: [], duplicates: 0, success: 0 });
  
  const { toast } = useToast();
  const { user } = useAuth();
  const queryClient = useQueryClient();

  const validateForm = (data: typeof formData): boolean => {
    const errors: Record<string, string> = {};

    if (!data.nome.trim()) {
      errors.nome = "Nome é obrigatório";
    }

    if (!data.telefone.trim()) {
      errors.telefone = "Telefone é obrigatório";
    } else if (!validatePhone(data.telefone)) {
      errors.telefone = "Formato de telefone inválido";
    }

    if (!data.cidade.trim()) {
      errors.cidade = "Cidade é obrigatória";
    }

    if (data.url && !validateUrl(data.url)) {
      errors.url = "URL inválida";
    }

    setValidationErrors(errors);
    return Object.keys(errors).length === 0;
  };

  // Buscar configuração do webhook
  const buscarConfiguracaoWebhook = async () => {
    if (!user?.id) return null;

    const { data: configuracao, error } = await supabase
      .from('configuracoes')
      .select('webhook_verificacao')
      .eq('user_id', user.id)
      .maybeSingle();

    if (error) {
      console.error('Erro ao buscar configuração webhook:', error);
      return null;
    }

    return configuracao;
  };

  // Buscar instâncias conectadas
  const buscarInstanciasConectadas = async () => {
    if (!user?.id) return [];

    const { data: instancias, error } = await supabase
      .from('instancias_whatsapp')
      .select('nome, apikey')
      .eq('user_id', user.id)
      .eq('status', 'conectado')
      .not('apikey', 'is', null);

    if (error) {
      console.error('Erro ao buscar instâncias conectadas:', error);
      return [];
    }

    return instancias || [];
  };

  // Verificar se o lead existe no banco com retry
  const verificarLeadNoBanco = async (leadId: string, maxTentativas: number = 5): Promise<boolean> => {
    for (let tentativa = 1; tentativa <= maxTentativas; tentativa++) {
      console.log(`Verificando lead no banco - Tentativa ${tentativa}/${maxTentativas}`);
      
      try {
        const { data: lead, error } = await supabase
          .from('leads')
          .select('id, verificado')
          .eq('id', leadId)
          .single();

        if (!error && lead) {
          console.log('Lead encontrado no banco:', lead);
          return true;
        }

        console.log(`Tentativa ${tentativa} - Lead não encontrado, aguardando...`);
        
        if (tentativa < maxTentativas) {
          await new Promise(resolve => setTimeout(resolve, 1000));
        }
      } catch (error) {
        console.error(`Erro na tentativa ${tentativa}:`, error);
        if (tentativa < maxTentativas) {
          await new Promise(resolve => setTimeout(resolve, 1000));
        }
      }
    }

    console.error('Lead não encontrado após todas as tentativas');
    return false;
  };

  // Aguardar verificação do lead com polling - versão corrigida
  const aguardarVerificacao = async (leadId: string): Promise<boolean> => {
    console.log('Iniciando aguardar verificação para lead:', leadId);
    
    return new Promise((resolve) => {
      let resolvido = false;
      let tentativasPolling = 0;
      const maxTentativas = 10;

      const resolverUmaVez = (resultado: boolean) => {
        if (!resolvido) {
          resolvido = true;
          console.log('Verificação resolvida:', resultado);
          resolve(resultado);
        }
      };

      const verificarPorPolling = async () => {
        if (resolvido) return;
        
        tentativasPolling++;
        console.log(`Verificação WhatsApp - Tentativa ${tentativasPolling}/${maxTentativas}`);
        
        try {
          const { data: lead, error } = await supabase
            .from('leads')
            .select('verificado, erro')
            .eq('id', leadId)
            .single();

          if (error) {
            console.error('Erro no polling:', error);
            if (tentativasPolling >= maxTentativas) {
              resolverUmaVez(false);
            }
            return;
          }

          console.log('Status atual do lead:', lead);

          if (lead.verificado !== null) {
            // Se verificado é false e há uma mensagem de erro, tratar especificamente
            if (lead.verificado === false && lead.erro) {
              console.log('Lead não verificado com erro:', lead.erro);
            }
            resolverUmaVez(lead.verificado === true);
            return;
          }

          if (tentativasPolling >= maxTentativas) {
            console.log('Timeout na verificação - processo demorou mais que 30 segundos');
            resolverUmaVez(false);
            return;
          }

          setTimeout(verificarPorPolling, 3000);
        } catch (error) {
          console.error('Erro inesperado no polling:', error);
          if (tentativasPolling >= maxTentativas) {
            resolverUmaVez(false);
          }
        }
      };

      const channel = supabase
        .channel(`lead-verification-${leadId}`)
        .on(
          'postgres_changes',
          {
            event: 'UPDATE',
            schema: 'public',
            table: 'leads',
            filter: `id=eq.${leadId}`
          },
          (payload) => {
            console.log('Real-time update recebido:', payload);
            const newData = payload.new as any;
            
            if (newData.verificado !== null && !resolvido) {
              supabase.removeChannel(channel);
              resolverUmaVez(newData.verificado === true);
            }
          }
        )
        .subscribe((status) => {
          console.log('Status do canal real-time:', status);
        });

      setTimeout(verificarPorPolling, 1000);

      setTimeout(() => {
        if (!resolvido) {
          console.log('Timeout geral - processo de verificação demorou mais que 35 segundos');
          supabase.removeChannel(channel);
          resolverUmaVez(false);
        }
      }, 35000);
    });
  };

  const checkForDuplicates = async (leads: any[]): Promise<{ duplicates: string[], unique: any[] }> => {
    if (!user?.id) return { duplicates: [], unique: leads };

    console.log(`Verificando duplicatas para ${leads.length} leads...`);
    
    const phones = leads.map(lead => lead.telefone);
    
    try {
      const { data: existingLeads, error } = await supabase
        .from('leads')
        .select('telefone')
        .eq('user_id', user.id)
        .in('telefone', phones);

      if (error) {
        console.error('Erro ao verificar duplicatas:', error);
        return { duplicates: [], unique: leads };
      }

      const existingPhones = new Set(existingLeads?.map(lead => lead.telefone) || []);
      const duplicates: string[] = [];
      const unique: any[] = [];

      leads.forEach(lead => {
        if (existingPhones.has(lead.telefone)) {
          duplicates.push(lead.telefone);
        } else {
          unique.push(lead);
        }
      });

      console.log(`Duplicatas: ${duplicates.length}, Únicos: ${unique.length}`);
      return { duplicates, unique };
    } catch (error) {
      console.error('Erro inesperado ao verificar duplicatas:', error);
      return { duplicates: [], unique: leads };
    }
  };

  const processBatch = async (batch: any[], batchIndex: number): Promise<{ success: number; errors: string[] }> => {
    console.log(`Processando lote ${batchIndex + 1} com ${batch.length} leads...`);
    
    try {
      const { error } = await supabase.from('leads').insert(batch);
      if (error) {
        console.error(`Erro no lote ${batchIndex + 1}:`, error);
        return { 
          success: 0, 
          errors: [`Lote ${batchIndex + 1}: ${error.message}`] 
        };
      }
      console.log(`Lote ${batchIndex + 1} processado com sucesso!`);
      return { success: batch.length, errors: [] };
    } catch (error: any) {
      console.error(`Erro inesperado no lote ${batchIndex + 1}:`, error);
      return { 
        success: 0, 
        errors: [`Lote ${batchIndex + 1}: Erro inesperado - ${error.message}`] 
      };
    }
  };

  const importCsvMutation = useMutation({
    mutationFn: async (csvText: string) => {
      if (!user?.id) throw new Error("Usuário não autenticado");

      setIsImporting(true);
      setImportProgress(0);
      setImportStats({ total: 0, processed: 0, errors: [], duplicates: 0, success: 0 });

      console.log("Iniciando importação CSV...");

      const sanitizedCsv = sanitizeCsvData(csvText);
      const lines = sanitizedCsv.trim().split('\n').filter(line => line.trim());
      
      if (lines.length < 2) {
        throw new Error("CSV deve conter pelo menos uma linha de cabeçalho e uma linha de dados");
      }

      if (lines.length > MAX_TOTAL_RECORDS + 1) {
        throw new Error(`Limite de ${MAX_TOTAL_RECORDS} registros excedido. Arquivo contém ${lines.length - 1} registros.`);
      }

      const headers = lines[0].split(',').map(h => h.trim().toLowerCase().replace(/"/g, ''));
      console.log("Cabeçalhos encontrados:", headers);
      
      const requiredFields = ['nome', 'telefone', 'cidade'];
      const missingFields = requiredFields.filter(field => !headers.includes(field));
      
      if (missingFields.length > 0) {
        throw new Error(`Campos obrigatórios ausentes: ${missingFields.join(', ')}`);
      }

      const validLeads = [];
      const allErrors: string[] = [];
      const totalLines = lines.length - 1;

      console.log(`Processando ${totalLines} linhas de dados...`);
      setImportStats(prev => ({ ...prev, total: totalLines }));

      for (let i = 1; i < lines.length; i++) {
        try {
          const values = lines[i].split(',').map(v => v.trim().replace(/"/g, ''));
          const lead: any = {};
          
          headers.forEach((header, index) => {
            lead[header] = values[index] || '';
          });

          const sanitizedLead = {
            nome: sanitizeString(lead.nome),
            telefone: sanitizePhone(lead.telefone),
            cidade: sanitizeString(lead.cidade),
            estado: sanitizeString(lead.estado || ''),
            categoria: sanitizeString(lead.categoria || 'Geral'),
            url: sanitizeUrl(lead.url || ''),
            campanha: sanitizeString(lead.campanha || ''),
            user_id: user.id
          };

          if (!sanitizedLead.nome || !sanitizedLead.telefone || !sanitizedLead.cidade) {
            allErrors.push(`Linha ${i + 1}: Campos obrigatórios ausentes (nome, telefone ou cidade)`);
            continue;
          }

          if (!validatePhone(sanitizedLead.telefone)) {
            allErrors.push(`Linha ${i + 1}: Telefone inválido "${sanitizedLead.telefone}"`);
            continue;
          }

          if (sanitizedLead.url && !validateUrl(sanitizedLead.url)) {
            allErrors.push(`Linha ${i + 1}: URL inválida "${sanitizedLead.url}"`);
            continue;
          }

          const baseDate = new Date();
          baseDate.setMilliseconds(baseDate.getMilliseconds() + validLeads.length);
          const dataHora = baseDate.toLocaleString('pt-BR', {
            day: '2-digit',
            month: '2-digit',
            year: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
          }).replace(',', '');

          validLeads.push({
            ...sanitizedLead,
            data_hora: dataHora
          });

        } catch (error: any) {
          allErrors.push(`Linha ${i + 1}: Erro de processamento - ${error.message}`);
        }
      }

      console.log(`Validação concluída: ${validLeads.length} leads válidos, ${allErrors.length} erros`);

      if (validLeads.length === 0) {
        throw new Error(`Nenhum lead válido encontrado para importar.\n\nErros encontrados:\n${allErrors.slice(0, 10).join('\n')}${allErrors.length > 10 ? `\n... e mais ${allErrors.length - 10} erros` : ''}`);
      }

      const { duplicates, unique: uniqueLeads } = await checkForDuplicates(validLeads);
      
      if (duplicates.length > 0) {
        allErrors.push(...duplicates.map(phone => `Telefone ${phone} já existe no banco de dados`));
      }

      if (uniqueLeads.length === 0) {
        throw new Error(`Todos os leads já existem no banco de dados.\n\nDuplicatas encontradas:\n${duplicates.slice(0, 10).join('\n')}${duplicates.length > 10 ? `\n... e mais ${duplicates.length - 10} telefones` : ''}`);
      }

      const batches = [];
      for (let i = 0; i < uniqueLeads.length; i += BATCH_SIZE) {
        batches.push(uniqueLeads.slice(i, i + BATCH_SIZE));
      }

      let totalProcessed = 0;
      let totalSuccess = 0;
      const batchErrors: string[] = [];

      console.log(`Iniciando importação de ${uniqueLeads.length} leads únicos em ${batches.length} lotes de ${BATCH_SIZE}`);

      for (let i = 0; i < batches.length; i++) {
        const batch = batches[i];
        
        try {
          const result = await processBatch(batch, i);
          totalSuccess += result.success;
          batchErrors.push(...result.errors);
          
          totalProcessed += batch.length;
          const progress = Math.round((totalProcessed / uniqueLeads.length) * 100);
          setImportProgress(progress);
          
          setImportStats(prev => ({
            ...prev,
            processed: totalProcessed,
            success: totalSuccess,
            errors: [...allErrors, ...batchErrors],
            duplicates: duplicates.length
          }));

          if (i < batches.length - 1) {
            await new Promise(resolve => setTimeout(resolve, 200));
          }

        } catch (error: any) {
          console.error(`Erro no lote ${i + 1}:`, error);
          batchErrors.push(`Lote ${i + 1}: ${error.message}`);
        }
      }

      const finalErrors = [...allErrors, ...batchErrors];
      
      console.log(`Importação concluída: ${totalSuccess} sucessos de ${uniqueLeads.length} tentativas`);

      if (totalSuccess === 0) {
        throw new Error(`Nenhum lead foi importado com sucesso.\n\nErros:\n${finalErrors.slice(0, 10).join('\n')}${finalErrors.length > 10 ? `\n... e mais ${finalErrors.length - 10} erros` : ''}`);
      }

      return {
        success: totalSuccess,
        total: validLeads.length,
        errors: finalErrors,
        skipped: allErrors.length,
        duplicates: duplicates.length
      };
    },
    onSuccess: (result) => {
      console.log("Importação finalizada com sucesso:", result);
      queryClient.invalidateQueries({ queryKey: ['leads'] });
      setCsvData("");
      setImportProgress(100);
      
      const { success, total, errors, skipped, duplicates } = result;
      
      let message = `${success} de ${total} leads importados com sucesso!`;
      if (duplicates > 0) {
        message += ` (${duplicates} duplicatas ignoradas)`;
      }
      if (skipped > 0) {
        message += ` (${skipped} registros foram ignorados devido a erros de validação)`;
      }
      
      toast({
        title: "Importação concluída",
        description: message
      });

      if (errors.length > 0) {
        console.warn("Erros durante a importação:", errors);
      }
    },
    onError: (error: any) => {
      console.error("Erro na importação:", error);
      const safeError = createSafeError(error);
      toast({
        title: "Erro na importação",
        description: safeError.message,
        variant: "destructive"
      });
    },
    onSettled: () => {
      setIsImporting(false);
      setTimeout(() => {
        setImportProgress(0);
        setImportStats({ total: 0, processed: 0, errors: [], duplicates: 0, success: 0 });
      }, 5000);
    }
  });

  const addLeadMutation = useMutation({
    mutationFn: async (leadData: any) => {
      if (!user?.id) throw new Error("Usuário não autenticado");

      setIsVerifying(true);

      const sanitizedData = {
        nome: sanitizeString(leadData.nome),
        cidade: sanitizeString(leadData.cidade),
        estado: sanitizeString(leadData.estado),
        categoria: sanitizeString(leadData.categoria || 'Geral'),
        telefone: sanitizePhone(leadData.telefone),
        url: sanitizeUrl(leadData.url),
        campanha: sanitizeString(leadData.campanha),
        user_id: user.id
      };

      const { data: existingLead } = await supabase
        .from('leads')
        .select('id')
        .eq('user_id', user.id)
        .eq('telefone', sanitizedData.telefone)
        .maybeSingle();

      if (existingLead) {
        throw new Error(`Lead com telefone ${sanitizedData.telefone} já existe`);
      }

      const dataHora = new Date().toLocaleString('pt-BR', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      }).replace(',', '');

      const leadToInsert = {
        ...sanitizedData,
        data_hora: dataHora,
        verificado: null as boolean | null
      };

      console.log('Inserindo lead no banco:', leadToInsert);

      const { data: newLead, error } = await supabase.from('leads').insert([leadToInsert]).select().single();
      
      if (error) {
        console.error('Erro ao inserir lead:', error);
        throw error;
      }

      console.log('Lead inserido com sucesso:', newLead);

      const leadExiste = await verificarLeadNoBanco(newLead.id);
      
      if (!leadExiste) {
        throw new Error('Lead não foi encontrado após inserção - possível problema de sincronização');
      }

      console.log('Lead confirmado no banco, prosseguindo com verificação');

      const configuracao = await buscarConfiguracaoWebhook();

      if (!configuracao?.webhook_verificacao) {
        const { error: updateError } = await supabase
          .from('leads')
          .update({ verificado: true })
          .eq('id', newLead.id);
        
        if (updateError) {
          console.error('Erro ao marcar lead como verificado:', updateError);
        }
        
        toast({
          title: "Aviso",
          description: "Webhook de verificação não configurado. Lead adicionado sem verificação.",
          variant: "destructive"
        });
        return newLead;
      }

      const instanciasConectadas = await buscarInstanciasConectadas();

      try {
        const webhookData = {
          lead_id: newLead.id,
          telefone: sanitizedData.telefone,
          timestamp: new Date().toISOString(),
          webhook_confirmacao: `https://brwapytjhitzurfnpfsz.supabase.co/functions/v1/webhook-verificacao-lead`,
          instancias_conectadas: instanciasConectadas
        };

        console.log('Enviando webhook de verificação:', webhookData);

        const response = await fetch(configuracao.webhook_verificacao, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(webhookData)
        });

        if (!response.ok) {
          throw new Error(`Webhook falhou: ${response.status} ${response.statusText}`);
        }

        console.log('Webhook enviado com sucesso, aguardando verificação...');

        const verificado = await aguardarVerificacao(newLead.id);

        if (!verificado) {
          // Buscar a mensagem de erro específica antes de deletar
          const { data: leadAtualizado } = await supabase
            .from('leads')
            .select('erro')
            .eq('id', newLead.id)
            .single();

          console.log('Lead não verificado, removendo do banco...');
          await supabase
            .from('leads')
            .delete()
            .eq('id', newLead.id);
          
          // Usar a mensagem de erro específica se disponível
          const errorMessage = leadAtualizado?.erro || "WhatsApp inexistente ou inválido! O número não será salvo.";
          throw new Error(errorMessage);
        }

        console.log('Lead verificado com sucesso!');
        return newLead;

      } catch (error) {
        console.error('Erro no processo de verificação:', error);
        console.log('Removendo lead devido a erro na verificação...');
        await supabase
          .from('leads')
          .delete()
          .eq('id', newLead.id);
        
        throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['leads'] });
      setFormData({
        nome: "",
        cidade: "",
        estado: "",
        categoria: "",
        telefone: "",
        url: "",
        campanha: ""
      });
      setValidationErrors({});
      toast({
        title: "Sucesso",
        description: "Lead adicionado e verificado com sucesso!"
      });
    },
    onError: (error: any) => {
      console.error('Erro detalhado:', error);
      toast({
        title: "Erro",
        description: error.message || "Erro inesperado ao adicionar lead",
        variant: "destructive"
      });
    },
    onSettled: () => {
      setIsVerifying(false);
    }
  });

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (validationErrors[field]) {
      setValidationErrors(prev => ({ ...prev, [field]: "" }));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm(formData)) {
      toast({
        title: "Erro de validação",
        description: "Por favor, corrija os erros no formulário",
        variant: "destructive"
      });
      return;
    }

    addLeadMutation.mutate(formData);
  };

  const handleFileImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 5 * 1024 * 1024) {
      toast({
        title: "Erro",
        description: "Arquivo muito grande. Limite de 5MB.",
        variant: "destructive"
      });
      return;
    }

    if (!file.name.toLowerCase().endsWith('.csv') && !file.name.toLowerCase().endsWith('.txt')) {
      toast({
        title: "Erro",
        description: "Apenas arquivos CSV e TXT são permitidos.",
        variant: "destructive"
      });
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      setCsvData(text);
    };
    reader.readAsText(file, 'UTF-8');
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Plus className="h-5 w-5" />
            Adicionar Lead Manualmente
          </CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="nome">Nome *</Label>
                <Input
                  id="nome"
                  value={formData.nome}
                  onChange={(e) => handleInputChange('nome', e.target.value)}
                  className={validationErrors.nome ? "border-red-500" : ""}
                  required
                  disabled={isVerifying}
                />
                {validationErrors.nome && (
                  <p className="text-sm text-red-500 mt-1">{validationErrors.nome}</p>
                )}
              </div>
              <div>
                <Label htmlFor="telefone">Telefone *</Label>
                <Input
                  id="telefone"
                  placeholder="(12) 9 87654321"
                  value={formData.telefone}
                  onChange={(e) => handleInputChange('telefone', e.target.value)}
                  className={validationErrors.telefone ? "border-red-500" : ""}
                  required
                  disabled={isVerifying}
                />
                {validationErrors.telefone && (
                  <p className="text-sm text-red-500 mt-1">{validationErrors.telefone}</p>
                )}
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="cidade">Cidade *</Label>
                <Input
                  id="cidade"
                  value={formData.cidade}
                  onChange={(e) => handleInputChange('cidade', e.target.value)}
                  className={validationErrors.cidade ? "border-red-500" : ""}
                  required
                  disabled={isVerifying}
                />
                {validationErrors.cidade && (
                  <p className="text-sm text-red-500 mt-1">{validationErrors.cidade}</p>
                )}
              </div>
              <div>
                <Label htmlFor="estado">Estado</Label>
                <Input
                  id="estado"
                  value={formData.estado}
                  onChange={(e) => handleInputChange('estado', e.target.value)}
                  disabled={isVerifying}
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="categoria">Categoria</Label>
                <Input
                  id="categoria"
                  value={formData.categoria}
                  onChange={(e) => handleInputChange('categoria', e.target.value)}
                  disabled={isVerifying}
                />
              </div>
              <div>
                <Label htmlFor="campanha">Campanha</Label>
                <Input
                  id="campanha"
                  value={formData.campanha}
                  onChange={(e) => handleInputChange('campanha', e.target.value)}
                  disabled={isVerifying}
                />
              </div>
            </div>

            <div>
              <Label htmlFor="url">URL</Label>
              <Input
                id="url"
                type="url"
                value={formData.url}
                onChange={(e) => handleInputChange('url', e.target.value)}
                className={validationErrors.url ? "border-red-500" : ""}
                disabled={isVerifying}
              />
              {validationErrors.url && (
                <p className="text-sm text-red-500 mt-1">{validationErrors.url}</p>
              )}
            </div>

            {isVerifying && (
              <div className="bg-blue-50 p-4 rounded-lg">
                <div className="flex items-center gap-2">
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-600"></div>
                  <span className="text-blue-800 font-medium">
                    Verificando WhatsApp...
                  </span>
                </div>
                <p className="text-sm text-blue-600 mt-1">
                  Verificando se o número é válido. Aguarde alguns segundos.
                </p>
              </div>
            )}

            <Button 
              type="submit" 
              className="w-full"
              disabled={addLeadMutation.isPending || isVerifying}
            >
              {isVerifying ? "Verificando WhatsApp..." : addLeadMutation.isPending ? "Adicionando..." : "Adicionar"}
            </Button>
          </form>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Upload className="h-5 w-5" />
            Importar Leads via CSV/TXT
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="file-upload">Selecionar arquivo CSV/TXT (máx. 5MB)</Label>
            <Input
              id="file-upload"
              type="file"
              accept=".csv,.txt"
              onChange={handleFileImport}
              disabled={isImporting}
            />
          </div>

          <div>
            <Label htmlFor="csv-data">Ou cole os dados CSV aqui:</Label>
            <Textarea
              id="csv-data"
              placeholder="nome,telefone,cidade,estado,categoria,url,campanha&#10;João Silva,(11) 99999-9999,São Paulo,SP,Premium,https://exemplo.com,Campanha1"
              value={csvData}
              onChange={(e) => setCsvData(e.target.value)}
              rows={8}
              disabled={isImporting}
            />
          </div>

          {isImporting && (
            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span>Importando leads...</span>
                <span>{importStats.success} sucessos / {importStats.processed} processados / {importStats.total} total</span>
              </div>
              <Progress value={importProgress} className="w-full" />
              {importStats.duplicates > 0 && (
                <div className="text-sm text-blue-600 flex items-start gap-2">
                  <AlertCircle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                  <span>{importStats.duplicates} duplicatas ignoradas</span>
                </div>
              )}
              {importStats.errors.length > 0 && (
                <div className="text-sm text-amber-600 flex items-start gap-2">
                  <AlertCircle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                  <span>{importStats.errors.length} erros encontrados (verifique o console para detalhes)</span>
                </div>
              )}
            </div>
          )}

          <div className="text-sm text-gray-600 p-3 bg-gray-50 rounded">
            <strong>Formato esperado:</strong>
            <br />
            Primeira linha: cabeçalhos (nome,telefone,cidade,estado,categoria,url,campanha)
            <br />
            Demais linhas: dados separados por vírgula
            <br />
            <strong>Campos obrigatórios:</strong> nome, telefone, cidade
            <br />
            <strong>Limites:</strong> {MAX_TOTAL_RECORDS.toLocaleString()} registros por arquivo, processamento em lotes de {BATCH_SIZE}
            <br />
            <strong>Formatos suportados:</strong> CSV e TXT com codificação UTF-8
            <br />
            <strong>Duplicatas:</strong> Leads com telefones já existentes serão automaticamente ignorados
          </div>

          <Button 
            onClick={() => importCsvMutation.mutate(csvData)}
            disabled={!csvData.trim() || isImporting}
            className="w-full"
          >
            <FileText className="h-4 w-4 mr-2" />
            {isImporting ? `Importando... ${importProgress}%` : "Importar Dados"}
          </Button>
        </CardContent>
      </Card>
    </div>
  );
};

export default ImportTab;
