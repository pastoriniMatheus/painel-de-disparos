
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';

export const useTemplates = () => {
  const { user } = useAuth();

  return useQuery({
    queryKey: ['message-templates', user?.id],
    queryFn: async () => {
      if (!user?.id) {
        console.log('Usuário não autenticado para buscar templates');
        return [];
      }
      
      console.log('Buscando templates para o usuário:', user.id);
      
      const { data, error } = await supabase
        .from('templates_mensagens')
        .select('*')
        .eq('user_id', user.id)
        .order('nome', { ascending: true });

      if (error) {
        console.error('Erro ao carregar templates:', error);
        throw error;
      }

      console.log('Templates encontrados na base de dados:', data?.length || 0);
      console.log('Dados dos templates:', data);
      return data || [];
    },
    enabled: !!user?.id,
    retry: 2,
    staleTime: 1000, // 1 segundo para dados mais frescos
    refetchOnMount: true,
    refetchOnWindowFocus: true,
    refetchInterval: false // Remover auto-refresh para melhor performance
  });
};
