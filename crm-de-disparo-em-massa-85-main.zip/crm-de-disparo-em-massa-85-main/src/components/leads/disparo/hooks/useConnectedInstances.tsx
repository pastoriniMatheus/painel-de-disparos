
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';

export interface ConnectedInstance {
  nome: string;
  apikey: string;
}

export const useConnectedInstances = () => {
  const { user } = useAuth();

  return useQuery({
    queryKey: ['connected-instances', user?.id],
    queryFn: async (): Promise<ConnectedInstance[]> => {
      if (!user?.id) return [];

      const { data, error } = await supabase
        .from('instancias_whatsapp')
        .select('nome, apikey')
        .eq('user_id', user.id)
        .eq('status', 'conectado')
        .not('apikey', 'is', null);

      if (error) {
        console.error('Erro ao buscar instâncias conectadas:', error);
        return [];
      }

      // Filtrar instâncias que têm apikey válida
      const instanciasValidas = (data || []).filter(instancia => 
        instancia.apikey && instancia.apikey.trim() !== ''
      );

      console.log('Instâncias conectadas encontradas:', instanciasValidas);
      return instanciasValidas as ConnectedInstance[];
    },
    enabled: !!user?.id,
    refetchOnWindowFocus: false
  });
};
