
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { useConnectedInstances } from "./useConnectedInstances";
import { processTemplateVariables, formatMessageForWhatsApp } from "../utils/templateProcessor";

export const useScheduledDispatches = () => {
  const { toast } = useToast();
  const { user } = useAuth();
  const queryClient = useQueryClient();

  // Função para processar disparos agendados
  const processarDisparosAgendados = async () => {
    if (!user?.id) {
      console.log('Usuário não autenticado para processar disparos agendados');
      return { processados: 0 }; // Retornar objeto ao invés de undefined
    }

    try {
      // Buscar disparos agendados que devem ser executados
      const agora = new Date().toISOString();
      const { data: disparosParaExecutar, error: consultaError } = await supabase
        .from('disparos_agendados')
        .select('*')
        .eq('user_id', user.id)
        .eq('status', 'agendado')
        .lte('data_agendada', agora);

      if (consultaError) {
        console.error('Erro ao consultar disparos agendados:', consultaError);
        return { processados: 0, erro: consultaError.message };
      }

      if (!disparosParaExecutar || disparosParaExecutar.length === 0) {
        console.log('Nenhum disparo agendado para executar');
        return { processados: 0 };
      }

      console.log(`${disparosParaExecutar.length} disparo(s) agendado(s) para executar`);

      // Buscar configurações do webhook
      const { data: configuracoes, error: configError } = await supabase
        .from('configuracoes')
        .select('webhook_envio')
        .eq('user_id', user.id)
        .maybeSingle();

      if (configError || !configuracoes?.webhook_envio) {
        console.error('Webhook não configurado para disparos agendados');
        // Marcar disparos como erro
        for (const disparo of disparosParaExecutar) {
          await supabase
            .from('disparos_agendados')
            .update({ 
              status: 'erro'
            })
            .eq('id', disparo.id);
        }
        return { processados: 0, erro: 'Webhook não configurado' };
      }

      // Buscar instâncias conectadas
      const { data: instanciasConectadas = [], error: instanciasError } = await supabase
        .from('instancias_whatsapp')
        .select('nome, apikey')
        .eq('user_id', user.id)
        .eq('status', 'conectado')
        .not('apikey', 'is', null);

      if (instanciasError) {
        console.error('Erro ao buscar instâncias conectadas:', instanciasError);
      }

      const instanciasValidas = (instanciasConectadas || []).filter(instancia => 
        instancia.apikey && instancia.apikey.trim() !== ''
      );

      let processadosComSucesso = 0;

      // Executar cada disparo
      for (const disparo of disparosParaExecutar) {
        try {
          console.log('Executando disparo agendado:', disparo.id);
          
          // Marcar como executando
          await supabase
            .from('disparos_agendados')
            .update({ status: 'executando' })
            .eq('id', disparo.id);

          const leadsDoDisparo = disparo.leads_selecionados as any[];

          // Processar leads individualmente com variáveis
          const leadsProcessados = leadsDoDisparo.map(lead => {
            const conteudoProcessado = processTemplateVariables(disparo.conteudo, lead);
            const conteudoFormatado = formatMessageForWhatsApp(conteudoProcessado);
            
            return {
              id: lead.id,
              nome: lead.nome,
              telefone: lead.telefone,
              cidade: lead.cidade,
              categoria: lead.categoria,
              url: lead.url,
              conteudo: conteudoFormatado // Conteúdo processado para cada lead
            };
          });

          // Preparar dados para o webhook
          const webhookData = {
            conteudo: disparo.conteudo, // Template original
            imagem_url: disparo.imagem_url || null,
            leads: leadsProcessados, // Leads com conteúdo processado individualmente
            instancias: instanciasValidas,
            timestamp: new Date().toISOString()
          };

          console.log('Instâncias conectadas incluídas no webhook do agendamento:', instanciasValidas);

          // Enviar para o webhook
          const response = await fetch(configuracoes.webhook_envio, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json'
            },
            body: JSON.stringify(webhookData)
          });

          if (response.ok) {
            // Marcar como executado
            await supabase
              .from('disparos_agendados')
              .update({ 
                status: 'executado'
              })
              .eq('id', disparo.id);

            // Registrar no histórico com conteúdo processado para cada lead
            const historicos = leadsDoDisparo.map(lead => {
              const conteudoProcessado = processTemplateVariables(disparo.conteudo, lead);
              
              return {
                user_id: disparo.user_id,
                lead_id: lead.id,
                nome_lead: lead.nome,
                telefone_lead: lead.telefone,
                conteudo: conteudoProcessado, // Salvar conteúdo com variáveis processadas
                imagem_url: disparo.imagem_url,
                status_envio: 'enviado'
              };
            });

            await supabase
              .from('historico_disparos')
              .insert(historicos);

            // Marcar leads como enviados se ainda existirem
            const leadIds = leadsDoDisparo.map(lead => lead.id).filter(id => id);
            if (leadIds.length > 0) {
              await supabase
                .from('leads')
                .update({ enviado: true })
                .in('id', leadIds);
            }
            
            console.log('Disparo executado com sucesso:', disparo.id);
            processadosComSucesso++;
          } else {
            throw new Error(`Webhook retornou status ${response.status}`);
          }

        } catch (error) {
          console.error('Erro ao executar disparo:', disparo.id, error);
          
          // Marcar como erro
          await supabase
            .from('disparos_agendados')
            .update({ 
              status: 'erro'
            })
            .eq('id', disparo.id);
        }
      }

      return { processados: processadosComSucesso, total: disparosParaExecutar.length };

    } catch (error) {
      console.error('Erro no processamento de disparos agendados:', error);
      return { processados: 0, erro: error instanceof Error ? error.message : 'Erro desconhecido' };
    }
  };

  // Iniciar o processamento automático (chama a cada 1 minuto)
  const { data: processandoAutomatico } = useQuery({
    queryKey: ['processar-disparos-agendados', user?.id],
    queryFn: processarDisparosAgendados,
    refetchInterval: 60000, // 1 minuto
    enabled: !!user?.id
  });

  // Mutation para testar o processamento manualmente
  const processarManualmenteMutation = useMutation({
    mutationFn: processarDisparosAgendados,
    onSuccess: (resultado) => {
      if (resultado?.processados && resultado.processados > 0) {
        toast({
          title: "Sucesso",
          description: `${resultado.processados} disparo(s) processado(s) com sucesso`
        });
      } else {
        toast({
          title: "Info",
          description: "Nenhum disparo agendado para processar no momento"
        });
      }
      queryClient.invalidateQueries({ queryKey: ['agendamentos'] });
    },
    onError: (error: any) => {
      toast({
        title: "Erro",
        description: "Erro ao processar disparos agendados",
        variant: "destructive"
      });
    }
  });

  return {
    processarManualmente: processarManualmenteMutation.mutate,
    isProcessing: processarManualmenteMutation.isPending
  };
};
