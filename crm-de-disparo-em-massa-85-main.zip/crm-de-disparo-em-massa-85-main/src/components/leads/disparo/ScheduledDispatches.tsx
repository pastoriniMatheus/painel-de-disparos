
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Clock, Trash2, Play } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { createSafeError } from "@/utils/errorHandling";
import { useScheduledDispatches } from "./hooks/useScheduledDispatches";

const ScheduledDispatches = () => {
  const { toast } = useToast();
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const { processarManualmente, isProcessing } = useScheduledDispatches();

  const { data: agendamentos = [] } = useQuery({
    queryKey: ['agendamentos', user?.id],
    queryFn: async () => {
      if (!user?.id) throw new Error("Usuário não autenticado");
      
      const { data, error } = await supabase
        .from('disparos_agendados')
        .select('*')
        .eq('user_id', user.id)
        .order('data_agendada', { ascending: true });
      
      if (error) throw error;
      return data || [];
    },
    enabled: !!user?.id,
    refetchInterval: 30000 // Atualizar a cada 30 segundos
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      if (!user?.id) throw new Error("Usuário não autenticado");
      
      const { error } = await supabase
        .from('disparos_agendados')
        .delete()
        .eq('id', id)
        .eq('user_id', user.id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['agendamentos'] });
      toast({
        title: "Sucesso",
        description: "Agendamento cancelado!"
      });
    },
    onError: (error: any) => {
      const safeError = createSafeError(error);
      toast({
        title: "Erro",
        description: safeError.message,
        variant: "destructive"
      });
    }
  });

  const formatarDataAgendamento = (dataString: string) => {
    return new Date(dataString).toLocaleString('pt-BR');
  };

  const getStatusBadgeVariant = (status: string) => {
    switch (status) {
      case 'agendado':
        return 'default';
      case 'executando':
        return 'secondary';
      case 'executado':
        return 'outline';
      case 'erro':
        return 'destructive';
      default:
        return 'secondary';
    }
  };

  if (agendamentos.length === 0) {
    return null;
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Clock className="h-5 w-5" />
            Disparos Agendados
          </CardTitle>
          <Button
            onClick={() => processarManualmente()}
            disabled={isProcessing}
            size="sm"
            variant="outline"
          >
            <Play className={`h-4 w-4 mr-2 ${isProcessing ? 'animate-spin' : ''}`} />
            {isProcessing ? "Processando..." : "Processar Agora"}
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {agendamentos.map((agendamento) => (
            <div key={agendamento.id} className="border rounded-lg p-4">
              <div className="flex items-start justify-between mb-2">
                <div>
                  <Badge variant={getStatusBadgeVariant(agendamento.status)}>
                    {agendamento.status}
                  </Badge>
                  <p className="text-sm text-gray-600 mt-1">
                    Agendado: {formatarDataAgendamento(agendamento.data_agendada)}
                  </p>
                </div>
                {agendamento.status === 'agendado' && (
                  <Button
                    size="sm"
                    variant="destructive"
                    onClick={() => deleteMutation.mutate(agendamento.id)}
                    disabled={deleteMutation.isPending}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                )}
              </div>
              
              <p className="text-sm mb-2">
                {agendamento.conteudo.length > 100 
                  ? agendamento.conteudo.substring(0, 100) + '...'
                  : agendamento.conteudo
                }
              </p>
              
              <p className="text-xs text-gray-500">
                {(agendamento.leads_selecionados as any[]).length} contatos selecionados
              </p>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default ScheduledDispatches;
