
import { useState, useEffect } from 'react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { FileText, RefreshCw } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useTemplates } from './hooks/useTemplates';
import { Button } from '@/components/ui/button';

interface TemplateSelectorProps {
  selectedTemplate: string;
  onTemplateSelect: (templateId: string, template?: any) => void;
}

const TemplateSelector = ({ selectedTemplate, onTemplateSelect }: TemplateSelectorProps) => {
  const { data: templates = [], isLoading, error, refetch } = useTemplates();
  const { toast } = useToast();

  // Log detalhado para debug
  useEffect(() => {
    console.log('=== DEBUG TemplateSelector ===');
    console.log('Templates carregados:', templates);
    console.log('Quantidade de templates:', templates.length);
    console.log('isLoading:', isLoading);
    console.log('error:', error);
    console.log('selectedTemplate:', selectedTemplate);
    console.log('================================');
  }, [templates, isLoading, error, selectedTemplate]);

  const handleTemplateChange = (templateId: string) => {
    console.log('Template selecionado ID:', templateId);
    
    if (templateId === 'none' || templateId === '') {
      onTemplateSelect('');
      return;
    }

    const template = templates.find(t => t.id === templateId);
    console.log('Template encontrado:', template);
    
    if (template) {
      // Manter template original - processamento será feito no envio
      onTemplateSelect(templateId, template);
      toast({
        title: "Template carregado",
        description: `Template "${template.nome}" foi aplicado com sucesso`
      });
    } else {
      console.error('Template não encontrado para ID:', templateId);
      toast({
        title: "Erro",
        description: "Template não encontrado",
        variant: "destructive"
      });
    }
  };

  const handleRefresh = () => {
    console.log('Atualizando templates manualmente...');
    refetch();
    toast({
      title: "Atualizando",
      description: "Carregando templates mais recentes..."
    });
  };

  if (error) {
    console.error('Erro no TemplateSelector:', error);
  }

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <Label htmlFor="template-select">Carregar Template</Label>
        <Button
          variant="outline"
          size="sm"
          onClick={handleRefresh}
          disabled={isLoading}
        >
          <RefreshCw className={`h-4 w-4 ${isLoading ? 'animate-spin' : ''}`} />
        </Button>
      </div>
      <Select value={selectedTemplate || 'none'} onValueChange={handleTemplateChange}>
        <SelectTrigger className="w-full">
          <SelectValue placeholder="Selecione um template..." />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="none">
            <div className="flex items-center gap-2">
              <FileText className="h-4 w-4" />
              Nenhum template
            </div>
          </SelectItem>
          {isLoading ? (
            <SelectItem value="loading" disabled>
              <div className="flex items-center gap-2">
                <RefreshCw className="h-4 w-4 animate-spin" />
                Carregando templates...
              </div>
            </SelectItem>
          ) : error ? (
            <SelectItem value="error" disabled>
              <div className="flex items-center gap-2 text-red-600">
                <FileText className="h-4 w-4" />
                Erro ao carregar templates
              </div>
            </SelectItem>
          ) : templates.length === 0 ? (
            <SelectItem value="empty" disabled>
              <div className="flex items-center gap-2">
                <FileText className="h-4 w-4" />
                Nenhum template encontrado. Crie um na aba Templates.
              </div>
            </SelectItem>
          ) : (
            templates.map((template) => (
              <SelectItem key={template.id} value={template.id}>
                <div className="flex items-center gap-2">
                  <FileText className="h-4 w-4" />
                  <div className="flex flex-col">
                    <span>{template.nome}</span>
                    <span className="text-xs text-gray-500 truncate max-w-60">
                      {template.conteudo.length > 50 
                        ? template.conteudo.substring(0, 50) + '...' 
                        : template.conteudo
                      }
                    </span>
                  </div>
                </div>
              </SelectItem>
            ))
          )}
        </SelectContent>
      </Select>
      {selectedTemplate && selectedTemplate !== 'none' && (
        <p className="text-sm text-green-600 mt-1">
          ✓ Template "{templates.find(t => t.id === selectedTemplate)?.nome || 'Selecionado'}" aplicado
        </p>
      )}
    </div>
  );
};

export default TemplateSelector;
