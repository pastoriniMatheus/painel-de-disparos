
import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { X } from 'lucide-react';

interface EditScheduledDispatchDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  dispatch: any;
  onSave: (updatedDispatch: any) => void;
}

const EditScheduledDispatchDialog = ({ 
  open, 
  onOpenChange, 
  dispatch, 
  onSave 
}: EditScheduledDispatchDialogProps) => {
  const [formData, setFormData] = useState({
    conteudo: '',
    imagem_url: '',
    data_agendada: '',
    hora_agendada: ''
  });

  useEffect(() => {
    if (dispatch) {
      const date = new Date(dispatch.data_agendada);
      const dateStr = date.toISOString().split('T')[0];
      const timeStr = date.toTimeString().split(' ')[0].substring(0, 5);

      setFormData({
        conteudo: dispatch.conteudo || '',
        imagem_url: dispatch.imagem_url || '',
        data_agendada: dateStr,
        hora_agendada: timeStr
      });
    }
  }, [dispatch]);

  const handleSave = () => {
    const dataHoraCompleta = new Date(`${formData.data_agendada}T${formData.hora_agendada}`);
    
    if (dataHoraCompleta <= new Date()) {
      alert('Data e hora devem ser futuras');
      return;
    }

    const updatedDispatch = {
      ...dispatch,
      conteudo: formData.conteudo,
      imagem_url: formData.imagem_url || null,
      data_agendada: dataHoraCompleta.toISOString()
    };

    onSave(updatedDispatch);
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Editar Disparo Agendado</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          <div>
            <Label htmlFor="conteudo">Mensagem *</Label>
            <Textarea
              id="conteudo"
              placeholder="Digite sua mensagem aqui..."
              value={formData.conteudo}
              onChange={(e) => setFormData(prev => ({ ...prev, conteudo: e.target.value }))}
              rows={4}
            />
          </div>

          <div>
            <Label htmlFor="imagem">URL da Imagem</Label>
            <Input
              id="imagem"
              type="url"
              placeholder="https://exemplo.com/imagem.jpg"
              value={formData.imagem_url}
              onChange={(e) => setFormData(prev => ({ ...prev, imagem_url: e.target.value }))}
            />
            {formData.imagem_url && (
              <div className="mt-2">
                <img 
                  src={formData.imagem_url} 
                  alt="Preview" 
                  className="max-w-32 h-auto rounded border"
                  onError={(e) => {
                    e.currentTarget.style.display = 'none';
                  }}
                />
              </div>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="data">Data *</Label>
              <Input
                id="data"
                type="date"
                value={formData.data_agendada}
                onChange={(e) => setFormData(prev => ({ ...prev, data_agendada: e.target.value }))}
                min={new Date().toISOString().split('T')[0]}
              />
            </div>
            <div>
              <Label htmlFor="hora">Hora *</Label>
              <Input
                id="hora"
                type="time"
                value={formData.hora_agendada}
                onChange={(e) => setFormData(prev => ({ ...prev, hora_agendada: e.target.value }))}
              />
            </div>
          </div>

          <div className="text-sm text-gray-600">
            Contatos selecionados: {(dispatch?.leads_selecionados as any[])?.length || 0}
          </div>

          <div className="flex gap-2 justify-end">
            <Button variant="outline" onClick={() => onOpenChange(false)}>
              Cancelar
            </Button>
            <Button 
              onClick={handleSave}
              disabled={!formData.conteudo.trim() || !formData.data_agendada || !formData.hora_agendada}
            >
              Salvar
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default EditScheduledDispatchDialog;
