
export const processTemplateVariables = (content: string, lead: any): string => {
  if (!content || !lead) return content;
  
  console.log('Processando template para lead:', lead);
  console.log('Conteúdo original:', content);
  
  let processedContent = content
    .replace(/\{\{nome\}\}/g, lead.nome || '')
    .replace(/\{\{cidade\}\}/g, lead.cidade || '')
    .replace(/\{\{categoria\}\}/g, lead.categoria || '')
    .replace(/\{\{telefone\}\}/g, lead.telefone || '')
    .replace(/\{\{url\}\}/g, lead.url || '');
  
  console.log('Conteúdo processado (antes formatação WhatsApp):', processedContent);
  return processedContent;
};

export const formatMessageForWhatsApp = (content: string): string => {
  if (!content) return content;
  
  console.log('Formatando mensagem para WhatsApp - entrada:', content);
  
  // Converter quebras de linha para formato WhatsApp (\n -> \\n)
  let formatted = content
    // Substituir \r\n (Windows) por \n primeiro
    .replace(/\r\n/g, '\n')
    // Substituir \r (Mac antigo) por \n
    .replace(/\r/g, '\n')
    // Converter quebras de linha para formato de escape duplo para WhatsApp
    .replace(/\n/g, '\\n');
  
  console.log('Formatado para WhatsApp - saída:', formatted);
  return formatted;
};

export const prepareMessageForWebhook = (content: string, lead: any): string => {
  // Primeiro processa as variáveis
  const processedContent = processTemplateVariables(content, lead);
  
  // Depois formata para WhatsApp
  const formattedContent = formatMessageForWhatsApp(processedContent);
  
  console.log('Mensagem final preparada para webhook:', {
    lead: lead.nome,
    original: content,
    processed: processedContent,
    formatted: formattedContent
  });
  
  return formattedContent;
};
