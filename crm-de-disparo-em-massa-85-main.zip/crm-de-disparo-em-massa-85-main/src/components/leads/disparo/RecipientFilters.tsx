
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";

interface RecipientFiltersProps {
  filtroCidade: string;
  setFiltroCidade: (value: string) => void;
  filtroCategoria: string;
  setFiltroCategoria: (value: string) => void;
  apenasContatosPendentes: boolean;
  setApenasContatosPendentes: (value: boolean) => void;
  incluirLeadsComErro: boolean;
  setIncluirLeadsComErro: (value: boolean) => void;
}

const RecipientFilters = ({
  filtroCidade,
  setFiltroCidade,
  filtroCategoria,
  setFiltroCategoria,
  apenasContatosPendentes,
  setApenasContatosPendentes,
  incluirLeadsComErro,
  setIncluirLeadsComErro
}: RecipientFiltersProps) => {
  const { user } = useAuth();

  // Query para buscar TODOS os leads (para obter as opções de filtro)
  const { data: allLeads = [] } = useQuery({
    queryKey: ['all-leads', user?.id],
    queryFn: async () => {
      if (!user?.id) throw new Error("Usuário não autenticado");
      
      const { data, error } = await supabase
        .from('leads')
        .select('*')
        .eq('user_id', user.id)
        .order('nome');
      
      if (error) throw error;
      return data || [];
    },
    enabled: !!user?.id
  });

  const cidades = [...new Set(allLeads.map(lead => lead.cidade).filter(cidade => cidade && cidade.trim() !== ''))];
  const categorias = [...new Set(allLeads.map(lead => lead.categoria).filter(categoria => categoria && categoria.trim() !== ''))];

  const nenhumFiltroMarcado = !apenasContatosPendentes && !incluirLeadsComErro;

  return (
    <Card>
      <CardHeader>
        <CardTitle>Configurar Destinatários</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <Label>Filtrar por Cidade</Label>
            <Select value={filtroCidade} onValueChange={setFiltroCidade}>
              <SelectTrigger>
                <SelectValue placeholder="Todas as cidades" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="todas">Todas as cidades</SelectItem>
                {cidades.map(cidade => (
                  <SelectItem key={cidade} value={cidade}>{cidade}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label>Filtrar por Categoria</Label>
            <Select value={filtroCategoria} onValueChange={setFiltroCategoria}>
              <SelectTrigger>
                <SelectValue placeholder="Todas as categorias" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="todas">Todas as categorias</SelectItem>
                {categorias.map(categoria => (
                  <SelectItem key={categoria} value={categoria}>{categoria}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="space-y-3">
          {nenhumFiltroMarcado && (
            <div className="bg-blue-50 p-3 rounded-lg mb-3">
              <p className="text-sm text-blue-800 font-medium">
                📢 Nenhum filtro de status selecionado: Todos os leads serão incluídos (enviados, pendentes e com erro)
              </p>
            </div>
          )}

          <div className="flex items-center space-x-2">
            <Checkbox
              id="apenas-pendentes"
              checked={apenasContatosPendentes}
              onCheckedChange={(checked) => setApenasContatosPendentes(checked as boolean)}
            />
            <Label htmlFor="apenas-pendentes">
              Enviar apenas para contatos pendentes (não enviados e sem erro)
            </Label>
          </div>

          <div className="flex items-center space-x-2">
            <Checkbox
              id="incluir-com-erro"
              checked={incluirLeadsComErro}
              onCheckedChange={(checked) => setIncluirLeadsComErro(checked as boolean)}
            />
            <Label htmlFor="incluir-com-erro">
              Incluir leads com status de erro
            </Label>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default RecipientFilters;
