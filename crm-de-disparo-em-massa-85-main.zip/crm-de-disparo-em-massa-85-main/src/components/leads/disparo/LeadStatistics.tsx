
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";

interface LeadStatisticsProps {
  filtroCidade: string;
  filtroCategoria: string;
  apenasContatosPendentes: boolean;
  incluirLeadsComErro: boolean;
}

const LeadStatistics = ({ filtroCidade, filtroCategoria, apenasContatosPendentes, incluirLeadsComErro }: LeadStatisticsProps) => {
  const { user } = useAuth();

  // Query para buscar TODOS os leads (sem filtros) para contadores corretos
  const { data: allLeads = [] } = useQuery({
    queryKey: ['all-leads', user?.id],
    queryFn: async () => {
      if (!user?.id) throw new Error("Usuário não autenticado");
      
      const { data, error } = await supabase
        .from('leads')
        .select('*')
        .eq('user_id', user.id)
        .order('nome');
      
      if (error) throw error;
      return data || [];
    },
    enabled: !!user?.id
  });

  // Query para leads filtrados (SEM LIMITE DE 1000)
  const { data: leadsFiltered = [] } = useQuery({
    queryKey: ['leads-disparo', filtroCidade, filtroCategoria, apenasContatosPendentes, incluirLeadsComErro, user?.id],
    queryFn: async () => {
      if (!user?.id) throw new Error("Usuário não autenticado");
      
      let query = supabase.from('leads').select('*').eq('user_id', user.id);
      
      if (filtroCidade && filtroCidade !== "todas") {
        query = query.eq('cidade', filtroCidade);
      }
      if (filtroCategoria && filtroCategoria !== "todas") {
        query = query.eq('categoria', filtroCategoria);
      }

      // Se nenhum filtro estiver marcado, incluir TODOS os leads
      const nenhumFiltroMarcado = !apenasContatosPendentes && !incluirLeadsComErro;
      
      if (!nenhumFiltroMarcado) {
        // Aplicar filtros conforme os checkboxes marcados
        if (apenasContatosPendentes && !incluirLeadsComErro) {
          // Apenas contatos pendentes (não enviados e sem erro)
          query = query.eq('enviado', false).or('erro.is.null,erro.eq.');
        } else if (incluirLeadsComErro && !apenasContatosPendentes) {
          // Apenas leads com erro
          query = query.not('erro', 'is', null).neq('erro', '');
        } else if (apenasContatosPendentes && incluirLeadsComErro) {
          // Pendentes OU com erro
          query = query.or('and(enviado.eq.false,or(erro.is.null,erro.eq.)),and(erro.is.not.null,erro.neq.)');
        }
      }
      
      const { data, error } = await query.order('nome');
      
      if (error) throw error;
      return data || [];
    },
    enabled: !!user?.id
  });

  // Estatísticas gerais (todos os leads)
  const contadorLeads = {
    total: allLeads.length,
    pendentes: allLeads.filter(lead => lead.enviado === false && !lead.erro).length,
    enviados: allLeads.filter(lead => lead.enviado === true).length,
    comErro: allLeads.filter(lead => lead.erro).length
  };

  return (
    <Card>
      <CardContent className="p-4">
        <div className="bg-gray-50 rounded-lg p-4">
          <h4 className="font-medium mb-3">Estatísticas dos Leads (Todos os contatos)</h4>
          <div className="grid grid-cols-4 gap-3 mb-4">
            <div className="text-center">
              <div className="text-xl font-bold text-blue-600">{contadorLeads.total}</div>
              <div className="text-xs text-gray-600">Total</div>
            </div>
            <div className="text-center">
              <div className="text-xl font-bold text-orange-600">{contadorLeads.pendentes}</div>
              <div className="text-xs text-gray-600">Pendentes</div>
            </div>
            <div className="text-center">
              <div className="text-xl font-bold text-green-600">{contadorLeads.enviados}</div>
              <div className="text-xs text-gray-600">Enviados</div>
            </div>
            <div className="text-center">
              <div className="text-xl font-bold text-red-600">{contadorLeads.comErro}</div>
              <div className="text-xs text-gray-600">Com Erro</div>
            </div>
          </div>
          
          <div className="border-t pt-3">
            <h5 className="font-medium mb-2">Resumo do Disparo</h5>
            <div className="space-y-2 text-sm">
              <p>
                <span className="font-medium">Contatos filtrados:</span> {leadsFiltered.length}
                {incluirLeadsComErro && " (apenas com erro)"}
              </p>
              <p>
                <span className="font-medium">Serão enviados para:</span> {leadsFiltered.length} contatos
              </p>
              <p className="text-green-600 font-medium">
                ✅ Sem limite de quantidade - Todos os contatos filtrados serão incluídos
              </p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default LeadStatistics;
