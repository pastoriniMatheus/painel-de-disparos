
import { useState, useCallback, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { Send, Calendar, Upload, X, MessageSquare, FileText } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

interface MessageFormProps {
  filtroCidade: string;
  filtroCategoria: string;
  apenasContatosPendentes: boolean;
}

interface MessageTemplate {
  id: string;
  nome: string;
  conteudo: string;
  imagem_url?: string;
}

const MessageForm = ({ filtroCidade, filtroCategoria, apenasContatosPendentes }: MessageFormProps) => {
  const [message, setMessage] = useState('');
  const [image, setImage] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string>('');
  const [isScheduled, setIsScheduled] = useState(false);
  const [scheduledDate, setScheduledDate] = useState('');
  const [scheduledTime, setScheduledTime] = useState('');
  const [sending, setSending] = useState(false);
  const [templates, setTemplates] = useState<MessageTemplate[]>([]);
  const [selectedTemplate, setSelectedTemplate] = useState<string>('');
  const [selectedLeads, setSelectedLeads] = useState<any[]>([]);
  const { toast } = useToast();
  const { user } = useAuth();

  // Buscar leads baseado nos filtros
  const fetchFilteredLeads = useCallback(async () => {
    if (!user?.id) return;

    try {
      let query = supabase
        .from('leads')
        .select('*')
        .eq('user_id', user.id);

      if (filtroCidade !== 'todas') {
        query = query.eq('cidade', filtroCidade);
      }

      if (filtroCategoria !== 'todas') {
        query = query.eq('categoria', filtroCategoria);
      }

      if (apenasContatosPendentes) {
        query = query.eq('enviado', false);
      }

      const { data, error } = await query.order('nome');
      
      if (error) {
        console.error('Erro ao buscar leads:', error);
        return;
      }

      setSelectedLeads(data || []);
    } catch (error) {
      console.error('Erro ao buscar leads:', error);
    }
  }, [user?.id, filtroCidade, filtroCategoria, apenasContatosPendentes]);

  useEffect(() => {
    fetchFilteredLeads();
  }, [fetchFilteredLeads]);

  // Carregar templates
  const fetchTemplates = useCallback(async () => {
    try {
      const { data, error } = await supabase
        .from('templates_mensagens')
        .select('*')
        .eq('user_id', user?.id)
        .order('nome', { ascending: true });

      if (error) {
        console.error('Erro ao carregar templates:', error);
        return;
      }

      setTemplates(data || []);
    } catch (error) {
      console.error('Erro ao carregar templates:', error);
    }
  }, [user?.id]);

  useEffect(() => {
    if (user?.id) {
      fetchTemplates();
    }
  }, [user?.id, fetchTemplates]);

  const handleTemplateSelect = useCallback((templateId: string) => {
    const template = templates.find(t => t.id === templateId);
    if (template) {
      setMessage(template.conteudo);
      setSelectedTemplate(templateId);
      
      // Se o template tem imagem, fazer download e definir preview
      if (template.imagem_url) {
        setImagePreview(template.imagem_url);
        // Não conseguimos definir o File aqui, mas o preview funciona
      } else {
        setImagePreview('');
        setImage(null);
      }
      
      toast({
        title: "Template carregado",
        description: `Template "${template.nome}" foi aplicado`
      });
    }
  }, [templates, toast]);

  const handleImageChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) { // 5MB limit
        toast({
          title: "Erro",
          description: "Imagem muito grande. Máximo 5MB.",
          variant: "destructive"
        });
        return;
      }

      if (!file.type.startsWith('image/')) {
        toast({
          title: "Erro",
          description: "Arquivo deve ser uma imagem.",
          variant: "destructive"
        });
        return;
      }

      setImage(file);
      const reader = new FileReader();
      reader.onload = (e) => {
        setImagePreview(e.target?.result as string);
      };
      reader.readAsDataURL(file);
      
      // Limpar template selecionado se uma nova imagem foi escolhida
      if (selectedTemplate) {
        setSelectedTemplate('');
      }
    }
  }, [toast, selectedTemplate]);

  const handleRemoveImage = useCallback(() => {
    setImage(null);
    setImagePreview('');
    setSelectedTemplate('');
  }, []);

  const sendMessage = useCallback(async () => {
    if (!message.trim()) {
      toast({
        title: "Erro",
        description: "Digite uma mensagem",
        variant: "destructive"
      });
      return;
    }

    if (selectedLeads.length === 0) {
      toast({
        title: "Erro",
        description: "Nenhum lead encontrado com os filtros aplicados",
        variant: "destructive"
      });
      return;
    }

    try {
      setSending(true);
      
      let imageUrl = '';
      
      // Upload da imagem se existir
      if (image) {
        const fileExt = image.name.split('.').pop();
        const fileName = `${Date.now()}.${fileExt}`;
        
        console.log('Fazendo upload da imagem...');
        // Simulação do upload - em produção você faria upload real
        imageUrl = URL.createObjectURL(image);
      } else if (imagePreview && selectedTemplate) {
        // Usar a URL da imagem do template
        const template = templates.find(t => t.id === selectedTemplate);
        if (template?.imagem_url) {
          imageUrl = template.imagem_url;
        }
      }

      if (isScheduled) {
        // Agendar disparo
        const scheduledDateTime = new Date(`${scheduledDate}T${scheduledTime}`);
        
        if (scheduledDateTime <= new Date()) {
          toast({
            title: "Erro",
            description: "Data/hora deve ser futura",
            variant: "destructive"
          });
          return;
        }

        console.log('Agendando disparo para:', scheduledDateTime);
        
        const { error } = await supabase
          .from('disparos_agendados')
          .insert({
            user_id: user?.id,
            conteudo: message,
            imagem_url: imageUrl || null,
            data_agendada: scheduledDateTime.toISOString(),
            leads_selecionados: selectedLeads.map(lead => ({
              id: lead.id,
              nome: lead.nome,
              telefone: lead.telefone
            })),
            status: 'agendado'
          });

        if (error) {
          console.error('Erro ao agendar disparo:', error);
          toast({
            title: "Erro",
            description: "Erro ao agendar disparo",
            variant: "destructive"
          });
          return;
        }

        toast({
          title: "Sucesso",
          description: `Disparo agendado para ${selectedLeads.length} contatos`
        });
      } else {
        // Envio imediato - registrar no histórico
        console.log('Enviando mensagem imediatamente...');
        
        const historicos = selectedLeads.map(lead => ({
          user_id: user?.id,
          lead_id: lead.id,
          nome_lead: lead.nome,
          telefone_lead: lead.telefone,
          conteudo: message,
          imagem_url: imageUrl || null,
          status_envio: 'enviado',
          data_envio: new Date().toISOString()
        }));

        const { error } = await supabase
          .from('historico_disparos')
          .insert(historicos);

        if (error) {
          console.error('Erro ao registrar histórico:', error);
          toast({
            title: "Erro",
            description: "Erro ao registrar envio",
            variant: "destructive"
          });
          return;
        }

        toast({
          title: "Sucesso",
          description: `Mensagem enviada para ${selectedLeads.length} contatos`
        });
      }

      // Limpar formulário
      setMessage('');
      setImage(null);
      setImagePreview('');
      setIsScheduled(false);
      setScheduledDate('');
      setScheduledTime('');
      setSelectedTemplate('');
      
    } catch (error) {
      console.error('Erro ao enviar mensagem:', error);
      toast({
        title: "Erro",
        description: "Erro ao enviar mensagem",
        variant: "destructive"
      });
    } finally {
      setSending(false);
    }
  }, [message, selectedLeads, image, imagePreview, isScheduled, scheduledDate, scheduledTime, selectedTemplate, templates, user?.id, toast]);

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <MessageSquare className="h-5 w-5" />
          Enviar Mensagem
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Seletor de Template */}
        {templates.length > 0 && (
          <div>
            <Label htmlFor="template-select">Carregar Template</Label>
            <Select value={selectedTemplate} onValueChange={handleTemplateSelect}>
              <SelectTrigger className="w-full">
                <SelectValue placeholder="Selecione um template..." />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="">
                  <div className="flex items-center gap-2">
                    <FileText className="h-4 w-4" />
                    Nenhum template
                  </div>
                </SelectItem>
                {templates.map((template) => (
                  <SelectItem key={template.id} value={template.id}>
                    <div className="flex items-center gap-2">
                      <FileText className="h-4 w-4" />
                      {template.nome}
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {selectedTemplate && (
              <p className="text-sm text-green-600 mt-1">
                Template "{templates.find(t => t.id === selectedTemplate)?.nome}" aplicado
              </p>
            )}
          </div>
        )}

        <div>
          <Label htmlFor="message">Mensagem *</Label>
          <Textarea
            id="message"
            placeholder="Digite sua mensagem aqui..."
            value={message}
            onChange={(e) => {
              setMessage(e.target.value);
              // Se o usuário editar a mensagem, limpar template selecionado
              if (selectedTemplate && e.target.value !== templates.find(t => t.id === selectedTemplate)?.conteudo) {
                setSelectedTemplate('');
              }
            }}
            rows={4}
            className="resize-none"
            required
          />
        </div>

        <div>
          <Label htmlFor="image">Imagem (opcional)</Label>
          <div className="flex items-center gap-2">
            <Input
              id="image"
              type="file"
              accept="image/*"
              onChange={handleImageChange}
              className="flex-1"
            />
            {imagePreview && (
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={handleRemoveImage}
              >
                <X className="h-4 w-4" />
              </Button>
            )}
          </div>
          {imagePreview && (
            <div className="mt-2">
              <img 
                src={imagePreview} 
                alt="Preview" 
                className="max-w-32 h-auto rounded border"
              />
            </div>
          )}
        </div>

        <div className="flex items-center gap-2">
          <input
            type="checkbox"
            id="schedule"
            checked={isScheduled}
            onChange={(e) => setIsScheduled(e.target.checked)}
          />
          <Label htmlFor="schedule">Agendar envio</Label>
        </div>

        {isScheduled && (
          <div className="grid grid-cols-2 gap-2">
            <div>
              <Label htmlFor="date">Data</Label>
              <Input
                id="date"
                type="date"
                value={scheduledDate}
                onChange={(e) => setScheduledDate(e.target.value)}
                min={new Date().toISOString().split('T')[0]}
                required
              />
            </div>
            <div>
              <Label htmlFor="time">Hora</Label>
              <Input
                id="time"
                type="time"
                value={scheduledTime}
                onChange={(e) => setScheduledTime(e.target.value)}
                required
              />
            </div>
          </div>
        )}

        <div className="flex items-center justify-between pt-4 border-t">
          <div className="text-sm text-gray-600">
            {selectedLeads.length} contato(s) selecionado(s)
          </div>
          <Button 
            onClick={sendMessage}
            disabled={sending || !message.trim() || selectedLeads.length === 0}
            className="min-w-32"
          >
            {sending ? (
              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
            ) : isScheduled ? (
              <Calendar className="h-4 w-4 mr-2" />
            ) : (
              <Send className="h-4 w-4 mr-2" />
            )}
            {sending ? 'Enviando...' : isScheduled ? 'Agendar' : 'Enviar'}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default MessageForm;
