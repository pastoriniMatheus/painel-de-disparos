
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { Send, X } from "lucide-react";
import TemplateSelector from "./TemplateSelector";
import { useConnectedInstances } from "./hooks/useConnectedInstances";
import { prepareMessageForWebhook } from "./utils/templateProcessor";
import { useQuery } from "@tanstack/react-query";

interface MessageFormUpdatedProps {
  filtroCidade: string;
  filtroCategoria: string;
  apenasContatosPendentes: boolean;
  incluirLeadsComErro: boolean;
}

const MessageFormUpdated = ({ 
  filtroCidade, 
  filtroCategoria, 
  apenasContatosPendentes,
  incluirLeadsComErro 
}: MessageFormUpdatedProps) => {
  const [conteudo, setConteudo] = useState("");
  const [imagemUrl, setImagemUrl] = useState("");
  const [selectedTemplate, setSelectedTemplate] = useState("");
  const [isEnviando, setIsEnviando] = useState(false);
  const { toast } = useToast();
  const { user } = useAuth();
  const { data: instanciasConectadas = [] } = useConnectedInstances();

  // Buscar leads filtrados
  const { data: leadsFiltrados = [] } = useQuery({
    queryKey: ['leads-filtrados', filtroCidade, filtroCategoria, apenasContatosPendentes, incluirLeadsComErro, user?.id],
    queryFn: async () => {
      if (!user?.id) return [];

      let query = supabase.from('leads').select('*').eq('user_id', user.id);
      
      if (filtroCidade !== "todas") {
        query = query.eq('cidade', filtroCidade);
      }
      
      if (filtroCategoria !== "todas") {
        query = query.eq('categoria', filtroCategoria);
      }
      
      if (apenasContatosPendentes) {
        query = query.eq('enviado', false).is('erro', null);
      }
      
      if (!incluirLeadsComErro) {
        query = query.is('erro', null);
      }
      
      const { data, error } = await query.order('created_at', { ascending: false });
      
      if (error) throw error;
      return data || [];
    },
    enabled: !!user?.id
  });

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const url = URL.createObjectURL(file);
      setImagemUrl(url);
    }
  };

  const removeImage = () => {
    setImagemUrl("");
  };

  const buscarConfiguracaoWebhook = async () => {
    if (!user?.id) return null;

    const { data: configuracao, error } = await supabase
      .from('configuracoes')
      .select('webhook_envio')
      .eq('user_id', user.id)
      .maybeSingle();

    if (error) {
      console.error('Erro ao buscar configuração webhook:', error);
      return null;
    }

    return configuracao;
  };

  const handleEnvio = async () => {
    if (!conteudo.trim()) {
      toast({
        title: "Erro",
        description: "Digite uma mensagem para enviar",
        variant: "destructive"
      });
      return;
    }

    if (leadsFiltrados.length === 0) {
      toast({
        title: "Aviso",
        description: "Nenhum lead selecionado para envio",
        variant: "destructive"
      });
      return;
    }

    if (!user?.id) {
      toast({
        title: "Erro",
        description: "Usuário não autenticado",
        variant: "destructive"
      });
      return;
    }

    setIsEnviando(true);

    try {
      // Buscar configuração do webhook
      const configuracao = await buscarConfiguracaoWebhook();

      if (!configuracao?.webhook_envio) {
        toast({
          title: "Aviso",
          description: "Webhook de envio não configurado. Configure na seção Ajustes > Webhooks",
          variant: "destructive"
        });
        return;
      }

      // Criar o disparo em massa
      const { data: disparo, error: disparoError } = await supabase
        .from('disparos_massa')
        .insert({
          user_id: user.id,
          conteudo,
          imagem_url: imagemUrl || null,
          total_leads: leadsFiltrados.length,
          status: 'em_andamento'
        })
        .select()
        .single();

      if (disparoError || !disparo) {
        console.error('Erro ao criar disparo:', disparoError);
        toast({
          title: "Erro",
          description: "Erro ao criar disparo em massa",
          variant: "destructive"
        });
        return;
      }

      // Criar registros de disparo_leads
      const disparoLeads = leadsFiltrados.map(lead => ({
        disparo_id: disparo.id,
        lead_id: lead.id,
        status: 'pendente'
      }));

      const { error: disparoLeadsError } = await supabase
        .from('disparo_leads')
        .insert(disparoLeads);

      if (disparoLeadsError) {
        console.error('Erro ao criar disparo_leads:', disparoLeadsError);
        toast({
          title: "Erro",
          description: "Erro ao vincular leads ao disparo",
          variant: "destructive"
        });
        return;
      }

      // Preparar leads com conteúdo processado para o webhook
      const leadsProcessados = leadsFiltrados.map(lead => {
        const conteudoProcessado = prepareMessageForWebhook(conteudo, lead);
        return {
          id: lead.id,
          nome: lead.nome,
          telefone: lead.telefone,
          cidade: lead.cidade,
          categoria: lead.categoria,
          url: lead.url,
          conteudo: conteudoProcessado
        };
      });

      // Preparar dados para o webhook
      const dadosWebhook = {
        disparo_id: disparo.id,
        conteudo: conteudo,
        imagem_url: imagemUrl || null,
        leads: leadsProcessados,
        instancias: instanciasConectadas,
        timestamp: new Date().toISOString(),
        webhook_confirmacao: `${window.location.origin}/functions/v1/webhook-confirmacao`
      };

      // Enviar webhook
      const response = await fetch(configuracao.webhook_envio, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(dadosWebhook)
      });

      if (!response.ok) {
        throw new Error(`Webhook falhou: ${response.status} ${response.statusText}`);
      }

      toast({
        title: "Sucesso",
        description: `Disparo em massa iniciado para ${leadsFiltrados.length} leads. A automação externa atualizará os status dos leads.`
      });

      // Limpar formulário
      setConteudo("");
      setImagemUrl("");
      setSelectedTemplate("");

    } catch (error) {
      console.error('Erro no envio:', error);
      toast({
        title: "Erro",
        description: "Erro inesperado durante o envio",
        variant: "destructive"
      });
    } finally {
      setIsEnviando(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Send className="h-5 w-5" />
          Enviar Disparo em Massa
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <TemplateSelector 
          selectedTemplate={selectedTemplate}
          onTemplateSelect={(templateId, template) => {
            setSelectedTemplate(templateId);
            if (template) {
              setConteudo(template.conteudo);
              if (template.imagem_url) {
                setImagemUrl(template.imagem_url);
              }
            }
          }}
        />

        <div>
          <Label htmlFor="conteudo">Mensagem</Label>
          <Textarea
            id="conteudo"
            value={conteudo}
            onChange={(e) => setConteudo(e.target.value)}
            placeholder="Digite sua mensagem aqui. Use {{nome}}, {{cidade}}, {{categoria}} para variáveis..."
            className="min-h-[100px]"
          />
          <p className="text-xs text-gray-500 mt-1">
            Variáveis disponíveis: {"{{nome}}"}, {"{{cidade}}"}, {"{{categoria}}"}, {"{{telefone}}"}, {"{{url}}"}
          </p>
        </div>

        <div>
          <Label htmlFor="imagem">Imagem (opcional)</Label>
          <div className="space-y-2">
            <Input
              id="imagem"
              type="file"
              accept="image/*"
              onChange={handleImageUpload}
              className="cursor-pointer"
            />
            
            {imagemUrl && (
              <div className="relative inline-block">
                <img 
                  src={imagemUrl} 
                  alt="Preview" 
                  className="h-20 w-20 object-cover rounded border"
                />
                <Button
                  size="sm"
                  variant="destructive"
                  className="absolute -top-2 -right-2 h-6 w-6 rounded-full p-0"
                  onClick={removeImage}
                >
                  <X className="h-3 w-3" />
                </Button>
              </div>
            )}
          </div>
        </div>

        {instanciasConectadas.length > 0 && (
          <div className="bg-green-50 p-3 rounded-lg">
            <p className="text-sm text-green-800 font-medium">
              {instanciasConectadas.length} instância(s) conectada(s):
            </p>
            <ul className="text-xs text-green-700 mt-1">
              {instanciasConectadas.map((instancia, index) => (
                <li key={index}>• {instancia.nome}</li>
              ))}
            </ul>
          </div>
        )}

        {instanciasConectadas.length === 0 && (
          <div className="bg-orange-50 p-3 rounded-lg">
            <p className="text-sm text-orange-800">
              ⚠️ Nenhuma instância conectada encontrada.
            </p>
          </div>
        )}

        <div className="bg-blue-50 p-3 rounded-lg">
          <p className="text-sm text-blue-800 font-medium">
            Leads selecionados para envio: {leadsFiltrados.length}
          </p>
          <div className="text-xs text-blue-700 mt-2 space-y-1">
            <p className="font-medium">URLs dos Webhooks de Confirmação:</p>
            <p>• <strong>Lead individual:</strong> {window.location.origin}/functions/v1/webhook-confirmacao</p>
            <p className="ml-2">Formato: POST {"{"}"lead_id": "uuid", "status": "enviado|erro", "error_details": "opcional"{"}"}</p>
            <p>• <strong>Disparo completo:</strong> {window.location.origin}/functions/v1/webhook-confirmacao</p>
            <p className="ml-2">Formato: POST {"{"}"disparo_id": "uuid"{"}"}</p>
          </div>
        </div>

        <Button 
          onClick={handleEnvio}
          disabled={isEnviando || !conteudo.trim() || leadsFiltrados.length === 0}
          className="w-full"
        >
          <Send className="h-4 w-4 mr-2" />
          {isEnviando ? "Enviando..." : `Enviar para ${leadsFiltrados.length} leads`}
        </Button>
      </CardContent>
    </Card>
  );
};

export default MessageFormUpdated;
