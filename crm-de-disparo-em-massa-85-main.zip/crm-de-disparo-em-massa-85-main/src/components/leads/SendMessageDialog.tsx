
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { Send, User, X } from "lucide-react";
import { useTemplates } from "./disparo/hooks/useTemplates";
import { prepareMessageForWebhook } from "./disparo/utils/templateProcessor";
import { useConnectedInstances } from "./disparo/hooks/useConnectedInstances";

interface SendMessageDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  leads: any[];
}

const SendMessageDialog = ({ open, onOpenChange, leads }: SendMessageDialogProps) => {
  const [selectedLead, setSelectedLead] = useState<any>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedTemplate, setSelectedTemplate] = useState("");
  const [conteudo, setConteudo] = useState("");
  const [imagemUrl, setImagemUrl] = useState("");
  const [isEnviando, setIsEnviando] = useState(false);
  const { toast } = useToast();
  const { user } = useAuth();
  const { data: templates = [] } = useTemplates();
  const { data: instanciasConectadas = [] } = useConnectedInstances();

  const filteredLeads = leads.filter(lead => 
    lead.nome.toLowerCase().includes(searchTerm.toLowerCase()) ||
    lead.telefone.includes(searchTerm)
  );

  const handleLeadSelect = (lead: any) => {
    setSelectedLead(lead);
    setSearchTerm("");
  };

  const handleTemplateSelect = (templateId: string) => {
    setSelectedTemplate(templateId);
    if (templateId === 'none' || templateId === '') {
      setConteudo("");
      setImagemUrl("");
      return;
    }

    const template = templates.find(t => t.id === templateId);
    if (template) {
      setConteudo(template.conteudo);
      if (template.imagem_url) {
        setImagemUrl(template.imagem_url);
      }
    }
  };

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const url = URL.createObjectURL(file);
      setImagemUrl(url);
    }
  };

  const removeImage = () => {
    setImagemUrl("");
  };

  const buscarConfiguracaoWebhook = async () => {
    if (!user?.id) return null;

    const { data: configuracao, error } = await supabase
      .from('configuracoes')
      .select('webhook_envio')
      .eq('user_id', user.id)
      .maybeSingle();

    if (error) {
      console.error('Erro ao buscar configuração webhook:', error);
      return null;
    }

    return configuracao;
  };

  const handleEnvio = async () => {
    if (!conteudo.trim()) {
      toast({
        title: "Erro",
        description: "Digite uma mensagem para enviar",
        variant: "destructive"
      });
      return;
    }

    if (!selectedLead) {
      toast({
        title: "Erro",
        description: "Selecione um lead para enviar a mensagem",
        variant: "destructive"
      });
      return;
    }

    if (!user?.id) {
      toast({
        title: "Erro",
        description: "Usuário não autenticado",
        variant: "destructive"
      });
      return;
    }

    setIsEnviando(true);

    try {
      // Buscar configuração do webhook
      const configuracao = await buscarConfiguracaoWebhook();

      if (!configuracao?.webhook_envio) {
        toast({
          title: "Aviso",
          description: "Webhook de envio não configurado. Configure na seção Ajustes > Webhooks",
          variant: "destructive"
        });
        return;
      }

      // Processar conteúdo com variáveis do lead selecionado
      const conteudoProcessado = prepareMessageForWebhook(conteudo, selectedLead);

      const leadProcessado = {
        id: selectedLead.id,
        nome: selectedLead.nome,
        telefone: selectedLead.telefone,
        cidade: selectedLead.cidade,
        categoria: selectedLead.categoria,
        url: selectedLead.url,
        conteudo: conteudoProcessado
      };

      // Preparar dados para o webhook COM INSTÂNCIAS CONECTADAS
      const dadosWebhook = {
        conteudo: conteudo,
        imagem_url: imagemUrl || null,
        leads: [leadProcessado],
        instancias: instanciasConectadas,
        timestamp: new Date().toISOString(),
        webhook_confirmacao: `${window.location.origin}/functions/v1/webhook-confirmacao`
      };

      // Enviar webhook
      const response = await fetch(configuracao.webhook_envio, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(dadosWebhook)
      });

      if (!response.ok) {
        throw new Error(`Webhook falhou: ${response.status} ${response.statusText}`);
      }

      // Registrar no histórico (sem marcar como enviado)
      const { error: historicoError } = await supabase
        .from('historico_disparos')
        .insert({
          user_id: user.id,
          lead_id: selectedLead.id,
          nome_lead: selectedLead.nome,
          telefone_lead: selectedLead.telefone,
          conteudo: conteudoProcessado,
          imagem_url: imagemUrl || null,
          status_envio: 'pendente' // Mudado de 'enviado' para 'pendente'
        });

      if (historicoError) {
        console.error('Erro ao salvar histórico:', historicoError);
      }

      // REMOVIDO: Não marcar mais os leads como enviados automaticamente
      // A automação externa se encarregará de atualizar o status via webhook

      toast({
        title: "Sucesso",
        description: `Mensagem enviada para ${selectedLead.nome}. Use o webhook de confirmação para atualizar o status.`
      });

      // Limpar formulário e fechar dialog
      setSelectedLead(null);
      setConteudo("");
      setImagemUrl("");
      setSelectedTemplate("");
      onOpenChange(false);

    } catch (error) {
      console.error('Erro no envio:', error);
      toast({
        title: "Erro",
        description: "Erro inesperado durante o envio",
        variant: "destructive"
      });
    } finally {
      setIsEnviando(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Send className="h-5 w-5" />
            Enviar Mensagem Individual
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {!selectedLead ? (
            <div>
              <Label>Pesquisar Lead</Label>
              <Command className="border">
                <CommandInput
                  placeholder="Digite o nome ou telefone do lead..."
                  value={searchTerm}
                  onValueChange={setSearchTerm}
                />
                <CommandList className="max-h-40">
                  <CommandEmpty>Nenhum lead encontrado.</CommandEmpty>
                  <CommandGroup>
                    {filteredLeads.map((lead) => (
                      <CommandItem
                        key={lead.id}
                        value={lead.nome}
                        onSelect={() => handleLeadSelect(lead)}
                        className="cursor-pointer"
                      >
                        <User className="h-4 w-4 mr-2" />
                        <div className="flex flex-col">
                          <span className="font-medium">{lead.nome}</span>
                          <span className="text-sm text-gray-500">
                            {lead.telefone} - {lead.cidade}
                          </span>
                        </div>
                      </CommandItem>
                    ))}
                  </CommandGroup>
                </CommandList>
              </Command>
            </div>
          ) : (
            <>
              <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                <div className="flex items-center gap-2">
                  <User className="h-4 w-4" />
                  <div>
                    <p className="font-medium">{selectedLead.nome}</p>
                    <p className="text-sm text-gray-600">
                      {selectedLead.telefone} - {selectedLead.cidade}
                    </p>
                  </div>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setSelectedLead(null)}
                >
                  Alterar
                </Button>
              </div>

              <div>
                <Label>Template</Label>
                <Select value={selectedTemplate || 'none'} onValueChange={handleTemplateSelect}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione um template..." />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">Nenhum template</SelectItem>
                    {templates.map((template) => (
                      <SelectItem key={template.id} value={template.id}>
                        {template.nome}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="conteudo">Mensagem</Label>
                <Textarea
                  id="conteudo"
                  value={conteudo}
                  onChange={(e) => setConteudo(e.target.value)}
                  placeholder="Digite sua mensagem aqui. Use {{nome}}, {{cidade}}, {{categoria}} para variáveis..."
                  className="min-h-[100px]"
                />
                <p className="text-xs text-gray-500 mt-1">
                  Variáveis disponíveis: {"{{nome}}"}, {"{{cidade}}"}, {"{{categoria}}"}, {"{{telefone}}"}, {"{{url}}"}
                </p>
              </div>

              <div>
                <Label htmlFor="imagem">Imagem (opcional)</Label>
                <div className="space-y-2">
                  <Input
                    id="imagem"
                    type="file"
                    accept="image/*"
                    onChange={handleImageUpload}
                    className="cursor-pointer"
                  />
                  
                  {imagemUrl && (
                    <div className="relative inline-block">
                      <img 
                        src={imagemUrl} 
                        alt="Preview" 
                        className="h-20 w-20 object-cover rounded border"
                      />
                      <Button
                        size="sm"
                        variant="destructive"
                        className="absolute -top-2 -right-2 h-6 w-6 rounded-full p-0"
                        onClick={removeImage}
                      >
                        <X className="h-3 w-3" />
                      </Button>
                    </div>
                  )}
                </div>
              </div>

              {instanciasConectadas.length > 0 && (
                <div className="bg-green-50 p-3 rounded-lg">
                  <p className="text-sm text-green-800 font-medium">
                    {instanciasConectadas.length} instância(s) conectada(s) será(ão) incluída(s) no webhook:
                  </p>
                  <ul className="text-xs text-green-700 mt-1">
                    {instanciasConectadas.map((instancia, index) => (
                      <li key={index}>• {instancia.nome} (API: {instancia.apikey ? instancia.apikey.substring(0, 8) + '...' : 'N/A'})</li>
                    ))}
                  </ul>
                </div>
              )}

              {instanciasConectadas.length === 0 && (
                <div className="bg-orange-50 p-3 rounded-lg">
                  <p className="text-sm text-orange-800">
                    ⚠️ Nenhuma instância conectada encontrada. Verifique o status das suas instâncias na aba "Instâncias".
                  </p>
                </div>
              )}

              <div className="bg-blue-50 p-3 rounded-lg">
                <p className="text-sm text-blue-800 font-medium">
                  Webhook de Confirmação
                </p>
                <p className="text-xs text-blue-700 mt-1">
                  URL: {window.location.origin}/functions/v1/webhook-confirmacao
                </p>
                <p className="text-xs text-blue-700">
                  Formato: POST {"{"}"lead_id": "uuid", "status": "enviado|erro", "error_details": "opcional"{"}"}
                </p>
              </div>

              <Button 
                onClick={handleEnvio}
                disabled={isEnviando || !conteudo.trim() || !selectedLead}
                className="w-full"
              >
                <Send className="h-4 w-4 mr-2" />
                {isEnviando ? "Enviando..." : "Enviar Mensagem"}
              </Button>
            </>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default SendMessageDialog;
