
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";
import { supabase } from "@/integrations/supabase/client";
import { Database, Users, CheckCircle, XCircle, Send, Clock, TrendingUp } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";

const DashboardTab = () => {
  const { user } = useAuth();

  const { data: stats } = useQuery({
    queryKey: ['dashboard-stats', user?.id],
    queryFn: async () => {
      if (!user?.id) return null;

      const [leadsResult, historicoResult, disparosResult] = await Promise.all([
        supabase.from('leads').select('*').eq('user_id', user.id),
        supabase.from('historico_disparos').select('*').eq('user_id', user.id),
        supabase.from('disparos_massa').select('*').eq('user_id', user.id)
      ]);

      const leads = leadsResult.data || [];
      const historico = historicoResult.data || [];
      const disparos = disparosResult.data || [];

      const totalLeads = leads.length;
      const enviados = leads.filter(lead => lead.enviado).length;
      const comErro = leads.filter(lead => lead.erro).length;
      const totalDisparos = historico.length;
      const totalDisparosMassa = disparos.length;

      // Agrupar por cidade
      const leadsPorCidade = leads.reduce((acc: any, lead) => {
        acc[lead.cidade] = (acc[lead.cidade] || 0) + 1;
        return acc;
      }, {});

      // Agrupar por categoria
      const leadsPorCategoria = leads.reduce((acc: any, lead) => {
        acc[lead.categoria] = (acc[lead.categoria] || 0) + 1;
        return acc;
      }, {});

      const cidadeData = Object.entries(leadsPorCidade).map(([cidade, count]) => ({
        cidade,
        leads: count
      }));

      const categoriaData = Object.entries(leadsPorCategoria).map(([categoria, count]) => ({
        name: categoria,
        value: count
      }));

      // Últimos disparos em massa (últimos 5)
      const ultimosDisparos = disparos
        .sort((a, b) => new Date(b.data_inicio).getTime() - new Date(a.data_inicio).getTime())
        .slice(0, 5)
        .map(disparo => ({
          id: disparo.id,
          data_inicio: new Date(disparo.data_inicio).toLocaleString('pt-BR'),
          data_conclusao: disparo.data_conclusao ? new Date(disparo.data_conclusao).toLocaleString('pt-BR') : 'Em andamento',
          total_leads: disparo.total_leads,
          leads_enviados: disparo.leads_enviados,
          leads_erro: disparo.leads_erro,
          status: disparo.status,
          taxa_sucesso: disparo.total_leads > 0 ? Math.round((disparo.leads_enviados / disparo.total_leads) * 100) : 0
        }));

      // Disparos do dia
      const hoje = new Date().toISOString().split('T')[0];
      const disparosDoDia = disparos.filter(disparo => 
        disparo.data_inicio.startsWith(hoje)
      );

      return {
        totalLeads,
        enviados,
        comErro,
        totalDisparos,
        totalDisparosMassa,
        cidadeData,
        categoriaData,
        ultimosDisparos,
        disparosDoDia: disparosDoDia.length,
        leadsEnviadosHoje: disparosDoDia.reduce((acc, d) => acc + d.leads_enviados, 0),
        leadsErroHoje: disparosDoDia.reduce((acc, d) => acc + d.leads_erro, 0)
      };
    },
    enabled: !!user?.id
  });

  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8'];

  if (!stats) {
    return <div>Carregando...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total de Leads</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalLeads}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Enviados</CardTitle>
            <CheckCircle className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{stats.enviados}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Com Erro</CardTitle>
            <XCircle className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{stats.comErro}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Disparos em Massa</CardTitle>
            <TrendingUp className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">{stats.totalDisparosMassa}</div>
          </CardContent>
        </Card>
      </div>

      {/* Estatísticas do dia */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Disparos Hoje</CardTitle>
            <Send className="h-4 w-4 text-purple-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-purple-600">{stats.disparosDoDia}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Enviados Hoje</CardTitle>
            <CheckCircle className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{stats.leadsEnviadosHoje}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Erros Hoje</CardTitle>
            <XCircle className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{stats.leadsErroHoje}</div>
          </CardContent>
        </Card>
      </div>

      {/* Últimos Disparos */}
      <Card>
        <CardHeader>
          <CardTitle>Últimos Disparos em Massa</CardTitle>
          <CardDescription>Histórico dos 5 últimos disparos realizados</CardDescription>
        </CardHeader>
        <CardContent>
          {stats.ultimosDisparos.length > 0 ? (
            <div className="space-y-4">
              {stats.ultimosDisparos.map((disparo) => (
                <div key={disparo.id} className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <Clock className="h-4 w-4" />
                      <span className="font-medium">Início: {disparo.data_inicio}</span>
                      {disparo.status === 'concluido' && (
                        <span className="text-sm text-gray-600">
                          | Conclusão: {disparo.data_conclusao}
                        </span>
                      )}
                    </div>
                    <div className="text-sm text-gray-600">
                      Status: <span className={`font-medium ${
                        disparo.status === 'concluido' ? 'text-green-600' : 
                        disparo.status === 'em_andamento' ? 'text-blue-600' : 'text-red-600'
                      }`}>
                        {disparo.status === 'concluido' ? 'Concluído' : 
                         disparo.status === 'em_andamento' ? 'Em Andamento' : 'Erro'}
                      </span>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-lg font-bold">{disparo.total_leads} leads</div>
                    <div className="text-sm text-gray-600">
                      {disparo.leads_enviados} enviados • {disparo.leads_erro} erros
                    </div>
                    <div className={`text-sm font-medium ${
                      disparo.taxa_sucesso >= 80 ? 'text-green-600' : 
                      disparo.taxa_sucesso >= 50 ? 'text-yellow-600' : 'text-red-600'
                    }`}>
                      {disparo.taxa_sucesso}% sucesso
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8 text-gray-500">
              Nenhum disparo em massa realizado ainda
            </div>
          )}
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Leads por Cidade</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={stats.cidadeData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="cidade" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="leads" fill="#8884d8" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Leads por Categoria</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={stats.categoriaData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {stats.categoriaData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default DashboardTab;
