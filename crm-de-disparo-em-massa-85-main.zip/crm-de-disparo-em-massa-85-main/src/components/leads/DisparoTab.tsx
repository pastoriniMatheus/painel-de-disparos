
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Send } from "lucide-react";
import MessageFormUpdated from "./disparo/MessageFormUpdated";
import RecipientFilters from "./disparo/RecipientFilters";
import ScheduledDispatches from "./disparo/ScheduledDispatches";
import LeadStatistics from "./disparo/LeadStatistics";

const DisparoTab = () => {
  const [filtroCidade, setFiltroCidade] = useState("todas");
  const [filtroCategoria, setFiltroCategoria] = useState("todas");
  const [apenasContatosPendentes, setApenasContatosPendentes] = useState(false);
  const [incluirLeadsComErro, setIncluirLeadsComErro] = useState(false);

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <MessageFormUpdated 
          filtroCidade={filtroCidade}
          filtroCategoria={filtroCategoria}
          apenasContatosPendentes={apenasContatosPendentes}
          incluirLeadsComErro={incluirLeadsComErro}
        />

        <div className="space-y-6">
          <RecipientFilters 
            filtroCidade={filtroCidade}
            setFiltroCidade={setFiltroCidade}
            filtroCategoria={filtroCategoria}
            setFiltroCategoria={setFiltroCategoria}
            apenasContatosPendentes={apenasContatosPendentes}
            setApenasContatosPendentes={setApenasContatosPendentes}
            incluirLeadsComErro={incluirLeadsComErro}
            setIncluirLeadsComErro={setIncluirLeadsComErro}
          />
          
          <LeadStatistics 
            filtroCidade={filtroCidade}
            filtroCategoria={filtroCategoria}
            apenasContatosPendentes={apenasContatosPendentes}
            incluirLeadsComErro={incluirLeadsComErro}
          />
        </div>
      </div>

      <ScheduledDispatches />
    </div>
  );
};

export default DisparoTab;
