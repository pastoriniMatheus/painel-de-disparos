import { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { MessageSquare, Clock, CheckCircle, XCircle, Users, Trash2, Send, Calendar, TrendingUp, Plus, RotateCcw } from 'lucide-react';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';

interface DisparoMassa {
  id: string;
  conteudo: string;
  imagem_url?: string;
  data_inicio: string;
  data_conclusao?: string;
  total_leads: number;
  leads_enviados: number;
  leads_erro: number;
  status: string;
  leads_detalhes?: any[];
}

interface DisparoAgendado {
  id: string;
  conteudo: string;
  imagem_url?: string;
  data_agendada: string;
  status: string;
  leads_selecionados: any;
}

const HistoricoTab = () => {
  const [disparos, setDisparos] = useState<DisparoMassa[]>([]);
  const [disparosAgendados, setDisparosAgendados] = useState<DisparoAgendado[]>([]);
  const [loading, setLoading] = useState(true);
  const [expandedDisparo, setExpandedDisparo] = useState<string | null>(null);
  const [showAgendamentoDialog, setShowAgendamentoDialog] = useState(false);
  const [showReagendamentoDialog, setShowReagendamentoDialog] = useState(false);
  const [disparoParaReagendar, setDisparoParaReagendar] = useState<DisparoMassa | null>(null);
  const [agendamentoForm, setAgendamentoForm] = useState({
    conteudo: '',
    data_agendada: '',
    hora_agendada: ''
  });
  const { toast } = useToast();
  const { user } = useAuth();

  const fetchDisparos = useCallback(async () => {
    try {
      setLoading(true);
      console.log('Buscando histórico de disparos em massa...');
      
      const { data, error } = await supabase
        .from('disparos_massa')
        .select(`
          *,
          disparo_leads (
            id,
            lead_id,
            status,
            data_processamento,
            erro_detalhes,
            leads (
              nome,
              telefone,
              cidade,
              categoria
            )
          )
        `)
        .eq('user_id', user?.id)
        .order('data_inicio', { ascending: false });

      if (error) {
        console.error('Erro ao buscar disparos:', error);
        toast({
          title: "Erro",
          description: "Erro ao carregar histórico de disparos",
          variant: "destructive"
        });
        return;
      }

      console.log('Disparos carregados:', data);

      const disparosComDetalhes = data?.map(disparo => ({
        ...disparo,
        leads_detalhes: disparo.disparo_leads?.map((dl: any) => ({
          id: dl.id,
          lead_id: dl.lead_id,
          status: dl.status,
          data_processamento: dl.data_processamento,
          erro_detalhes: dl.erro_detalhes,
          nome: dl.leads?.nome || 'N/A',
          telefone: dl.leads?.telefone || 'N/A',
          cidade: dl.leads?.cidade || 'N/A',
          categoria: dl.leads?.categoria || 'N/A'
        })) || []
      })) || [];

      setDisparos(disparosComDetalhes);
    } catch (error) {
      console.error('Erro ao buscar disparos:', error);
      toast({
        title: "Erro",
        description: "Erro ao carregar histórico de disparos",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  }, [user?.id, toast]);

  const fetchDisparosAgendados = useCallback(async () => {
    try {
      console.log('Buscando disparos agendados...');
      
      const { data, error } = await supabase
        .from('disparos_agendados')
        .select('*')
        .eq('user_id', user?.id)
        .order('data_agendada', { ascending: false });

      if (error) {
        console.error('Erro ao buscar disparos agendados:', error);
        return;
      }

      console.log('Disparos agendados carregados:', data);
      setDisparosAgendados(data || []);
    } catch (error) {
      console.error('Erro ao buscar disparos agendados:', error);
    }
  }, [user?.id]);

  const limparHistoricoCompleto = useCallback(async () => {
    try {
      console.log('Iniciando limpeza completa do histórico...');
      setLoading(true);
      
      if (!user?.id) {
        toast({
          title: "Erro",
          description: "Usuário não autenticado",
          variant: "destructive"
        });
        return;
      }

      // 1. Buscar todos os disparos do usuário primeiro
      const { data: disparosData, error: errorBuscarDisparos } = await supabase
        .from('disparos_massa')
        .select('id')
        .eq('user_id', user.id);

      if (errorBuscarDisparos) {
        console.error('Erro ao buscar disparos:', errorBuscarDisparos);
        throw errorBuscarDisparos;
      }

      console.log('Disparos encontrados para deletar:', disparosData);

      // 2. Deletar disparo_leads relacionados primeiro (se existirem disparos)
      if (disparosData && disparosData.length > 0) {
        const disparoIds = disparosData.map(d => d.id);
        
        console.log('Deletando disparo_leads para disparos:', disparoIds);
        const { error: errorDisparoLeads } = await supabase
          .from('disparo_leads')
          .delete()
          .in('disparo_id', disparoIds);

        if (errorDisparoLeads) {
          console.error('Erro ao deletar disparo_leads:', errorDisparoLeads);
          throw errorDisparoLeads;
        }
        console.log('disparo_leads deletados com sucesso');
      }

      // 3. Deletar disparos_massa
      console.log('Deletando disparos_massa...');
      const { error: errorDisparosMassa } = await supabase
        .from('disparos_massa')
        .delete()
        .eq('user_id', user.id);

      if (errorDisparosMassa) {
        console.error('Erro ao deletar disparos_massa:', errorDisparosMassa);
        throw errorDisparosMassa;
      }
      console.log('disparos_massa deletados com sucesso');

      // 4. Deletar disparos_agendados
      console.log('Deletando disparos_agendados...');
      const { error: errorDisparosAgendados } = await supabase
        .from('disparos_agendados')
        .delete()
        .eq('user_id', user.id);

      if (errorDisparosAgendados) {
        console.error('Erro ao deletar disparos_agendados:', errorDisparosAgendados);
        throw errorDisparosAgendados;
      }
      console.log('disparos_agendados deletados com sucesso');

      // 5. Deletar histórico_disparos (se existir)
      console.log('Deletando historico_disparos...');
      const { error: errorHistorico } = await supabase
        .from('historico_disparos')
        .delete()
        .eq('user_id', user.id);

      if (errorHistorico) {
        console.error('Erro ao deletar historico_disparos:', errorHistorico);
        // Não falhar se esta tabela der erro
        console.warn('Aviso: não foi possível limpar historico_disparos');
      } else {
        console.log('historico_disparos deletados com sucesso');
      }

      toast({
        title: "Sucesso",
        description: "Todo o histórico foi limpo com sucesso"
      });
      
      // Recarregar dados
      await fetchDisparos();
      await fetchDisparosAgendados();
      
    } catch (error) {
      console.error('Erro ao limpar histórico completo:', error);
      toast({
        title: "Erro",
        description: `Erro ao limpar histórico: ${error.message || 'Erro desconhecido'}`,
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  }, [user?.id, fetchDisparos, fetchDisparosAgendados, toast]);

  const deletarDisparoIndividual = useCallback(async (disparoId: string, tipo: 'massa' | 'agendado') => {
    try {
      console.log(`Deletando disparo individual ${tipo}:`, disparoId);
      
      if (!user?.id) {
        toast({
          title: "Erro",
          description: "Usuário não autenticado",
          variant: "destructive"
        });
        return;
      }

      if (tipo === 'massa') {
        // 1. Deletar disparo_leads primeiro
        console.log('Deletando disparo_leads para disparo:', disparoId);
        const { error: errorDisparoLeads } = await supabase
          .from('disparo_leads')
          .delete()
          .eq('disparo_id', disparoId);

        if (errorDisparoLeads) {
          console.error('Erro ao deletar disparo_leads:', errorDisparoLeads);
          throw errorDisparoLeads;
        }
        console.log('disparo_leads deletados com sucesso');

        // 2. Deletar disparo massa
        console.log('Deletando disparo_massa:', disparoId);
        const { error: errorDisparo } = await supabase
          .from('disparos_massa')
          .delete()
          .eq('id', disparoId)
          .eq('user_id', user.id);

        if (errorDisparo) {
          console.error('Erro ao deletar disparo massa:', errorDisparo);
          throw errorDisparo;
        }
        console.log('disparo_massa deletado com sucesso');

        // Atualizar estado local removendo o item deletado
        setDisparos(prevDisparos => prevDisparos.filter(d => d.id !== disparoId));

      } else {
        // Deletar disparo agendado
        console.log('Deletando disparo_agendado:', disparoId);
        const { error: errorAgendado } = await supabase
          .from('disparos_agendados')
          .delete()
          .eq('id', disparoId)
          .eq('user_id', user.id);

        if (errorAgendado) {
          console.error('Erro ao deletar disparo agendado:', errorAgendado);
          throw errorAgendado;
        }
        console.log('disparo_agendado deletado com sucesso');

        // Atualizar estado local removendo o item deletado
        setDisparosAgendados(prevAgendados => prevAgendados.filter(d => d.id !== disparoId));
      }

      toast({
        title: "Sucesso",
        description: "Disparo removido com sucesso"
      });

    } catch (error) {
      console.error('Erro ao deletar disparo individual:', error);
      toast({
        title: "Erro",
        description: `Erro ao remover disparo: ${error.message || 'Erro desconhecido'}`,
        variant: "destructive"
      });
    }
  }, [user?.id, toast]);

  const criarAgendamento = useCallback(async () => {
    try {
      if (!agendamentoForm.conteudo.trim()) {
        toast({
          title: "Erro",
          description: "Conteúdo da mensagem é obrigatório",
          variant: "destructive"
        });
        return;
      }

      if (!agendamentoForm.data_agendada || !agendamentoForm.hora_agendada) {
        toast({
          title: "Erro",
          description: "Data e hora são obrigatórias",
          variant: "destructive"
        });
        return;
      }

      const dataAgendada = new Date(`${agendamentoForm.data_agendada}T${agendamentoForm.hora_agendada}`);
      
      if (dataAgendada <= new Date()) {
        toast({
          title: "Erro",
          description: "Data e hora devem ser futuras",
          variant: "destructive"
        });
        return;
      }

      // Buscar todos os leads verificados do usuário
      const { data: leads, error: errorLeads } = await supabase
        .from('leads')
        .select('*')
        .eq('user_id', user?.id)
        .eq('verificado', true);

      if (errorLeads) {
        console.error('Erro ao buscar leads:', errorLeads);
        throw errorLeads;
      }

      if (!leads || leads.length === 0) {
        toast({
          title: "Erro",
          description: "Nenhum lead verificado encontrado para agendamento",
          variant: "destructive"
        });
        return;
      }

      const novoAgendamento = {
        user_id: user?.id,
        conteudo: agendamentoForm.conteudo,
        data_agendada: dataAgendada.toISOString(),
        leads_selecionados: leads,
        status: 'agendado'
      };

      const { error } = await supabase
        .from('disparos_agendados')
        .insert([novoAgendamento]);

      if (error) {
        console.error('Erro ao criar agendamento:', error);
        throw error;
      }

      toast({
        title: "Sucesso",
        description: `Agendamento criado para ${leads.length} leads`
      });

      setShowAgendamentoDialog(false);
      setAgendamentoForm({ conteudo: '', data_agendada: '', hora_agendada: '' });
      await fetchDisparosAgendados();
    } catch (error) {
      console.error('Erro ao criar agendamento:', error);
      toast({
        title: "Erro",
        description: "Erro ao criar agendamento",
        variant: "destructive"
      });
    }
  }, [agendamentoForm, user?.id, fetchDisparosAgendados, toast]);

  const reagendarDisparo = useCallback(async () => {
    try {
      if (!disparoParaReagendar) return;

      if (!agendamentoForm.data_agendada || !agendamentoForm.hora_agendada) {
        toast({
          title: "Erro",
          description: "Data e hora são obrigatórias",
          variant: "destructive"
        });
        return;
      }

      const dataAgendada = new Date(`${agendamentoForm.data_agendada}T${agendamentoForm.hora_agendada}`);
      
      if (dataAgendada <= new Date()) {
        toast({
          title: "Erro",
          description: "Data e hora devem ser futuras",
          variant: "destructive"
        });
        return;
      }

      // Buscar os leads que foram enviados com sucesso neste disparo
      const leadsEnviados = disparoParaReagendar.leads_detalhes?.filter(lead => lead.status === 'enviado') || [];

      if (leadsEnviados.length === 0) {
        toast({
          title: "Erro",
          description: "Nenhum lead foi enviado com sucesso neste disparo",
          variant: "destructive"
        });
        return;
      }

      // Buscar dados completos dos leads no banco
      const leadIds = leadsEnviados.map(lead => lead.lead_id);
      const { data: leadsCompletos, error: errorLeads } = await supabase
        .from('leads')
        .select('*')
        .in('id', leadIds);

      if (errorLeads) {
        console.error('Erro ao buscar leads completos:', errorLeads);
        throw errorLeads;
      }

      const novoAgendamento = {
        user_id: user?.id,
        conteudo: disparoParaReagendar.conteudo,
        data_agendada: dataAgendada.toISOString(),
        leads_selecionados: leadsCompletos || [],
        status: 'agendado',
        imagem_url: disparoParaReagendar.imagem_url
      };

      const { error } = await supabase
        .from('disparos_agendados')
        .insert([novoAgendamento]);

      if (error) {
        console.error('Erro ao reagendar disparo:', error);
        throw error;
      }

      toast({
        title: "Sucesso",
        description: `Disparo reagendado para ${leadsCompletos?.length || 0} leads`
      });

      setShowReagendamentoDialog(false);
      setDisparoParaReagendar(null);
      setAgendamentoForm({ conteudo: '', data_agendada: '', hora_agendada: '' });
      await fetchDisparosAgendados();
    } catch (error) {
      console.error('Erro ao reagendar disparo:', error);
      toast({
        title: "Erro",
        description: "Erro ao reagendar disparo",
        variant: "destructive"
      });
    }
  }, [disparoParaReagendar, agendamentoForm, user?.id, fetchDisparosAgendados, toast]);

  const cancelarAgendamento = useCallback(async (agendamentoId: string) => {
    try {
      console.log('Cancelando agendamento:', agendamentoId);
      
      const { error } = await supabase
        .from('disparos_agendados')
        .update({ status: 'cancelado' })
        .eq('id', agendamentoId)
        .eq('user_id', user?.id);

      if (error) {
        console.error('Erro ao cancelar agendamento:', error);
        toast({
          title: "Erro",
          description: "Erro ao cancelar agendamento",
          variant: "destructive"
        });
        return;
      }

      toast({
        title: "Sucesso",
        description: "Agendamento cancelado com sucesso"
      });
      
      await fetchDisparosAgendados();
    } catch (error) {
      console.error('Erro ao cancelar agendamento:', error);
      toast({
        title: "Erro",
        description: "Erro ao cancelar agendamento",
        variant: "destructive"
      });
    }
  }, [user?.id, fetchDisparosAgendados, toast]);

  const abrirDialogoReagendamento = (disparo: DisparoMassa) => {
    setDisparoParaReagendar(disparo);
    setAgendamentoForm({
      conteudo: disparo.conteudo,
      data_agendada: '',
      hora_agendada: ''
    });
    setShowReagendamentoDialog(true);
  };

  const getStatusBadge = useCallback((status: string) => {
    switch (status) {
      case 'enviado':
        return <Badge className="bg-green-500 text-white"><CheckCircle className="h-3 w-3 mr-1" />Enviado</Badge>;
      case 'erro':
        return <Badge variant="destructive"><XCircle className="h-3 w-3 mr-1" />Erro</Badge>;
      case 'pendente':
        return <Badge variant="secondary"><Clock className="h-3 w-3 mr-1" />Pendente</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  }, []);

  const getDisparoStatusBadge = useCallback((status: string) => {
    switch (status) {
      case 'concluido':
        return <Badge className="bg-green-500 text-white">Concluído</Badge>;
      case 'em_andamento':
        return <Badge className="bg-blue-500 text-white">Em Andamento</Badge>;
      case 'erro':
        return <Badge variant="destructive">Erro</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  }, []);

  const getAgendadoStatusBadge = useCallback((status: string) => {
    switch (status) {
      case 'agendado':
        return <Badge className="bg-blue-500 text-white">Agendado</Badge>;
      case 'executado':
        return <Badge className="bg-green-500 text-white">Executado</Badge>;
      case 'cancelado':
        return <Badge variant="destructive">Cancelado</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  }, []);

  const getStatusColor = useCallback((enviados: number, total: number) => {
    const percentual = (enviados / total) * 100;
    if (percentual === 100) return 'text-green-600';
    if (percentual >= 80) return 'text-yellow-600';
    return 'text-red-600';
  }, []);

  const toggleExpandDisparo = (disparoId: string) => {
    setExpandedDisparo(expandedDisparo === disparoId ? null : disparoId);
  };

  useEffect(() => {
    if (user?.id) {
      fetchDisparos();
      fetchDisparosAgendados();
    }
  }, [user?.id, fetchDisparos, fetchDisparosAgendados]);

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  const hasAnyData = disparos.length > 0 || disparosAgendados.length > 0;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Histórico de Disparos</h2>
          <p className="text-gray-600">Visualize o histórico de todos os disparos realizados e agendados</p>
        </div>
        <div className="flex gap-2">
          <Dialog open={showAgendamentoDialog} onOpenChange={setShowAgendamentoDialog}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Agendar Disparo
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[425px]">
              <DialogHeader>
                <DialogTitle>Agendar Novo Disparo</DialogTitle>
                <DialogDescription>
                  Crie um agendamento para envio futuro para todos os leads verificados
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="conteudo">Conteúdo da Mensagem</Label>
                  <Textarea
                    id="conteudo"
                    value={agendamentoForm.conteudo}
                    onChange={(e) => setAgendamentoForm(prev => ({ ...prev, conteudo: e.target.value }))}
                    placeholder="Digite a mensagem que será enviada..."
                    rows={4}
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="data">Data</Label>
                    <Input
                      id="data"
                      type="date"
                      value={agendamentoForm.data_agendada}
                      onChange={(e) => setAgendamentoForm(prev => ({ ...prev, data_agendada: e.target.value }))}
                      min={new Date().toISOString().split('T')[0]}
                    />
                  </div>
                  <div>
                    <Label htmlFor="hora">Hora</Label>
                    <Input
                      id="hora"
                      type="time"
                      value={agendamentoForm.hora_agendada}
                      onChange={(e) => setAgendamentoForm(prev => ({ ...prev, hora_agendada: e.target.value }))}
                    />
                  </div>
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setShowAgendamentoDialog(false)}>
                  Cancelar
                </Button>
                <Button onClick={criarAgendamento}>
                  Criar Agendamento
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>

          <Dialog open={showReagendamentoDialog} onOpenChange={setShowReagendamentoDialog}>
            <DialogContent className="sm:max-w-[425px]">
              <DialogHeader>
                <DialogTitle>Reagendar Disparo</DialogTitle>
                <DialogDescription>
                  Reagende este disparo para ser enviado novamente para os leads que receberam com sucesso
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="conteudo-reagendar">Conteúdo da Mensagem</Label>
                  <Textarea
                    id="conteudo-reagendar"
                    value={agendamentoForm.conteudo}
                    onChange={(e) => setAgendamentoForm(prev => ({ ...prev, conteudo: e.target.value }))}
                    placeholder="Digite a mensagem que será enviada..."
                    rows={4}
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="data-reagendar">Data</Label>
                    <Input
                      id="data-reagendar"
                      type="date"
                      value={agendamentoForm.data_agendada}
                      onChange={(e) => setAgendamentoForm(prev => ({ ...prev, data_agendada: e.target.value }))}
                      min={new Date().toISOString().split('T')[0]}
                    />
                  </div>
                  <div>
                    <Label htmlFor="hora-reagendar">Hora</Label>
                    <Input
                      id="hora-reagendar"
                      type="time"
                      value={agendamentoForm.hora_agendada}
                      onChange={(e) => setAgendamentoForm(prev => ({ ...prev, hora_agendada: e.target.value }))}
                    />
                  </div>
                </div>
                {disparoParaReagendar && (
                  <div className="text-sm text-gray-600 bg-gray-50 p-3 rounded">
                    <strong>Será reagendado para:</strong> {disparoParaReagendar.leads_detalhes?.filter(l => l.status === 'enviado').length || 0} leads que receberam com sucesso
                  </div>
                )}
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => {
                  setShowReagendamentoDialog(false);
                  setDisparoParaReagendar(null);
                }}>
                  Cancelar
                </Button>
                <Button onClick={reagendarDisparo}>
                  Reagendar
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>

          {hasAnyData && (
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button variant="destructive">
                  <Trash2 className="h-4 w-4 mr-2" />
                  Limpar Todo Histórico
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Confirmar Limpeza Completa</AlertDialogTitle>
                  <AlertDialogDescription>
                    Tem certeza que deseja limpar TODO o histórico de disparos (executados e agendados)? Esta ação não pode ser desfeita.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancelar</AlertDialogCancel>
                  <AlertDialogAction 
                    onClick={limparHistoricoCompleto}
                    className="bg-red-600 hover:bg-red-700"
                  >
                    Limpar Todo Histórico
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          )}
        </div>
      </div>

      {/* Disparos Agendados */}
      {disparosAgendados.length > 0 && (
        <div className="space-y-4">
          <h3 className="text-lg font-semibold text-gray-900 flex items-center gap-2">
            <Calendar className="h-5 w-5" />
            Disparos Agendados ({disparosAgendados.length})
          </h3>
          {disparosAgendados.map((agendado) => (
            <Card key={agendado.id}>
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div className="flex-1">
                    <CardTitle className="flex items-center gap-2">
                      <Calendar className="h-5 w-5 text-blue-600" />
                      Agendado para {new Date(agendado.data_agendada).toLocaleString('pt-BR')}
                      {getAgendadoStatusBadge(agendado.status)}
                    </CardTitle>
                    <div className="flex items-center gap-4 mt-2">
                      <div className="flex items-center gap-1">
                        <Users className="h-4 w-4" />
                        <span className="text-sm font-medium">
                          {Array.isArray(agendado.leads_selecionados) ? agendado.leads_selecionados.length : 0} leads
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    {agendado.status === 'agendado' && (
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button variant="outline" size="sm">
                            Cancelar
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Cancelar Agendamento</AlertDialogTitle>
                            <AlertDialogDescription>
                              Tem certeza que deseja cancelar este agendamento?
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Não</AlertDialogCancel>
                            <AlertDialogAction onClick={() => cancelarAgendamento(agendado.id)}>
                              Sim, Cancelar
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    )}
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button variant="destructive" size="sm">
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>Remover Agendamento</AlertDialogTitle>
                          <AlertDialogDescription>
                            Tem certeza que deseja remover este agendamento do histórico?
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>Cancelar</AlertDialogCancel>
                          <AlertDialogAction 
                            onClick={() => deletarDisparoIndividual(agendado.id, 'agendado')}
                            className="bg-red-600 hover:bg-red-700"
                          >
                            Remover
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="bg-gray-50 p-4 rounded-lg">
                  <h4 className="font-medium mb-2">Conteúdo da Mensagem:</h4>
                  <p className="text-sm whitespace-pre-wrap">{agendado.conteudo}</p>
                  {agendado.imagem_url && (
                    <div className="mt-2">
                      <img 
                        src={agendado.imagem_url} 
                        alt="Imagem da mensagem" 
                        className="max-w-32 h-auto rounded border"
                      />
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Disparos Executados */}
      {disparos.length === 0 && disparosAgendados.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <TrendingUp className="h-12 w-12 text-gray-400 mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">
              Nenhum disparo encontrado
            </h3>
            <p className="text-gray-500 text-center">
              Quando você realizar disparos em massa ou agendar disparos, eles aparecerão aqui no histórico
            </p>
          </CardContent>
        </Card>
      ) : disparos.length > 0 && (
        <div className="space-y-4">
          <h3 className="text-lg font-semibold text-gray-900 flex items-center gap-2">
            <Send className="h-5 w-5" />
            Disparos Executados ({disparos.length})
          </h3>
          {disparos.map((disparo) => (
            <Card key={disparo.id}>
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div className="flex-1">
                    <CardTitle className="flex items-center gap-2">
                      <Send className="h-5 w-5 text-blue-600" />
                      Disparo de {new Date(disparo.data_inicio).toLocaleString('pt-BR')}
                      {getDisparoStatusBadge(disparo.status)}
                    </CardTitle>
                    <div className="flex items-center gap-4 mt-2">
                      <div className="flex items-center gap-1">
                        <Users className="h-4 w-4" />
                        <span className="text-sm font-medium">{disparo.total_leads} leads</span>
                      </div>
                      <div className={`text-sm font-medium ${getStatusColor(disparo.leads_enviados, disparo.total_leads)}`}>
                        {disparo.leads_enviados} enviados • {disparo.leads_erro} erros • {disparo.total_leads - disparo.leads_enviados - disparo.leads_erro} pendentes
                      </div>
                      {disparo.data_conclusao && (
                        <div className="text-sm text-gray-500">
                          <Clock className="h-4 w-4 inline mr-1" />
                          Concluído: {new Date(disparo.data_conclusao).toLocaleString('pt-BR')}
                        </div>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="text-right">
                      <div className={`text-2xl font-bold ${getStatusColor(disparo.leads_enviados, disparo.total_leads)}`}>
                        {Math.round((disparo.leads_enviados / disparo.total_leads) * 100)}%
                      </div>
                      <div className="text-sm text-gray-500">Taxa de sucesso</div>
                    </div>
                    <div className="flex flex-col gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => toggleExpandDisparo(disparo.id)}
                      >
                        {expandedDisparo === disparo.id ? 'Ocultar' : 'Ver'} Detalhes
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => abrirDialogoReagendamento(disparo)}
                        title="Reagendar este disparo"
                      >
                        <RotateCcw className="h-4 w-4" />
                      </Button>
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button variant="destructive" size="sm">
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Remover Disparo</AlertDialogTitle>
                            <AlertDialogDescription>
                              Tem certeza que deseja remover este disparo do histórico?
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Cancelar</AlertDialogCancel>
                            <AlertDialogAction 
                              onClick={() => deletarDisparoIndividual(disparo.id, 'massa')}
                              className="bg-red-600 hover:bg-red-700"
                            >
                              Remover
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                  </div>
                </div>
              </CardHeader>
              
              {expandedDisparo === disparo.id && (
                <CardContent className="space-y-4">
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h4 className="font-medium mb-2">Conteúdo da Mensagem:</h4>
                    <p className="text-sm whitespace-pre-wrap">{disparo.conteudo}</p>
                    {disparo.imagem_url && (
                      <div className="mt-2">
                        <img 
                          src={disparo.imagem_url} 
                          alt="Imagem da mensagem" 
                          className="max-w-32 h-auto rounded border"
                        />
                      </div>
                    )}
                  </div>

                  <div className="space-y-2">
                    <h4 className="font-medium">Destinatários ({disparo.leads_detalhes?.length || 0}):</h4>
                    <div className="max-h-60 overflow-y-auto space-y-2">
                      {disparo.leads_detalhes?.map((lead) => (
                        <div key={lead.id} className="flex items-center justify-between p-3 bg-white border rounded">
                          <div className="flex-1">
                            <p className="font-medium text-sm">{lead.nome}</p>
                            <p className="text-xs text-gray-500">{lead.telefone} - {lead.cidade}</p>
                            {lead.erro_detalhes && (
                              <p className="text-xs text-red-600 mt-1">{lead.erro_detalhes}</p>
                            )}
                          </div>
                          <div className="flex items-center gap-2">
                            {lead.data_processamento && (
                              <span className="text-xs text-gray-500">
                                {new Date(lead.data_processamento).toLocaleTimeString('pt-BR')}
                              </span>
                            )}
                            {getStatusBadge(lead.status)}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </CardContent>
              )}
            </Card>
          ))}
        </div>
      )}
    </div>
  );
};

export default HistoricoTab;
