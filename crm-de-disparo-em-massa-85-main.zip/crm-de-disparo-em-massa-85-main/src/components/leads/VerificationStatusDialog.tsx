
import { useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, XCircle, Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";

interface VerificationResults {
  verificados: any[];
  invalidos: any[];
  isLoading: boolean;
}

interface VerificationStatusDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  results: VerificationResults;
  onResultsUpdate: (updater: (prev: VerificationResults) => VerificationResults) => void;
}

const VerificationStatusDialog = ({ 
  open, 
  onOpenChange, 
  results, 
  onResultsUpdate 
}: VerificationStatusDialogProps) => {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  // Listener para o webhook de verificação via realtime
  useEffect(() => {
    if (!open || !user?.id) return;

    console.log('Configurando listener de realtime para verificação...');

    const channel = supabase
      .channel('verification-updates', {
        config: {
          broadcast: { self: false },
          presence: { key: user.id }
        }
      })
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'leads',
          filter: `user_id=eq.${user.id}`
        },
        (payload) => {
          console.log('Lead atualizado via webhook:', payload);
          
          const lead = payload.new;
          const oldLead = payload.old;
          
          // Verificar se houve mudança no status de verificação
          if (oldLead.verificado !== lead.verificado || oldLead.deleted_at !== lead.deleted_at) {
            // Se o lead foi verificado (mas não enviado)
            if (lead.verificado === true && !lead.deleted_at && lead.erro === null) {
              console.log('Lead verificado com sucesso:', lead);
              onResultsUpdate(prev => ({
                ...prev,
                verificados: [...prev.verificados.filter(l => l.id !== lead.id), lead],
                isLoading: false
              }));
            }
            
            // Se o lead foi marcado como inválido e movido para lixeira
            if (lead.deleted_at && lead.delete_reason && lead.delete_reason.includes('WhatsApp inexistente')) {
              console.log('Lead movido para lixeira:', lead);
              onResultsUpdate(prev => ({
                ...prev,
                invalidos: [...prev.invalidos.filter(l => l.id !== lead.id), lead],
                isLoading: false
              }));
            }
            
            // Invalidar cache para atualizar a lista
            queryClient.invalidateQueries({ queryKey: ['leads'] });
          }
        }
      )
      .subscribe((status) => {
        console.log('Status do canal realtime:', status);
        if (status === 'SUBSCRIBED') {
          console.log('Canal de verificação conectado com sucesso');
        }
      });

    return () => {
      console.log('Removendo listener de realtime...');
      supabase.removeChannel(channel);
    };
  }, [open, user?.id, onResultsUpdate, queryClient]);

  // Auto-fechar quando a verificação for concluída
  useEffect(() => {
    if (results.verificados.length > 0 || results.invalidos.length > 0) {
      console.log('Resultados recebidos:', {
        verificados: results.verificados.length,
        invalidos: results.invalidos.length
      });
      
      // Parar o loading
      onResultsUpdate(prev => ({ ...prev, isLoading: false }));
      
      // Mostrar toast com resultados
      const totalVerificados = results.verificados.length;
      const totalInvalidos = results.invalidos.length;
      
      if (totalVerificados > 0 || totalInvalidos > 0) {
        toast({
          title: "Verificação concluída",
          description: `${totalVerificados} contatos válidos, ${totalInvalidos} inválidos foram movidos para lixeira.`
        });
        
        // Fechar dialog após 3 segundos
        setTimeout(() => {
          onOpenChange(false);
        }, 3000);
      }
    }
  }, [results.verificados.length, results.invalidos.length, onResultsUpdate, toast, onOpenChange]);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Status da Verificação</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6">
          {results.isLoading && (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="h-8 w-8 animate-spin mr-3" />
              <span className="text-lg">Verificando contatos...</span>
            </div>
          )}
          
          {results.verificados.length > 0 && (
            <div>
              <h3 className="text-lg font-semibold mb-3 text-green-600 flex items-center">
                <CheckCircle className="h-5 w-5 mr-2" />
                Contatos Verificados ({results.verificados.length})
              </h3>
              <div className="space-y-2 max-h-48 overflow-y-auto">
                {results.verificados.map((lead, index) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                    <div>
                      <span className="font-medium">{lead.nome}</span>
                      <span className="text-sm text-gray-600 ml-2">{lead.telefone}</span>
                    </div>
                    <Badge variant="secondary" className="bg-green-100 text-green-800">
                      Verificado
                    </Badge>
                  </div>
                ))}
              </div>
            </div>
          )}
          
          {results.invalidos.length > 0 && (
            <div>
              <h3 className="text-lg font-semibold mb-3 text-red-600 flex items-center">
                <XCircle className="h-5 w-5 mr-2" />
                Contatos Inválidos ({results.invalidos.length})
              </h3>
              <div className="space-y-2 max-h-48 overflow-y-auto">
                {results.invalidos.map((lead, index) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-red-50 rounded-lg">
                    <div>
                      <span className="font-medium">{lead.nome}</span>
                      <span className="text-sm text-gray-600 ml-2">{lead.telefone}</span>
                    </div>
                    <Badge variant="destructive">
                      Movido para Lixeira
                    </Badge>
                  </div>
                ))}
              </div>
            </div>
          )}
          
          {!results.isLoading && results.verificados.length === 0 && results.invalidos.length === 0 && (
            <div className="text-center py-8 text-gray-500">
              Aguardando resultados da verificação...
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default VerificationStatusDialog;
