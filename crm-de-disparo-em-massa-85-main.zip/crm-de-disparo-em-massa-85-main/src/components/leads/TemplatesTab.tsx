import { useState, useRef } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { FileText, Plus, Trash2, Edit } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import TemplateVariables from "./templates/TemplateVariables";
import PredefinedTemplates from "./templates/PredefinedTemplates";

const TemplatesTab = () => {
  const [isEditing, setIsEditing] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    nome: "",
    conteudo: "",
    imagem_url: ""
  });
  const conteudoRef = useRef<HTMLTextAreaElement>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { user } = useAuth();

  const { data: templates = [], isLoading } = useQuery({
    queryKey: ['templates', user?.id],
    queryFn: async () => {
      if (!user?.id) {
        return [];
      }

      const { data, error } = await supabase
        .from('templates_mensagens')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      console.log('Templates carregados no TemplatesTab:', data);
      return data || [];
    },
    enabled: !!user?.id
  });

  const saveMutation = useMutation({
    mutationFn: async (templateData: any) => {
      if (!user?.id) {
        throw new Error('Usuário não autenticado');
      }

      const dataToSave = {
        ...templateData,
        user_id: user.id
      };

      if (editingId) {
        const { error } = await supabase
          .from('templates_mensagens')
          .update({
            ...dataToSave,
            updated_at: new Date().toISOString()
          })
          .eq('id', editingId)
          .eq('user_id', user.id);
        if (error) throw error;
      } else {
        const { error } = await supabase
          .from('templates_mensagens')
          .insert([dataToSave]);
        if (error) throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['templates'] });
      queryClient.invalidateQueries({ queryKey: ['message-templates'] });
      resetForm();
      toast({
        title: "Sucesso",
        description: editingId ? "Template atualizado!" : "Template criado!"
      });
    },
    onError: (error: any) => {
      console.error('Erro ao salvar template:', error);
      toast({
        title: "Erro",
        description: "Erro ao salvar template",
        variant: "destructive"
      });
    }
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      if (!user?.id) {
        throw new Error('Usuário não autenticado');
      }

      const { error } = await supabase
        .from('templates_mensagens')
        .delete()
        .eq('id', id)
        .eq('user_id', user.id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['templates'] });
      queryClient.invalidateQueries({ queryKey: ['message-templates'] });
      toast({
        title: "Sucesso",
        description: "Template excluído!"
      });
    },
    onError: (error: any) => {
      console.error('Erro ao excluir template:', error);
      toast({
        title: "Erro",
        description: "Erro ao excluir template",
        variant: "destructive"
      });
    }
  });

  const resetForm = () => {
    setFormData({ nome: "", conteudo: "", imagem_url: "" });
    setIsEditing(false);
    setEditingId(null);
  };

  const handleEdit = (template: any) => {
    setFormData({
      nome: template.nome,
      conteudo: template.conteudo,
      imagem_url: template.imagem_url || ""
    });
    setEditingId(template.id);
    setIsEditing(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.nome.trim() || !formData.conteudo.trim()) {
      toast({
        title: "Erro",
        description: "Nome e conteúdo são obrigatórios",
        variant: "destructive"
      });
      return;
    }

    if (!user?.id) {
      toast({
        title: "Erro",
        description: "Usuário não autenticado",
        variant: "destructive"
      });
      return;
    }

    saveMutation.mutate(formData);
  };

  const handleVariableClick = (variable: string) => {
    if (conteudoRef.current) {
      const textarea = conteudoRef.current;
      const start = textarea.selectionStart;
      const end = textarea.selectionEnd;
      const currentText = formData.conteudo;
      const newText = currentText.substring(0, start) + variable + currentText.substring(end);
      
      setFormData(prev => ({ ...prev, conteudo: newText }));
      
      // Reposicionar cursor após a variável inserida
      setTimeout(() => {
        textarea.focus();
        textarea.setSelectionRange(start + variable.length, start + variable.length);
      }, 0);
    }
  };

  const handlePredefinedTemplateSelect = (template: { nome: string; conteudo: string }) => {
    setFormData(prev => ({
      ...prev,
      nome: template.nome,
      conteudo: template.conteudo
    }));
    toast({
      title: "Template aplicado",
      description: `Template "${template.nome}" foi carregado para edição`
    });
  };

  if (!user?.id) {
    return (
      <div className="flex items-center justify-center p-8">
        <p className="text-gray-500">Faça login para gerenciar templates</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <PredefinedTemplates onTemplateSelect={handlePredefinedTemplateSelect} />
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Plus className="h-5 w-5" />
              {isEditing ? "Editar Template" : "Novo Template"}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="nome">Nome do Template *</Label>
                <Input
                  id="nome"
                  value={formData.nome}
                  onChange={(e) => setFormData(prev => ({ ...prev, nome: e.target.value }))}
                  placeholder="Ex: Mensagem de Boas-vindas"
                  required
                />
              </div>

              <TemplateVariables onVariableClick={handleVariableClick} />

              <div>
                <Label htmlFor="conteudo">Conteúdo da Mensagem *</Label>
                <Textarea
                  ref={conteudoRef}
                  id="conteudo"
                  value={formData.conteudo}
                  onChange={(e) => setFormData(prev => ({ ...prev, conteudo: e.target.value }))}
                  placeholder="Olá {{nome}}, seja bem-vindo! Você está em {{cidade}}..."
                  rows={8}
                  required
                />
              </div>

              <div>
                <Label htmlFor="imagem_url">URL da Imagem (opcional)</Label>
                <Input
                  id="imagem_url"
                  type="url"
                  value={formData.imagem_url}
                  onChange={(e) => setFormData(prev => ({ ...prev, imagem_url: e.target.value }))}
                  placeholder="https://exemplo.com/imagem.jpg"
                />
              </div>

              <div className="flex gap-2">
                <Button 
                  type="submit" 
                  disabled={saveMutation.isPending}
                  className="flex-1"
                >
                  {saveMutation.isPending ? "Salvando..." : (isEditing ? "Atualizar" : "Criar Template")}
                </Button>
                {isEditing && (
                  <Button 
                    type="button" 
                    variant="outline"
                    onClick={resetForm}
                  >
                    Cancelar
                  </Button>
                )}
              </div>
            </form>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5" />
              Templates Salvos ({templates.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="text-center py-8">Carregando templates...</div>
            ) : templates.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                <FileText className="h-12 w-12 mx-auto mb-4 text-gray-400" />
                <p className="mb-2">Nenhum template criado ainda</p>
                <p className="text-sm">Crie seu primeiro template para usar nos disparos</p>
              </div>
            ) : (
              <div className="space-y-4">
                {templates.map((template) => (
                  <div key={template.id} className="border rounded-lg p-4">
                    <div className="flex items-start justify-between mb-2">
                      <h3 className="font-medium">{template.nome}</h3>
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleEdit(template)}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          size="sm"
                          variant="destructive"
                          onClick={() => deleteMutation.mutate(template.id)}
                          disabled={deleteMutation.isPending}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                    
                    <p className="text-gray-600 text-sm mb-2">
                      {template.conteudo.length > 150 
                        ? template.conteudo.substring(0, 150) + '...'
                        : template.conteudo
                      }
                    </p>
                    
                    {template.imagem_url && (
                      <p className="text-blue-600 text-xs">
                        📷 Imagem anexada
                      </p>
                    )}
                    
                    <p className="text-gray-400 text-xs mt-2">
                      Criado em: {new Date(template.created_at).toLocaleString('pt-BR')}
                    </p>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default TemplatesTab;
