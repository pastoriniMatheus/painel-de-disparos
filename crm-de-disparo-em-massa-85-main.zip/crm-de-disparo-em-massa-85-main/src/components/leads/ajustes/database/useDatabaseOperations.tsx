
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";

interface DatabaseConfig {
  url: string;
  anonKey: string;
  serviceKey: string;
}

export const useDatabaseOperations = () => {
  const [isConnecting, setIsConnecting] = useState(false);
  const [isBackingUp, setIsBackingUp] = useState(false);
  const [isRestoring, setIsRestoring] = useState(false);
  const { toast } = useToast();

  // Configuração atual do Supabase (obtida do client)
  const currentConfig: DatabaseConfig = {
    url: "https://brwapytjhitzurfnpfsz.supabase.co",
    anonKey: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJyd2FweXRqaGl0enVyZm5wZnN6Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDg2MTY4NTUsImV4cCI6MjA2NDE5Mjg1NX0.HFzi6CO41Bf4YcRZ88YmMhcJvH2sZcOpoPtd1zUorLQ",
    serviceKey: "" // Será preenchido pelo usuário se necessário
  };

  const testConnection = async (config: DatabaseConfig) => {
    setIsConnecting(true);
    try {
      // Criar um cliente temporário para testar a conexão
      const { createClient } = await import('@supabase/supabase-js');
      const testClient = createClient(config.url, config.anonKey);
      
      // Tentar fazer uma consulta simples para testar
      const { error } = await testClient.from('profiles').select('count', { count: 'exact', head: true });
      
      if (error) {
        throw error;
      }

      toast({
        title: "Sucesso",
        description: "Conexão com o banco de dados estabelecida com sucesso!"
      });
      
      return true;
    } catch (error: any) {
      toast({
        title: "Erro de Conexão",
        description: `Falha ao conectar: ${error.message}`,
        variant: "destructive"
      });
      return false;
    } finally {
      setIsConnecting(false);
    }
  };

  const downloadBackup = async () => {
    setIsBackingUp(true);
    try {
      // Lista das tabelas principais para backup
      const tables = [
        'profiles',
        'leads',
        'instancias_whatsapp',
        'configuracoes',
        'templates_mensagens',
        'historico_disparos',
        'disparos_agendados',
        'appearance_settings'
      ] as const;

      const backupData: any = {
        timestamp: new Date().toISOString(),
        version: "1.0",
        tables: {}
      };

      // Fazer backup de cada tabela
      for (const table of tables) {
        try {
          const { data, error } = await supabase.from(table).select('*');
          if (error) {
            console.warn(`Erro ao fazer backup da tabela ${table}:`, error);
            continue;
          }
          backupData.tables[table] = data;
        } catch (error) {
          console.warn(`Erro ao acessar tabela ${table}:`, error);
        }
      }

      // Converter para JSON e fazer download
      const jsonString = JSON.stringify(backupData, null, 2);
      const blob = new Blob([jsonString], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      
      const link = document.createElement('a');
      link.href = url;
      link.download = `backup_supabase_${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
      URL.revokeObjectURL(url);

      toast({
        title: "Backup Concluído",
        description: "Backup do banco de dados baixado com sucesso!"
      });

    } catch (error: any) {
      toast({
        title: "Erro no Backup",
        description: `Falha ao criar backup: ${error.message}`,
        variant: "destructive"
      });
    } finally {
      setIsBackingUp(false);
    }
  };

  const uploadBackup = async (file: File, targetConfig?: DatabaseConfig) => {
    setIsRestoring(true);
    try {
      const text = await file.text();
      const backupData = JSON.parse(text);

      if (!backupData.tables) {
        throw new Error("Arquivo de backup inválido");
      }

      // Usar configuração atual ou a fornecida
      const clientToUse = targetConfig ? 
        await import('@supabase/supabase-js').then(({ createClient }) => 
          createClient(targetConfig.url, targetConfig.serviceKey || targetConfig.anonKey)
        ) : supabase;

      let restoredTables = 0;
      let totalTables = Object.keys(backupData.tables).length;

      // Lista das tabelas válidas para restauração
      const validTables = [
        'profiles',
        'leads',
        'instancias_whatsapp',
        'configuracoes',
        'templates_mensagens',
        'historico_disparos',
        'disparos_agendados',
        'appearance_settings'
      ] as const;

      // Restaurar cada tabela
      for (const [tableName, tableData] of Object.entries(backupData.tables)) {
        try {
          // Verificar se a tabela é válida
          if (!validTables.includes(tableName as any)) {
            console.warn(`Tabela ${tableName} não é válida, pulando...`);
            continue;
          }

          if (Array.isArray(tableData) && tableData.length > 0) {
            // Inserir dados em lotes
            const batchSize = 100;
            for (let i = 0; i < tableData.length; i += batchSize) {
              const batch = tableData.slice(i, i + batchSize);
              const { error } = await clientToUse.from(tableName as any).upsert(batch);
              if (error) {
                console.warn(`Erro ao restaurar lote da tabela ${tableName}:`, error);
              }
            }
            restoredTables++;
          }
        } catch (error) {
          console.warn(`Erro ao restaurar tabela ${tableName}:`, error);
        }
      }

      toast({
        title: "Restauração Concluída",
        description: `${restoredTables}/${totalTables} tabelas restauradas com sucesso!`
      });

    } catch (error: any) {
      toast({
        title: "Erro na Restauração",
        description: `Falha ao restaurar backup: ${error.message}`,
        variant: "destructive"
      });
    } finally {
      setIsRestoring(false);
    }
  };

  return {
    currentConfig,
    isConnecting,
    isBackingUp,
    isRestoring,
    testConnection,
    downloadBackup,
    uploadBackup
  };
};
