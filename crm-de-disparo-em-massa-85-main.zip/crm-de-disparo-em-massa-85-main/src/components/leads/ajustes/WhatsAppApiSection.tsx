
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useWhatsAppApiConfig } from "./hooks/useWhatsAppApiConfig";
import { useInstancesManager } from "./hooks/useInstancesManager";
import WhatsAppApiConfiguration from "./WhatsAppApiConfiguration";
import InstancesList from "./InstancesList";

const WhatsAppApiSection = () => {
  const {
    urlApi,
    setUrlApi,
    tokenApi,
    setTokenApi,
    salvarConfiguracoes
  } = useWhatsAppApiConfig();

  const {
    instancias,
    listarInstancias,
    criarInstancia,
    adicionarInstancia,
    isListing
  } = useInstancesManager();

  const handleListInstances = () => {
    listarInstancias(urlApi, tokenApi);
  };

  const handleCreateInstance = (nomeInstancia: string) => {
    criarInstancia({ urlApi, tokenApi }, nomeInstancia);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Configuração da Evolution API</CardTitle>
      </CardHeader>
      <CardContent>
        <WhatsAppApiConfiguration
          urlApi={urlApi}
          setUrlApi={setUrlApi}
          tokenApi={tokenApi}
          setTokenApi={setTokenApi}
          onSave={salvarConfiguracoes}
          onList={handleListInstances}
          isListing={isListing}
        />
        
        <InstancesList
          instances={instancias}
          onAddInstance={adicionarInstancia}
          onCreateInstance={handleCreateInstance}
        />
      </CardContent>
    </Card>
  );
};

export default WhatsAppApiSection;
