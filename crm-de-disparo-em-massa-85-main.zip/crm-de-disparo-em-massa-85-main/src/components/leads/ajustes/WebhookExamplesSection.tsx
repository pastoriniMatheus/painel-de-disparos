
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { FileText } from "lucide-react";

const WebhookExamplesSection = () => {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <FileText className="h-5 w-5" />
          Exemplos de Dados dos Webhooks
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          <div>
            <h4 className="font-medium mb-2 text-blue-600">Webhook de Envio:</h4>
            <p className="text-sm text-gray-600 mb-2">Enviado quando mensagens são disparadas para os leads:</p>
            <pre className="text-xs bg-gray-50 p-3 rounded border overflow-x-auto">
{`{
  "event": "message_sent",
  "timestamp": "2024-01-01T12:00:00Z",
  "data": [
    {
      "nome": "João Silva",
      "telefone": "82999998888",
      "lead_id": "uuid-do-lead"
    }
  ],
  "conteudo": "Mensagem personalizada",
  "imagem_url": "https://exemplo.com/imagem.jpg",
  "user_id": "uuid-do-usuario"
}`}
            </pre>
          </div>
          
          <div>
            <h4 className="font-medium mb-2 text-green-600">Webhook de Verificação:</h4>
            <p className="text-sm text-gray-600 mb-2">Enviado para verificar status de leads específicos:</p>
            <pre className="text-xs bg-gray-50 p-3 rounded border overflow-x-auto">
{`{
  "event": "lead_verification",
  "timestamp": "2024-01-01T12:00:00Z",
  "data": [
    {
      "id": "uuid-do-lead",
      "nome": "João Silva",
      "telefone": "82999998888",
      "cidade": "Maceió",
      "categoria": "Imóveis"
    }
  ],
  "user_id": "uuid-do-usuario"
}`}
            </pre>
          </div>
          
          <div>
            <h4 className="font-medium mb-2 text-purple-600">Webhook de Verificação de Instância:</h4>
            <p className="text-sm text-gray-600 mb-2">Enviado automaticamente a cada 2 minutos para verificar status das instâncias WhatsApp:</p>
            <pre className="text-xs bg-gray-50 p-3 rounded border overflow-x-auto">
{`{
  "event": "instance_check",
  "timestamp": "2024-01-01T12:00:00Z",
  "action": "verify_instances",
  "user_id": "uuid-do-usuario",
  "instances": [
    {
      "id": "uuid-da-instancia",
      "nome": "Instância Principal",
      "status": "conectado"
    }
  ]
}`}
            </pre>
          </div>

          <div className="bg-yellow-50 p-4 rounded-lg">
            <h5 className="font-medium text-yellow-800 mb-2">📝 Resposta Esperada dos Webhooks:</h5>
            <p className="text-sm text-yellow-700">
              Todos os webhooks devem retornar status HTTP 200 para confirmar o recebimento. 
              Caso contrário, o sistema pode tentar reenviar a notificação.
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default WebhookExamplesSection;
