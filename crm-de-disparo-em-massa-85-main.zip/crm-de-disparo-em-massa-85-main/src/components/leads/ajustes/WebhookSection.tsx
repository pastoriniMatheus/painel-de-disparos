
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Webhook, Save, Loader2 } from "lucide-react";
import WebhookField from "./webhook/WebhookField";
import InstanceVerificationSettings from "./webhook/InstanceVerificationSettings";
import { useWebhookConfig } from "./webhook/useWebhookConfig";

const WebhookSection = () => {
  const {
    webhookEnvio,
    setWebhookEnvio,
    webhookVerificacao,
    setWebhookVerificacao,
    webhookVerificacaoInstancia,
    setWebhookVerificacaoInstancia,
    verificacaoAutomaticaHabilitada,
    setVerificacaoAutomaticaHabilitada,
    minutosVerificacao,
    setMinutosVerificacao,
    isSaving,
    isTesting,
    isLoading,
    handleSave,
    handleTest
  } = useWebhookConfig();

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Webhook className="h-5 w-5" />
            Configuração de Webhooks
          </CardTitle>
        </CardHeader>
        <CardContent className="flex items-center justify-center py-8">
          <div className="flex items-center gap-2 text-gray-500">
            <Loader2 className="h-4 w-4 animate-spin" />
            Carregando configurações...
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Webhook className="h-5 w-5" />
          Configuração de Webhooks
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="bg-blue-50 p-4 rounded-lg">
          <p className="text-sm text-blue-700">
            Configure URLs para receber notificações de disparos, verificações e outros eventos do sistema.
          </p>
        </div>

        <div className="space-y-4">
          <WebhookField
            id="webhook-envio"
            label="URL do Webhook de Envio"
            placeholder="https://api.seusite.com/webhook/envio"
            description="URL que receberá notificações quando mensagens forem enviadas"
            value={webhookEnvio}
            onChange={setWebhookEnvio}
            onTest={() => handleTest(webhookEnvio, 'envio')}
            isTesting={isTesting === 'envio'}
            testType="envio"
          />

          <WebhookField
            id="webhook-verificacao"
            label="URL do Webhook de Verificação"
            placeholder="https://api.seusite.com/webhook/verificacao"
            description="URL que receberá verificações de status dos leads"
            value={webhookVerificacao}
            onChange={setWebhookVerificacao}
            onTest={() => handleTest(webhookVerificacao, 'verificacao')}
            isTesting={isTesting === 'verificacao'}
            testType="verificacao"
          />

          <div>
            <WebhookField
              id="webhook-verificacao-instancia"
              label="URL do Webhook de Verificação de Instância"
              placeholder="https://api.seusite.com/webhook/instancia"
              description="URL para onde será enviado um POST para verificar status das instâncias"
              value={webhookVerificacaoInstancia}
              onChange={setWebhookVerificacaoInstancia}
              onTest={() => handleTest(webhookVerificacaoInstancia, 'instancia')}
              isTesting={isTesting === 'instancia'}
              testType="instancia"
            />
            
            <InstanceVerificationSettings
              verificacaoAutomaticaHabilitada={verificacaoAutomaticaHabilitada}
              setVerificacaoAutomaticaHabilitada={setVerificacaoAutomaticaHabilitada}
              minutosVerificacao={minutosVerificacao}
              setMinutosVerificacao={setMinutosVerificacao}
            />
          </div>
        </div>

        <div className="flex gap-2 pt-4 border-t">
          <Button 
            onClick={handleSave}
            disabled={isSaving}
            className="flex-1"
          >
            {isSaving ? (
              <>
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                Salvando...
              </>
            ) : (
              <>
                <Save className="h-4 w-4 mr-2" />
                Salvar Configurações
              </>
            )}
          </Button>
        </div>

        {/* Debug info - remover em produção */}
        <div className="text-xs text-gray-400 mt-4 p-2 bg-gray-50 rounded">
          <p>Debug: Webhook Envio = {webhookEnvio || 'vazio'}</p>
          <p>Debug: Webhook Verificação = {webhookVerificacao || 'vazio'}</p>
          <p>Debug: Webhook Instância = {webhookVerificacaoInstancia || 'vazio'}</p>
        </div>
      </CardContent>
    </Card>
  );
};

export default WebhookSection;
