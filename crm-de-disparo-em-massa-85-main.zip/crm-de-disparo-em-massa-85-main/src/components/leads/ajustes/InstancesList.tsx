
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Plus, Smartphone, User, Key } from "lucide-react";
import { useState } from "react";

interface Instance {
  mappedName: string;
  mappedStatus: string;
  mappedPhone: string;
  originalStatus: string;
  apikey?: string;
  instance: any;
}

interface InstancesListProps {
  instances: Instance[];
  onAddInstance: (instance: Instance) => void;
  onCreateInstance: (name: string) => void;
}

const InstancesList = ({ instances, onAddInstance, onCreateInstance }: InstancesListProps) => {
  const [newInstanceName, setNewInstanceName] = useState("");

  const getStatusBadgeVariant = (status: string) => {
    switch (status.toLowerCase()) {
      case 'conectado':
        return 'default';
      case 'conectando':
        return 'secondary';
      default:
        return 'destructive';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case 'conectado':
        return 'text-green-600';
      case 'conectando':
        return 'text-yellow-600';
      default:
        return 'text-red-600';
    }
  };

  const handleCreateInstance = () => {
    if (!newInstanceName.trim()) return;
    onCreateInstance(newInstanceName.trim());
    setNewInstanceName("");
  };

  return (
    <div className="space-y-6">
      {instances.length > 0 && (
        <div>
          <h3 className="text-lg font-medium mb-4">Instâncias Encontradas</h3>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {instances.map((instance, index) => (
              <Card key={index} className="relative">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg flex items-center gap-2">
                      <Smartphone className="h-4 w-4" />
                      {instance.mappedName}
                    </CardTitle>
                    <Badge variant={getStatusBadgeVariant(instance.mappedStatus)}>
                      {instance.mappedStatus}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="text-sm">
                    <span className="text-gray-500">Status:</span>
                    <div className={`font-medium ${getStatusColor(instance.mappedStatus)}`}>
                      {instance.mappedStatus}
                    </div>
                    <div className="text-xs text-gray-400">
                      API: {instance.originalStatus}
                    </div>
                  </div>

                  {instance.mappedPhone && (
                    <div className="text-sm">
                      <span className="text-gray-500 flex items-center gap-1">
                        <User className="h-3 w-3" />
                        Telefone:
                      </span>
                      <div className="font-mono text-xs">
                        {instance.mappedPhone}
                      </div>
                    </div>
                  )}

                  {instance.apikey && (
                    <div className="text-sm">
                      <span className="text-gray-500 flex items-center gap-1">
                        <Key className="h-3 w-3" />
                        API Key:
                      </span>
                      <div className="font-mono text-xs bg-gray-100 p-1 rounded truncate">
                        {instance.apikey.substring(0, 20)}...
                      </div>
                    </div>
                  )}

                  <Button
                    onClick={() => onAddInstance(instance)}
                    className="w-full"
                    size="sm"
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Adicionar ao Sistema
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      <Card>
        <CardHeader>
          <CardTitle>Criar Nova Instância</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="instanceName">Nome da Instância</Label>
            <Input
              id="instanceName"
              value={newInstanceName}
              onChange={(e) => setNewInstanceName(e.target.value)}
              placeholder="Digite o nome da nova instância"
            />
          </div>
          <Button 
            onClick={handleCreateInstance}
            disabled={!newInstanceName.trim()}
            className="w-full"
          >
            <Plus className="h-4 w-4 mr-2" />
            Criar Instância
          </Button>
        </CardContent>
      </Card>
    </div>
  );
};

export default InstancesList;
