
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useInstanceListing } from "./useInstanceListing";
import { useInstanceCreation } from "./useInstanceCreation";
import { statusMapper } from "@/components/whatsapp/utils/statusMapper";

export const useInstancesManager = () => {
  const [instancias, setInstancias] = useState<any[]>([]);
  const { toast } = useToast();
  const { user } = useAuth();
  const { listarInstanciasMutation } = useInstanceListing();
  const { criarInstanciaMutation } = useInstanceCreation();

  const listarInstancias = async (urlApi: string, tokenApi: string) => {
    if (!urlApi || !tokenApi) {
      toast({
        title: "Erro",
        description: "Preencha a URL da API e o Token antes de listar",
        variant: "destructive"
      });
      return;
    }

    try {
      console.log('Listando instâncias com:', { urlApi, tokenApi });
      
      const result = await listarInstanciasMutation.mutateAsync({
        urlApi,
        tokenApi
      });
      
      console.log('Resultado da listagem:', result);
      setInstancias(result || []);
    } catch (error) {
      console.error('Erro ao listar instâncias:', error);
      setInstancias([]);
    }
  };

  const criarInstancia = async (config: { urlApi: string; tokenApi: string }, nomeInstancia: string) => {
    if (!config.urlApi || !config.tokenApi) {
      toast({
        title: "Erro",
        description: "Configure a API antes de criar instâncias",
        variant: "destructive"
      });
      return;
    }

    try {
      await criarInstanciaMutation.mutateAsync({
        config,
        instanceName: nomeInstancia
      });
      
      // Recarregar lista após criar
      await listarInstancias(config.urlApi, config.tokenApi);
    } catch (error) {
      console.error('Erro ao criar instância:', error);
    }
  };

  const adicionarInstancia = async (instancia: any) => {
    if (!user?.id) {
      toast({
        title: "Erro",
        description: "Usuário não autenticado",
        variant: "destructive"
      });
      return;
    }

    try {
      const nomeInstancia = instancia.mappedName || instancia.instanceName || instancia.instanceId || 'Instância sem nome';
      const statusOriginalAPI = instancia.originalStatus;
      const apikey = instancia.apikey;
      
      console.log('📋 ADICIONANDO instância com dados COMPLETOS:', {
        nome: nomeInstancia,
        statusOriginalAPI: statusOriginalAPI,
        tipoStatusOriginal: typeof statusOriginalAPI,
        apikey: apikey ? 'presente' : 'ausente',
        objetoCompleto: JSON.stringify(instancia, null, 2)
      });
      
      // Verificar se a instância já existe
      const { data: existingInstance, error: checkError } = await supabase
        .from('instancias_whatsapp')
        .select('id')
        .eq('user_id', user.id)
        .eq('nome', nomeInstancia)
        .maybeSingle();

      if (checkError) {
        console.error('Erro ao verificar instância existente:', checkError);
        toast({
          title: "Erro",
          description: "Erro ao verificar instância",
          variant: "destructive"
        });
        return;
      }

      if (existingInstance) {
        toast({
          title: "Aviso",
          description: "Esta instância já foi adicionada",
          variant: "destructive"
        });
        return;
      }

      // GARANTIR que temos um status válido da API
      if (!statusOriginalAPI) {
        console.error('❌ ERRO CRÍTICO: Status original está undefined/null!');
        console.log('Objeto instancia completo:', JSON.stringify(instancia, null, 2));
        toast({
          title: "Erro",
          description: "Status da instância não encontrado na resposta da API",
          variant: "destructive"
        });
        return;
      }

      // Usar o statusMapper para garantir consistência
      const statusFinal = statusMapper.mapApiStatusToDatabase(statusOriginalAPI);
      
      console.log(`🔄 MAPEAMENTO FINAL: API "${statusOriginalAPI}" -> BANCO "${statusFinal}"`);

      // Criar objeto com tipo correto para inserção
      const insertData = {
        nome: nomeInstancia,
        status: statusFinal,
        quantidade_envios: 0,
        tempo_espera: 5,
        user_id: user.id,
        ...(apikey && { apikey: apikey })
      };

      console.log('💾 DADOS FINAIS para inserção no banco:', insertData);

      const { error } = await supabase
        .from('instancias_whatsapp')
        .insert(insertData);

      if (error) {
        console.error('❌ ERRO ao inserir no banco:', error);
        toast({
          title: "Erro",
          description: "Erro ao adicionar instância: " + error.message,
          variant: "destructive"
        });
        return;
      }

      console.log('✅ SUCESSO! Instância salva no banco com status:', statusFinal);
      toast({
        title: "Sucesso",
        description: `Instância "${nomeInstancia}" adicionada com status: ${statusFinal}`
      });
      
    } catch (error) {
      console.error('❌ ERRO GERAL ao adicionar instância:', error);
      toast({
        title: "Erro",
        description: "Erro inesperado ao adicionar instância",
        variant: "destructive"
      });
    }
  };

  return {
    instancias,
    listarInstancias,
    criarInstancia,
    adicionarInstancia,
    isListing: listarInstanciasMutation.isPending,
    isCreating: criarInstanciaMutation.isPending
  };
};
