
import { useMutation } from '@tanstack/react-query';
import { useToast } from '@/hooks/use-toast';
import { buildApiRequest, ApiConfig } from './utils/apiConfig';
import { processApiResponse } from './utils/responseProcessor';
import { handleApiError } from './utils/errorHandler';

export const useInstanceListing = () => {
  const { toast } = useToast();

  const listarInstanciasMutation = useMutation({
    mutationFn: async (config: ApiConfig) => {
      console.log('Iniciando listagem de instâncias Evolution API com config:', config);
      
      const { fullUrl, headers } = buildApiRequest(config);
      
      console.log('Fazendo requisição para:', fullUrl);
      console.log('Headers:', headers);

      try {
        const response = await fetch(fullUrl, {
          method: 'GET',
          headers,
          signal: AbortSignal.timeout(15000)
        });

        console.log('Resposta:', response.status, response.statusText);

        if (!response.ok) {
          const errorText = await response.text();
          console.error(`Erro HTTP ${response.status}:`, errorText);
          throw new Error(`HTTP ${response.status}: ${response.statusText || errorText}`);
        }

        const data = await response.json();
        console.log('Resposta bruta da Evolution API:', data);

        const { instancesWithCorrectStatus } = processApiResponse(data);
        
        console.log('Instâncias processadas finais:', instancesWithCorrectStatus);
        return instancesWithCorrectStatus;

      } catch (error: any) {
        if (error.name === 'AbortError') {
          throw new Error('Timeout: A API demorou muito para responder');
        }
        throw error;
      }
    },
    onSuccess: (data) => {
      console.log('Sucesso na listagem:', data);
      toast({
        title: "Sucesso",
        description: `${data?.length || 0} instância(s) encontrada(s)`
      });
    },
    onError: (error: any) => {
      const errorMessage = handleApiError(error);
      console.error('Erro final na listagem:', error);
      toast({
        title: "Erro",
        description: errorMessage,
        variant: "destructive"
      });
    }
  });

  return {
    listarInstanciasMutation
  };
};
