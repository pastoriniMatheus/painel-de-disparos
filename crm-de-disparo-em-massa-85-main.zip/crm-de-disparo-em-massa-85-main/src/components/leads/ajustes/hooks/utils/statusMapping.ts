
export const mapInstanceStatus = (apiStatus: string) => {
  console.log('Mapeando status da API:', apiStatus);
  const statusMap: { [key: string]: string } = {
    'open': 'Conectado',
    'close': 'Desconectado',
    'connecting': 'Conectando',
    'connected': 'Conectado',
    'disconnected': 'Desconectado',
    'qrcode': 'Aguardando QR',
    'closed': 'Desconectado'
  };
  const mappedStatus = statusMap[apiStatus?.toLowerCase()] || apiStatus || 'Desconhecido';
  console.log('Status mapeado:', mappedStatus);
  return mappedStatus;
};
