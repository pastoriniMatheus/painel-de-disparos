
export interface ApiConfig {
  urlApi: string;
  tokenApi: string;
}

export const buildApiRequest = ({ urlApi, tokenApi }: ApiConfig) => {
  // Normalizar URL
  const baseUrl = urlApi.endsWith('/') ? urlApi.slice(0, -1) : urlApi;
  
  // Evolution API - usar endpoint específico /instance/fetchInstances
  const fullUrl = `${baseUrl}/instance/fetchInstances`;

  // Headers para Evolution API - usar apikey conforme documentação
  const headers: Record<string, string> = {
    'apikey': tokenApi
  };

  console.log('Construindo requisição Evolution API:', { baseUrl, fullUrl, headers });

  return { fullUrl, headers, baseUrl };
};
