
export const extractInstanceInfo = (instanciaApi: any) => {
  console.log('🔍 Extraindo informações da instância:', JSON.stringify(instanciaApi, null, 2));
  
  let nomeInstancia = 'Instância';
  let statusInstancia = 'Desconhecido';
  let phone = '';
  
  // A resposta da Evolution API pode vir com diferentes estruturas
  const instance = instanciaApi.instance || instanciaApi;
  
  console.log('📊 Objeto instance extraído:', JSON.stringify(instance, null, 2));
  
  // Extrair nome da instância
  nomeInstancia = instance.instanceName || 
                 instance.name ||
                 instance.instanceId || 
                 instance.id ||
                 'Instância Sem Nome';

  // Extrair status - tentar diferentes campos possíveis
  let statusOriginal = instance.status || 
                      instance.connectionStatus || 
                      instance.state ||
                      'unknown';
  
  console.log(`📊 Status REAL extraído da API: "${statusOriginal}" (tipo: ${typeof statusOriginal})`);
  
  // Mapear status para exibição - manter valores exatos da API
  if (statusOriginal === 'open') {
    statusInstancia = 'Conectado';
  } else if (statusOriginal === 'close' || statusOriginal === 'closed') {
    statusInstancia = 'Desconectado';
  } else if (statusOriginal === 'connecting') {
    statusInstancia = 'Conectando';
  } else {
    statusInstancia = 'Desconhecido';
    console.log(`⚪ Status não reconhecido: "${statusOriginal}" -> Desconhecido`);
  }

  // Extrair telefone/owner
  phone = instance.owner || 
          instance.number || 
          instance.ownerJid?.replace('@s.whatsapp.net', '') || 
          '';
  
  // Extrair apikey
  const apikey = instance.apikey || instance.token || null;
  
  console.log('✅ Informações FINAIS extraídas:', { 
    nome: nomeInstancia, 
    statusMapeado: statusInstancia, 
    statusOriginal: statusOriginal,
    phone: phone,
    apikey: apikey ? 'presente' : 'ausente'
  });
  
  return { 
    nomeInstancia, 
    statusInstancia, 
    phone, 
    statusOriginal: statusOriginal, 
    apikey: apikey,
    instance: instance
  };
};
