
import { createSafeError } from '@/utils/errorHandling';

export const handleApiError = (error: any) => {
  console.error('Erro ao listar instâncias:', error);
  
  const safeError = createSafeError(error);
  let errorMessage = safeError.message;
  
  if (error.name === 'AbortError') {
    errorMessage = "Timeout: A API demorou muito para responder";
  } else if (error.message.includes('404')) {
    errorMessage = "Endpoint não encontrado. Verifique a URL e tipo de API";
  } else if (error.message.includes('401') || error.message.includes('403')) {
    errorMessage = "API Key inválida ou sem permissão";
  } else if (error.message.includes('CORS')) {
    errorMessage = "Erro de CORS. A API precisa permitir requisições do frontend";
  }
  
  return errorMessage;
};
