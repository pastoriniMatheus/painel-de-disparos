
import { extractInstanceInfo } from './instanceExtractor';

export const processApiResponse = (data: any) => {
  console.log('🔄 Processando resposta COMPLETA da Evolution API:', JSON.stringify(data, null, 2));
  
  // A Evolution API retorna um array de objetos, cada um com uma propriedade "instance"
  let instancesList = [];
  
  if (Array.isArray(data)) {
    instancesList = data;
    console.log(`📋 Encontrados ${instancesList.length} itens na resposta (array)`);
  } else if (data && typeof data === 'object') {
    // Se não for array, pode ser um objeto com propriedades
    console.log('📋 Resposta não é array, tentando extrair dados...');
    if (data.instances && Array.isArray(data.instances)) {
      instancesList = data.instances;
      console.log(`📋 Encontrados ${instancesList.length} itens em data.instances`);
    } else {
      console.warn('⚠️ Formato de resposta não reconhecido da Evolution API');
      instancesList = [];
    }
  } else {
    console.warn('⚠️ Resposta da API não é objeto nem array:', typeof data);
    instancesList = [];
  }

  console.log('📋 Lista de instâncias para processar:', instancesList.length);

  // Mapear as instâncias extraindo as informações corretas
  const instancesWithCorrectStatus = instancesList.map((item, index) => {
    console.log(`\n🔍 Processando item ${index + 1}/${instancesList.length}:`);
    console.log('   📋 Dados brutos do item:', JSON.stringify(item, null, 2));
    
    const { nomeInstancia, statusInstancia, phone, statusOriginal, apikey, instance } = extractInstanceInfo(item);
    
    const processedInstance = {
      ...item,
      mappedName: nomeInstancia,
      mappedStatus: statusInstancia,
      mappedPhone: phone,
      originalStatus: statusOriginal, // ESTE é o status real da API
      apikey: apikey,
      instance: instance,
      // Manter compatibilidade com código existente
      instanceName: nomeInstancia,
      instanceId: instance.instanceId || instance.id,
      status: statusOriginal // Status original da API para uso interno
    };

    console.log(`   ✅ Item ${index + 1} processado:`, {
      nome: processedInstance.mappedName,
      statusExibição: processedInstance.mappedStatus,
      statusOriginalAPI: processedInstance.originalStatus,
      apikey: processedInstance.apikey ? 'presente' : 'ausente'
    });
    
    return processedInstance;
  });

  console.log(`\n📊 RESUMO FINAL do processamento:`);
  console.log(`   Total processado: ${instancesWithCorrectStatus.length}`);
  instancesWithCorrectStatus.forEach((inst, i) => {
    console.log(`   ${i + 1}. ${inst.mappedName} -> Status API: "${inst.originalStatus}" -> Exibição: "${inst.mappedStatus}"`);
  });
  
  return { instancesList, instancesWithCorrectStatus };
};
