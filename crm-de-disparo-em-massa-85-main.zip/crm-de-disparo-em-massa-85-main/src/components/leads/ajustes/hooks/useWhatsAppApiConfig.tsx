
import { useState, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";

export const useWhatsAppApiConfig = () => {
  const [urlApi, setUrlApi] = useState("");
  const [tokenApi, setTokenApi] = useState("");
  const { toast } = useToast();
  const { user } = useAuth();

  useEffect(() => {
    carregarConfiguracoes();
  }, [user]);

  const carregarConfiguracoes = async () => {
    if (!user?.id) return;

    try {
      console.log('Carregando configurações para user:', user.id);
      
      const { data, error } = await supabase
        .from('configuracoes')
        .select('*')
        .eq('user_id', user.id)
        .maybeSingle();

      if (error) {
        console.error('Erro ao carregar configurações:', error);
        return;
      }

      if (data) {
        console.log('Configurações carregadas:', data);
        setUrlApi(data.url_api_whatsapp || "");
        setTokenApi(data.token_api_whatsapp || "");
      }
    } catch (error) {
      console.error('Erro ao carregar configurações:', error);
    }
  };

  const salvarConfiguracoes = async () => {
    if (!user?.id) {
      toast({
        title: "Erro",
        description: "Usuário não autenticado",
        variant: "destructive"
      });
      return;
    }

    if (!urlApi || !tokenApi) {
      toast({
        title: "Erro",
        description: "Preencha todos os campos obrigatórios",
        variant: "destructive"
      });
      return;
    }

    try {
      console.log('Salvando configurações para user:', user.id);
      console.log('Dados:', { urlApi, tokenApi });

      const { error } = await supabase
        .from('configuracoes')
        .upsert({
          user_id: user.id,
          url_api_whatsapp: urlApi,
          token_api_whatsapp: tokenApi,
          tipo_api_whatsapp: "evolution",
          updated_at: new Date().toISOString()
        }, {
          onConflict: 'user_id'
        });

      if (error) {
        console.error('Erro ao salvar configurações:', error);
        toast({
          title: "Erro",
          description: "Erro ao salvar configurações: " + error.message,
          variant: "destructive"
        });
        return;
      }

      console.log('Configurações salvas com sucesso');
      toast({
        title: "Sucesso",
        description: "Configurações da Evolution API salvadas com sucesso"
      });
    } catch (error) {
      console.error('Erro ao salvar configurações:', error);
      toast({
        title: "Erro",
        description: "Erro inesperado ao salvar configurações",
        variant: "destructive"
      });
    }
  };

  return {
    urlApi,
    setUrlApi,
    tokenApi,
    setTokenApi,
    salvarConfiguracoes
  };
};
