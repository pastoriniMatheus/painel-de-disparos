
import { useMutation } from '@tanstack/react-query';
import { useToast } from '@/hooks/use-toast';
import { ApiConfig } from './utils/apiConfig';
import { handleApiError } from './utils/errorHandler';

export const useInstanceCreation = () => {
  const { toast } = useToast();

  const criarInstanciaMutation = useMutation({
    mutationFn: async ({ config, instanceName }: { config: ApiConfig; instanceName: string }) => {
      console.log('Criando instância Evolution API:', instanceName, 'com config:', config);
      
      // Normalizar URL
      const baseUrl = config.urlApi.endsWith('/') ? config.urlApi.slice(0, -1) : config.urlApi;
      
      // Evolution API - endpoint para criar instância
      const fullUrl = `${baseUrl}/instance/create`;

      // Headers para Evolution API
      const headers: Record<string, string> = {
        'Content-Type': 'application/json',
        'apikey': config.tokenApi
      };

      // Payload para Evolution API
      const payload = {
        instanceName: instanceName,
        qrcode: true
      };

      console.log('Fazendo requisição para:', fullUrl);
      console.log('Headers:', headers);
      console.log('Payload:', payload);

      const response = await fetch(fullUrl, {
        method: 'POST',
        headers,
        body: JSON.stringify(payload),
        signal: AbortSignal.timeout(15000)
      });

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const data = await response.json();
      console.log('Resposta da criação Evolution API:', data);
      
      return data;
    },
    onSuccess: (data) => {
      console.log('Sucesso na criação:', data);
      toast({
        title: "Sucesso",
        description: "Instância criada com sucesso na Evolution API"
      });
    },
    onError: (error: any) => {
      const errorMessage = handleApiError(error);
      toast({
        title: "Erro",
        description: errorMessage,
        variant: "destructive"
      });
    }
  });

  return {
    criarInstanciaMutation
  };
};
