
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { TestTube } from 'lucide-react';

interface WebhookFieldProps {
  id: string;
  label: string;
  placeholder: string;
  description: string;
  value: string;
  onChange: (value: string) => void;
  onTest: () => void;
  isTesting: boolean;
  testType: string;
}

const WebhookField = ({
  id,
  label,
  placeholder,
  description,
  value,
  onChange,
  onTest,
  isTesting,
  testType
}: WebhookFieldProps) => {
  return (
    <div>
      <Label htmlFor={id}>{label}</Label>
      <div className="flex gap-2">
        <Input
          id={id}
          type="url"
          placeholder={placeholder}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="flex-1"
        />
        <Button 
          onClick={onTest}
          disabled={isTesting || !value.trim()}
          variant="outline"
          size="sm"
        >
          <TestTube className="h-4 w-4 mr-1" />
          {isTesting ? "Testando..." : "Testar"}
        </Button>
      </div>
      <p className="text-xs text-gray-500 mt-1">
        {description}
      </p>
    </div>
  );
};

export default WebhookField;
