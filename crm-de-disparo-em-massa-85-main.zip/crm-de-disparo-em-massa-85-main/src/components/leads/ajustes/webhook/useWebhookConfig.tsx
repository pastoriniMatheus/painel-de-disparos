
import { useState, useEffect } from "react";
import { useMutation, useQueryClient, useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";

export const useWebhookConfig = () => {
  const [webhookEnvio, setWebhookEnvio] = useState('');
  const [webhookVerificacao, setWebhookVerificacao] = useState('');
  const [webhookVerificacaoInstancia, setWebhookVerificacaoInstancia] = useState('');
  const [verificacaoAutomaticaHabilitada, setVerificacaoAutomaticaHabilitada] = useState(false);
  const [minutosVerificacao, setMinutosVerificacao] = useState(2);
  const [isSaving, setIsSaving] = useState(false);
  const [isTesting, setIsTesting] = useState('');
  const { toast } = useToast();
  const { user } = useAuth();
  const queryClient = useQueryClient();

  console.log('useWebhookConfig - User ID:', user?.id);

  // Buscar configuração existente
  const { data: configuracao, isLoading, error: queryError } = useQuery({
    queryKey: ['configuracoes-webhook', user?.id],
    queryFn: async () => {
      if (!user?.id) {
        console.log('useWebhookConfig - Usuário não autenticado');
        return null;
      }
      
      console.log('useWebhookConfig - Buscando configurações para user:', user.id);
      
      const { data, error } = await supabase
        .from('configuracoes')
        .select('*')
        .eq('user_id', user.id)
        .single();
      
      if (error) {
        if (error.code === 'PGRST116') {
          console.log('Nenhuma configuração encontrada');
          return null;
        }
        console.error('Erro ao carregar configurações:', error);
        throw error;
      }
      
      console.log('useWebhookConfig - Configurações carregadas:', data);
      return data;
    },
    enabled: !!user?.id
  });

  // Log de erro da query
  useEffect(() => {
    if (queryError) {
      console.error('Query error:', queryError);
    }
  }, [queryError]);

  // Atualizar estado quando a configuração carrega
  useEffect(() => {
    console.log('useWebhookConfig - Atualizando estado com configuração:', configuracao);
    if (configuracao) {
      setWebhookEnvio(configuracao.webhook_envio || '');
      setWebhookVerificacao(configuracao.webhook_verificacao || '');
      setWebhookVerificacaoInstancia(configuracao.webhook_verificacao_instancia || '');
      setVerificacaoAutomaticaHabilitada(configuracao.webhook_verificacao_instancia_habilitado || false);
      setMinutosVerificacao(configuracao.webhook_verificacao_instancia_minutos || 2);
    } else {
      // Se não há configuração, manter valores padrão
      setWebhookEnvio('');
      setWebhookVerificacao('');
      setWebhookVerificacaoInstancia('');
      setVerificacaoAutomaticaHabilitada(false);
      setMinutosVerificacao(2);
    }
  }, [configuracao]);

  const saveWebhookMutation = useMutation({
    mutationFn: async () => {
      if (!user?.id) {
        throw new Error("Usuário não autenticado");
      }

      console.log('Salvando configurações de webhook para user:', user.id);
      console.log('Dados a serem salvos:', {
        webhook_envio: webhookEnvio || null,
        webhook_verificacao: webhookVerificacao || null,
        webhook_verificacao_instancia: webhookVerificacaoInstancia || null,
        webhook_verificacao_instancia_habilitado: verificacaoAutomaticaHabilitada,
        webhook_verificacao_instancia_minutos: minutosVerificacao
      });

      // Verificar se já existe configuração
      const { data: existingConfig, error: checkError } = await supabase
        .from('configuracoes')
        .select('id')
        .eq('user_id', user.id)
        .single();

      let result;

      if (existingConfig && !checkError) {
        // Atualizar configuração existente
        console.log('Atualizando configuração existente');
        result = await supabase
          .from('configuracoes')
          .update({
            webhook_envio: webhookEnvio || null,
            webhook_verificacao: webhookVerificacao || null,
            webhook_verificacao_instancia: webhookVerificacaoInstancia || null,
            webhook_verificacao_instancia_habilitado: verificacaoAutomaticaHabilitada,
            webhook_verificacao_instancia_minutos: minutosVerificacao,
            updated_at: new Date().toISOString()
          })
          .eq('user_id', user.id)
          .select()
          .single();
      } else {
        // Criar nova configuração
        console.log('Criando nova configuração');
        result = await supabase
          .from('configuracoes')
          .insert([{
            user_id: user.id,
            webhook_envio: webhookEnvio || null,
            webhook_verificacao: webhookVerificacao || null,
            webhook_verificacao_instancia: webhookVerificacaoInstancia || null,
            webhook_verificacao_instancia_habilitado: verificacaoAutomaticaHabilitada,
            webhook_verificacao_instancia_minutos: minutosVerificacao
          }])
          .select()
          .single();
      }

      console.log('Resultado da operação:', result);

      if (result.error) {
        console.error('Erro ao salvar:', result.error);
        throw result.error;
      }

      return result.data;
    },
    onSuccess: (data) => {
      console.log('Configurações salvas com sucesso:', data);
      toast({
        title: "Sucesso",
        description: "Configurações de webhook salvadas com sucesso!"
      });
      queryClient.invalidateQueries({ queryKey: ['configuracoes-webhook'] });
    },
    onError: (error: any) => {
      console.error('Erro ao salvar webhooks:', error);
      toast({
        title: "Erro",
        description: "Erro ao salvar webhooks: " + (error.message || 'Erro desconhecido'),
        variant: "destructive"
      });
    },
    onSettled: () => {
      setIsSaving(false);
    }
  });

  const testWebhookMutation = useMutation({
    mutationFn: async (webhookUrl: string) => {
      if (!webhookUrl) throw new Error("URL do webhook é obrigatória");
      
      console.log('Testando webhook:', webhookUrl);
      
      const testData = {
        test: true,
        timestamp: new Date().toISOString(),
        message: "Test webhook from sistema"
      };
      
      // Usar modo no-cors para evitar problemas de CORS
      const response = await fetch(webhookUrl, {
        method: 'POST',
        mode: 'no-cors',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(testData)
      });
      
      console.log('Resposta do webhook (no-cors):', response.type);
      
      // Com no-cors, não conseguimos ler a resposta, mas podemos assumir sucesso se não houve erro
      return response;
    },
    onSuccess: () => {
      toast({
        title: "Teste enviado!",
        description: "Requisição enviada. Verifique o seu webhook para confirmar o recebimento."
      });
    },
    onError: (error: any) => {
      console.error('Erro no teste do webhook:', error);
      toast({
        title: "Erro no teste",
        description: "Falha ao enviar teste do webhook: " + error.message,
        variant: "destructive"
      });
    },
    onSettled: () => {
      setIsTesting('');
    }
  });

  const handleSave = () => {
    console.log('Iniciando salvamento...');
    setIsSaving(true);
    saveWebhookMutation.mutate();
  };

  const handleTest = (webhookUrl: string, type: string) => {
    console.log('Testando webhook:', type, webhookUrl);
    setIsTesting(type);
    testWebhookMutation.mutate(webhookUrl);
  };

  return {
    // State
    webhookEnvio,
    setWebhookEnvio,
    webhookVerificacao,
    setWebhookVerificacao,
    webhookVerificacaoInstancia,
    setWebhookVerificacaoInstancia,
    verificacaoAutomaticaHabilitada,
    setVerificacaoAutomaticaHabilitada,
    minutosVerificacao,
    setMinutosVerificacao,
    isSaving,
    isTesting,
    isLoading,
    
    // Actions
    handleSave,
    handleTest
  };
};
