
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';

interface InstanceVerificationSettingsProps {
  verificacaoAutomaticaHabilitada: boolean;
  setVerificacaoAutomaticaHabilitada: (enabled: boolean) => void;
  minutosVerificacao: number;
  setMinutosVerificacao: (minutes: number) => void;
}

const InstanceVerificationSettings = ({
  verificacaoAutomaticaHabilitada,
  setVerificacaoAutomaticaHabilitada,
  minutosVerificacao,
  setMinutosVerificacao
}: InstanceVerificationSettingsProps) => {
  return (
    <>
      <div className="flex items-center space-x-2 mt-3">
        <Checkbox 
          id="verificacao-automatica"
          checked={verificacaoAutomaticaHabilitada}
          onCheckedChange={(checked) => setVerificacaoAutomaticaHabilitada(checked as boolean)}
        />
        <Label htmlFor="verificacao-automatica" className="text-sm">
          Habilitar verificação automática
        </Label>
      </div>
      
      {verificacaoAutomaticaHabilitada && (
        <div className="mt-3">
          <Label htmlFor="minutos-verificacao">Intervalo em minutos</Label>
          <Input
            id="minutos-verificacao"
            type="number"
            min="1"
            max="60"
            value={minutosVerificacao}
            onChange={(e) => setMinutosVerificacao(parseInt(e.target.value) || 2)}
            className="w-24"
          />
          <p className="text-xs text-gray-500 mt-1">
            Intervalo entre verificações (1-60 minutos)
          </p>
        </div>
      )}
    </>
  );
};

export default InstanceVerificationSettings;
