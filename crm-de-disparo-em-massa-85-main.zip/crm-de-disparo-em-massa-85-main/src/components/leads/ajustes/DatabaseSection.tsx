
import { useState, useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import { Database, Download, Upload, TestTube, Server, Key, Link } from "lucide-react";
import { useDatabaseOperations } from "./database/useDatabaseOperations";

const DatabaseSection = () => {
  const [dbUrl, setDbUrl] = useState("");
  const [anonKey, setAnonKey] = useState("");
  const [serviceKey, setServiceKey] = useState("");
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const {
    currentConfig,
    isConnecting,
    isBackingUp,
    isRestoring,
    testConnection,
    downloadBackup,
    uploadBackup
  } = useDatabaseOperations();

  // Preencher com configuração atual ao carregar
  useState(() => {
    setDbUrl(currentConfig.url);
    setAnonKey(currentConfig.anonKey);
  });

  const handleTestConnection = () => {
    testConnection({
      url: dbUrl,
      anonKey: anonKey,
      serviceKey: serviceKey
    });
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const targetConfig = dbUrl && anonKey ? {
        url: dbUrl,
        anonKey: anonKey,
        serviceKey: serviceKey
      } : undefined;
      
      uploadBackup(file, targetConfig);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Database className="h-5 w-5" />
          Gerenciamento de Banco de Dados
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Configuração de Conexão */}
        <div className="space-y-4">
          <h3 className="text-lg font-semibold flex items-center gap-2">
            <Server className="h-4 w-4" />
            Configuração de Conexão
          </h3>
          
          <div className="grid gap-4">
            <div>
              <Label htmlFor="db-url" className="flex items-center gap-2">
                <Link className="h-4 w-4" />
                URL do Supabase
              </Label>
              <Input
                id="db-url"
                type="url"
                placeholder="https://xxxxxxxx.supabase.co"
                value={dbUrl}
                onChange={(e) => setDbUrl(e.target.value)}
              />
            </div>
            
            <div>
              <Label htmlFor="anon-key" className="flex items-center gap-2">
                <Key className="h-4 w-4" />
                Anon Key (Chave Pública)
              </Label>
              <Textarea
                id="anon-key"
                placeholder="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
                value={anonKey}
                onChange={(e) => setAnonKey(e.target.value)}
                rows={3}
              />
            </div>
            
            <div>
              <Label htmlFor="service-key" className="flex items-center gap-2">
                <Key className="h-4 w-4" />
                Service Role Key (Opcional - para restauração)
              </Label>
              <Textarea
                id="service-key"
                placeholder="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9... (Opcional)"
                value={serviceKey}
                onChange={(e) => setServiceKey(e.target.value)}
                rows={3}
              />
              <p className="text-sm text-gray-500 mt-1">
                Necessário apenas para operações de restauração. Mantenha seguro!
              </p>
            </div>
          </div>

          <Button 
            onClick={handleTestConnection}
            disabled={!dbUrl || !anonKey || isConnecting}
            variant="outline"
            className="w-full"
          >
            <TestTube className="h-4 w-4 mr-2" />
            {isConnecting ? "Testando Conexão..." : "Testar Conexão"}
          </Button>
        </div>

        <Separator />

        {/* Operações de Backup */}
        <div className="space-y-4">
          <h3 className="text-lg font-semibold flex items-center gap-2">
            <Database className="h-4 w-4" />
            Operações de Backup
          </h3>
          
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Button
                onClick={downloadBackup}
                disabled={isBackingUp}
                className="w-full"
                variant="default"
              >
                <Download className="h-4 w-4 mr-2" />
                {isBackingUp ? "Gerando Backup..." : "Baixar Backup"}
              </Button>
              <p className="text-sm text-gray-500">
                Faz download de todas as tabelas do banco atual em formato JSON
              </p>
            </div>

            <div className="space-y-2">
              <Button
                onClick={() => fileInputRef.current?.click()}
                disabled={isRestoring}
                className="w-full"
                variant="secondary"
              >
                <Upload className="h-4 w-4 mr-2" />
                {isRestoring ? "Restaurando..." : "Enviar Backup"}
              </Button>
              <p className="text-sm text-gray-500">
                Restaura dados de um arquivo de backup JSON no banco configurado
              </p>
            </div>
          </div>

          <input
            ref={fileInputRef}
            type="file"
            accept=".json"
            onChange={handleFileUpload}
            className="hidden"
          />
        </div>

        <Separator />

        {/* Informações Atuais */}
        <div className="space-y-2">
          <h3 className="text-lg font-semibold">Configuração Atual</h3>
          <div className="bg-gray-50 p-3 rounded-md text-sm">
            <p><strong>Status:</strong> <span className="text-green-600">Conectado</span></p>
            <p><strong>URL:</strong> {currentConfig.url}</p>
            <p><strong>Projeto:</strong> brwapytjhitzurfnpfsz</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default DatabaseSection;
