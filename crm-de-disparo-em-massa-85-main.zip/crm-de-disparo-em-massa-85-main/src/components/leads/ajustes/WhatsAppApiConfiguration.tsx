
import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";

interface WhatsAppApiConfigurationProps {
  urlApi: string;
  setUrlApi: (url: string) => void;
  tokenApi: string;
  setTokenApi: (token: string) => void;
  onSave: () => void;
  onList: () => void;
  isListing: boolean;
}

const WhatsAppApiConfiguration = ({
  urlApi,
  setUrlApi,
  tokenApi,
  setTokenApi,
  onSave,
  onList,
  isListing
}: WhatsAppApiConfigurationProps) => {
  return (
    <div className="space-y-4">
      <div className="bg-blue-50 p-4 rounded-lg">
        <p className="text-sm text-blue-700">
          <strong>Evolution API:</strong> Configure sua instância da Evolution API para gerenciar suas conexões WhatsApp.
        </p>
      </div>

      <div>
        <Label htmlFor="url-api">URL da Evolution API</Label>
        <Input
          id="url-api"
          type="url"
          placeholder="https://sua-evolution-api.com"
          value={urlApi}
          onChange={(e) => setUrlApi(e.target.value)}
        />
        <p className="text-xs text-gray-500 mt-1">
          Ex: https://api.evolution.com ou http://localhost:8080
        </p>
      </div>

      <div>
        <Label htmlFor="token-api">Token da API</Label>
        <Input
          id="token-api"
          type="password"
          placeholder="Seu token de acesso da Evolution API"
          value={tokenApi}
          onChange={(e) => setTokenApi(e.target.value)}
        />
        <p className="text-xs text-gray-500 mt-1">
          Token de autenticação para acessar a Evolution API
        </p>
      </div>

      <div className="flex gap-2">
        <Button onClick={onSave} className="flex-1">
          Salvar Configurações
        </Button>
        <Button 
          variant="outline" 
          onClick={onList}
          disabled={isListing || !urlApi || !tokenApi}
          className="flex-1"
        >
          {isListing ? "Listando..." : "Listar Instâncias"}
        </Button>
      </div>
    </div>
  );
};

export default WhatsAppApiConfiguration;
