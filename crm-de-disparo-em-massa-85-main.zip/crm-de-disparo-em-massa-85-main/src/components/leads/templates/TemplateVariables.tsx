
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

interface TemplateVariablesProps {
  onVariableClick: (variable: string) => void;
}

const TemplateVariables = ({ onVariableClick }: TemplateVariablesProps) => {
  const variables = [
    { name: "nome", description: "Nome do lead" },
    { name: "cidade", description: "Cidade do lead" },
    { name: "categoria", description: "Categoria do lead" },
    { name: "telefone", description: "Telefone do lead" },
    { name: "url", description: "URL do lead" }
  ];

  return (
    <div className="space-y-3">
      <h4 className="text-sm font-medium">Variáveis Disponíveis:</h4>
      <div className="flex flex-wrap gap-2">
        {variables.map((variable) => (
          <Badge
            key={variable.name}
            variant="outline"
            className="cursor-pointer hover:bg-blue-50"
            onClick={() => onVariableClick(`{{${variable.name}}}`)}
            title={variable.description}
          >
            {`{{${variable.name}}}`}
          </Badge>
        ))}
      </div>
      <p className="text-xs text-gray-500">
        Clique nas variáveis para adicioná-las ao texto da mensagem
      </p>
    </div>
  );
};

export default TemplateVariables;
