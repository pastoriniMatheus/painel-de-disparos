
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { CreditCard, DollarSign, Clock, CheckCircle } from "lucide-react";

interface PredefinedTemplatesProps {
  onTemplateSelect: (template: { nome: string; conteudo: string }) => void;
}

const PredefinedTemplates = ({ onTemplateSelect }: PredefinedTemplatesProps) => {
  const templates = [
    {
      id: "credito-rapido",
      nome: "Crédito Rápido Online",
      icon: <CreditCard className="h-4 w-4" />,
      conteudo: `Olá {{nome}}! 💳

🚀 *CRÉDITO RÁPIDO ONLINE*
✅ Aprovação em minutos
✅ Para negativados
✅ Sem consulta ao SPC/Serasa
✅ Primeiro pagamento em 90 dias

💰 Valores disponíveis:
• R$ 500 a R$ 2.500
• Parcelas de até 12x

📍 Você está em {{cidade}}? Perfeito!

👆 *SIMULE AGORA:* {{url}}

*Responda SIM para receber o link direto!*`
    },
    {
      id: "emprestimo-pessoal",
      nome: "Empréstimo Pessoal",
      icon: <DollarSign className="h-4 w-4" />,
      conteudo: `{{nome}}, que tal resolver suas pendências? 💪

💰 *EMPRÉSTIMO PESSOAL*
✅ Até R$ 10.000
✅ Aprovação rápida
✅ Sem burocracia
✅ Para negativados também

🏠 Atendemos {{cidade}} e região!

🔥 *CONDIÇÕES ESPECIAIS:*
• Taxa reduzida
• Parcelas que cabem no seu bolso
• Dinheiro na conta hoje mesmo

📱 *SOLICITE AQUI:* {{url}}

*Digite seu nome para começar!*`
    },
    {
      id: "credito-5mil",
      nome: "Crédito até R$ 5.000",
      icon: <CheckCircle className="h-4 w-4" />,
      conteudo: `Oi {{nome}}! 🎯

💳 *CRÉDITO DE ATÉ R$ 5.000*
⚡ Aprovado na hora
✅ Sem consulta ao SPC
✅ Para negativados
✅ {{cidade}} - Aprovado!

🎁 *VANTAGENS EXCLUSIVAS:*
• Sem anuidade
• Limite pré-aprovado
• Cartão virtual imediato

📲 *ATIVE AGORA:* {{url}}

*Responda com seu CPF para continuar!*`
    },
    {
      id: "melhores-ofertas",
      nome: "Melhores Ofertas",
      icon: <Clock className="h-4 w-4" />,
      conteudo: `{{nome}}, suas *MELHORES OFERTAS* chegaram! 🔥

🏆 *ESPECIAL PARA {{cidade}}:*

💳 *Opção 1 - Cartão de Crédito*
• Até R$ 2.500
• Aprovação imediata
• Sem anuidade

💰 *Opção 2 - Empréstimo*
• Até R$ 10.000
• 1º pagamento em 90 dias
• Para negativados

📱 *Opção 3 - Crédito Digital*
• Até R$ 5.000
• Liberação na hora
• {{categoria}} - Pré-aprovado!

🎯 *ESCOLHA SUA OPÇÃO:* {{url}}

*Qual interessou mais? Responda 1, 2 ou 3!*`
    }
  ];

  return (
    <div className="space-y-4">
      <h3 className="text-lg font-medium">Templates Pré-definidos</h3>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {templates.map((template) => (
          <Card key={template.id} className="cursor-pointer hover:shadow-md transition-shadow">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm flex items-center gap-2">
                {template.icon}
                {template.nome}
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="space-y-3">
                <p className="text-xs text-gray-600 line-clamp-3">
                  {template.conteudo.substring(0, 100)}...
                </p>
                <Button 
                  size="sm" 
                  className="w-full"
                  onClick={() => onTemplateSelect(template)}
                >
                  Usar este template
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default PredefinedTemplates;
