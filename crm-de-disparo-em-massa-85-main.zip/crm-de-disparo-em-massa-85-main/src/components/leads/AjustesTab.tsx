
import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Settings, Webhook, Palette, Database } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useUserProfile } from "@/hooks/useUserProfile";
import { useAppearanceSettings } from "@/hooks/useAppearanceSettings";
import WhatsAppApiSection from "./ajustes/WhatsAppApiSection";
import WebhookSection from "./ajustes/WebhookSection";
import WebhookExamplesSection from "./ajustes/WebhookExamplesSection";
import AppearanceSettings from "../settings/AppearanceSettings";
import DatabaseSection from "./ajustes/DatabaseSection";

const AjustesTab = () => {
  const [activeTab, setActiveTab] = useState("api");
  const { isAdmin } = useUserProfile();
  const { settings } = useAppearanceSettings();

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold mb-2" style={{ color: settings?.secondary_color || '#004a99' }}>
          Configurações do Sistema
        </h2>
        <p className="text-gray-600">
          Configure as integrações e ajustes do sistema
        </p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className={`grid w-full ${isAdmin ? 'grid-cols-4' : 'grid-cols-3'}`}>
          <TabsTrigger value="api" className="flex items-center gap-2">
            <Settings className="h-4 w-4" />
            API WhatsApp
          </TabsTrigger>
          <TabsTrigger value="webhooks" className="flex items-center gap-2">
            <Webhook className="h-4 w-4" />
            Webhooks
          </TabsTrigger>
          <TabsTrigger value="database" className="flex items-center gap-2">
            <Database className="h-4 w-4" />
            Banco de Dados
          </TabsTrigger>
          {isAdmin && (
            <TabsTrigger value="appearance" className="flex items-center gap-2">
              <Palette className="h-4 w-4" />
              Aparência
            </TabsTrigger>
          )}
        </TabsList>

        <TabsContent value="api" className="space-y-6">
          <WhatsAppApiSection />
        </TabsContent>

        <TabsContent value="webhooks" className="space-y-6">
          <WebhookSection />
          <WebhookExamplesSection />
        </TabsContent>

        <TabsContent value="database" className="space-y-6">
          <DatabaseSection />
        </TabsContent>

        {isAdmin && (
          <TabsContent value="appearance" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle 
                  className="flex items-center gap-2" 
                  style={{ color: settings?.secondary_color || '#004a99' }}
                >
                  <Palette className="h-5 w-5" />
                  Configurações de Aparência
                </CardTitle>
                <CardDescription>
                  Configure o favicon, logotipo e cores do sistema. Apenas administradores podem alterar essas configurações.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <AppearanceSettings />
              </CardContent>
            </Card>
          </TabsContent>
        )}
      </Tabs>
    </div>
  );
};

export default AjustesTab;
