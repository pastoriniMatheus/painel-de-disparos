
import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { Upload, Image as ImageIcon, Palette } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';

interface AppearanceSettings {
  id: string;
  favicon_url: string | null;
  logo_url: string | null;
  primary_color: string | null;
  secondary_color: string | null;
}

const AppearanceSettings = () => {
  const [favicon, setFavicon] = useState<File | null>(null);
  const [logo, setLogo] = useState<File | null>(null);
  const [faviconPreview, setFaviconPreview] = useState<string>('');
  const [logoPreview, setLogoPreview] = useState<string>('');
  const [settings, setSettings] = useState<AppearanceSettings | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    fetchAppearanceSettings();
  }, []);

  const fetchAppearanceSettings = async () => {
    try {
      const { data, error } = await supabase
        .from('appearance_settings')
        .select('*')
        .single();

      if (error && error.code !== 'PGRST116') {
        console.error('Erro ao buscar configurações:', error);
        return;
      }

      if (data) {
        setSettings(data);
        if (data.favicon_url) {
          setFaviconPreview(data.favicon_url);
        }
        if (data.logo_url) {
          setLogoPreview(data.logo_url);
        }
      }
    } catch (error) {
      console.error('Erro ao buscar configurações:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleFaviconChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (!file.type.startsWith('image/')) {
        toast({
          title: "Erro",
          description: "Arquivo deve ser uma imagem PNG ou JPG.",
          variant: "destructive"
        });
        return;
      }

      setFavicon(file);
      const reader = new FileReader();
      reader.onload = (e) => {
        setFaviconPreview(e.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleLogoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (!file.type.startsWith('image/')) {
        toast({
          title: "Erro",
          description: "Arquivo deve ser uma imagem.",
          variant: "destructive"
        });
        return;
      }

      setLogo(file);
      const reader = new FileReader();
      reader.onload = (e) => {
        setLogoPreview(e.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const convertFileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  };

  const saveFavicon = async () => {
    if (!favicon) {
      toast({
        title: "Erro",
        description: "Selecione um arquivo de favicon primeiro.",
        variant: "destructive"
      });
      return;
    }

    try {
      setSaving(true);
      
      // Converter para base64 para salvar no banco
      const base64Data = await convertFileToBase64(favicon);
      
      // Atualizar configurações no banco
      const { error } = await supabase
        .from('appearance_settings')
        .upsert({
          id: settings?.id || '00000000-0000-0000-0000-000000000001',
          favicon_url: base64Data,
          logo_url: settings?.logo_url,
          primary_color: settings?.primary_color || '#00cc68',
          secondary_color: settings?.secondary_color || '#004a99'
        });

      if (error) {
        console.error('Erro ao salvar favicon:', error);
        toast({
          title: "Erro",
          description: "Erro ao salvar favicon no banco de dados.",
          variant: "destructive"
        });
        return;
      }

      // Atualizar o favicon no DOM
      const link = document.querySelector("link[rel*='icon']") || document.createElement('link');
      link.setAttribute('rel', 'icon');
      link.setAttribute('href', base64Data);
      link.setAttribute('type', favicon.type);
      document.head.appendChild(link);

      toast({
        title: "Sucesso",
        description: "Favicon aplicado e salvo com sucesso!"
      });

      await fetchAppearanceSettings();
    } catch (error) {
      console.error('Erro ao salvar favicon:', error);
      toast({
        title: "Erro",
        description: "Erro ao salvar favicon.",
        variant: "destructive"
      });
    } finally {
      setSaving(false);
    }
  };

  const saveLogo = async () => {
    if (!logo) {
      toast({
        title: "Erro",
        description: "Selecione um arquivo de logo primeiro.",
        variant: "destructive"
      });
      return;
    }

    try {
      setSaving(true);
      
      // Converter para base64 para salvar no banco
      const base64Data = await convertFileToBase64(logo);

      // Atualizar configurações no banco
      const { error } = await supabase
        .from('appearance_settings')
        .upsert({
          id: settings?.id || '00000000-0000-0000-0000-000000000001',
          favicon_url: settings?.favicon_url,
          logo_url: base64Data,
          primary_color: settings?.primary_color || '#00cc68',
          secondary_color: settings?.secondary_color || '#004a99'
        });

      if (error) {
        console.error('Erro ao salvar logo:', error);
        toast({
          title: "Erro",
          description: "Erro ao salvar logo no banco de dados.",
          variant: "destructive"
        });
        return;
      }

      toast({
        title: "Sucesso",
        description: "Logo aplicado e salvo com sucesso!"
      });

      await fetchAppearanceSettings();
    } catch (error) {
      console.error('Erro ao salvar logo:', error);
      toast({
        title: "Erro",
        description: "Erro ao salvar logo.",
        variant: "destructive"
      });
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return <div className="p-4">Carregando configurações...</div>;
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-[#004a99]">
            <Palette className="h-5 w-5" />
            Favicon
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="favicon">Selecionar Favicon (PNG/JPG)</Label>
            <Input
              id="favicon"
              type="file"
              accept="image/png,image/jpeg,image/jpg"
              onChange={handleFaviconChange}
              className="mt-1"
            />
            <p className="text-sm text-gray-500 mt-1">
              Recomendado: PNG 32x32 pixels ou JPG 32x32 pixels
            </p>
          </div>

          {faviconPreview && (
            <div className="space-y-2">
              <Label>Preview do Favicon</Label>
              <div className="flex items-center gap-2">
                <img 
                  src={faviconPreview} 
                  alt="Favicon preview" 
                  className="w-8 h-8 rounded"
                />
                <span className="text-sm text-gray-600">32x32 pixels</span>
              </div>
            </div>
          )}

          <Button 
            onClick={saveFavicon} 
            disabled={!favicon || saving}
            className="bg-[#00cc68] hover:bg-[#00b359] text-white"
          >
            <Upload className="h-4 w-4 mr-2" />
            {saving ? "Salvando..." : "Aplicar e Salvar Favicon"}
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-[#004a99]">
            <ImageIcon className="h-5 w-5" />
            Logotipo
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="logo">Selecionar Logotipo</Label>
            <Input
              id="logo"
              type="file"
              accept="image/*"
              onChange={handleLogoChange}
              className="mt-1"
            />
            <p className="text-sm text-gray-500 mt-1">
              Recomendado: PNG com fundo transparente, proporção 4:1 (ex: 400x100px)
            </p>
          </div>

          {logoPreview && (
            <div className="space-y-2">
              <Label>Preview do Logo</Label>
              <div className="p-4 border rounded-lg bg-gray-50">
                <img 
                  src={logoPreview} 
                  alt="Logo preview" 
                  className="max-h-16 w-auto"
                />
              </div>
            </div>
          )}

          <Button 
            onClick={saveLogo} 
            disabled={!logo || saving}
            className="bg-[#00cc68] hover:bg-[#00b359] text-white"
          >
            <Upload className="h-4 w-4 mr-2" />
            {saving ? "Salvando..." : "Aplicar e Salvar Logo"}
          </Button>
        </CardContent>
      </Card>
    </div>
  );
};

export default AppearanceSettings;
