
import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { useAppearanceSettings } from "@/hooks/useAppearanceSettings";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { UserPlus, LogIn } from "lucide-react";

const AuthPage = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const { signIn, signUp } = useAuth();
  const { settings } = useAppearanceSettings();
  const { toast } = useToast();

  const handleSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !password.trim()) {
      toast({
        title: "Erro",
        description: "Email e senha são obrigatórios",
        variant: "destructive"
      });
      return;
    }

    setLoading(true);
    const { error } = await signIn(email, password);
    
    if (error) {
      toast({
        title: "Erro no login",
        description: error.message === "Invalid login credentials" 
          ? "Email ou senha incorretos" 
          : error.message,
        variant: "destructive"
      });
    } else {
      toast({
        title: "Sucesso",
        description: "Login realizado com sucesso!"
      });
    }
    setLoading(false);
  };

  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !password.trim()) {
      toast({
        title: "Erro",
        description: "Email e senha são obrigatórios",
        variant: "destructive"
      });
      return;
    }

    if (password.length < 6) {
      toast({
        title: "Erro",
        description: "A senha deve ter pelo menos 6 caracteres",
        variant: "destructive"
      });
      return;
    }

    setLoading(true);
    const { error } = await signUp(email, password);
    
    if (error) {
      if (error.message.includes("already registered")) {
        toast({
          title: "Erro",
          description: "Este email já está cadastrado. Tente fazer login.",
          variant: "destructive"
        });
      } else {
        toast({
          title: "Erro no cadastro",
          description: error.message,
          variant: "destructive"
        });
      }
    } else {
      toast({
        title: "Sucesso",
        description: "Conta criada com sucesso! Verifique seu email para confirmar a conta."
      });
    }
    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          {/* Logo personalizado */}
          <div className="mb-4">
            {settings?.logo_url ? (
              <img 
                src={settings.logo_url} 
                alt="Logo"
                className="h-16 mx-auto"
                onError={(e) => {
                  // Fallback caso a imagem não carregue
                  const target = e.target as HTMLImageElement;
                  target.style.display = 'none';
                  const fallback = target.parentElement?.querySelector('.fallback-logo');
                  if (fallback) {
                    (fallback as HTMLElement).style.display = 'block';
                  }
                }}
              />
            ) : (
              <div className="fallback-logo">
                <div 
                  className="w-16 h-16 rounded-lg flex items-center justify-center mx-auto"
                  style={{ backgroundColor: settings?.primary_color || '#00cc68' }}
                >
                  <span className="text-white text-2xl font-bold">SL</span>
                </div>
              </div>
            )}
            {!settings?.logo_url && (
              <div className="fallback-logo">
                <div 
                  className="w-16 h-16 rounded-lg flex items-center justify-center mx-auto"
                  style={{ backgroundColor: settings?.primary_color || '#00cc68' }}
                >
                  <span className="text-white text-2xl font-bold">SL</span>
                </div>
              </div>
            )}
          </div>
          
          <h1 
            className="text-3xl font-bold mb-2"
            style={{ color: settings?.secondary_color || '#006ecf' }}
          >
            Sistema de Leads
          </h1>
          <p className="text-gray-600">
            Faça login ou crie sua conta para continuar
          </p>
        </div>

        <Tabs defaultValue="login" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger 
              value="login" 
              className="flex items-center gap-2"
              style={{ 
                '--tw-ring-color': settings?.secondary_color || '#006ecf'
              } as React.CSSProperties}
            >
              <LogIn className="h-4 w-4" />
              Login
            </TabsTrigger>
            <TabsTrigger 
              value="signup" 
              className="flex items-center gap-2"
              style={{ 
                '--tw-ring-color': settings?.secondary_color || '#006ecf'
              } as React.CSSProperties}
            >
              <UserPlus className="h-4 w-4" />
              Cadastro
            </TabsTrigger>
          </TabsList>

          <TabsContent value="login">
            <Card>
              <CardHeader>
                <CardTitle style={{ color: settings?.secondary_color || '#006ecf' }}>
                  Fazer Login
                </CardTitle>
                <CardDescription>
                  Entre com suas credenciais para acessar o sistema
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSignIn} className="space-y-4">
                  <div>
                    <Label htmlFor="login-email">Email</Label>
                    <Input
                      id="login-email"
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="seu@email.com"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="login-password">Senha</Label>
                    <Input
                      id="login-password"
                      type="password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="Sua senha"
                      required
                    />
                  </div>
                  <Button 
                    type="submit" 
                    className="w-full text-white"
                    disabled={loading}
                    style={{ 
                      backgroundColor: settings?.primary_color || '#00cc68',
                      '--tw-bg-opacity': '1'
                    } as React.CSSProperties}
                  >
                    {loading ? "Entrando..." : "Entrar"}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="signup">
            <Card>
              <CardHeader>
                <CardTitle style={{ color: settings?.secondary_color || '#006ecf' }}>
                  Criar Conta
                </CardTitle>
                <CardDescription>
                  Crie uma nova conta para começar a usar o sistema
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSignUp} className="space-y-4">
                  <div>
                    <Label htmlFor="signup-email">Email</Label>
                    <Input
                      id="signup-email"
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="seu@email.com"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="signup-password">Senha</Label>
                    <Input
                      id="signup-password"
                      type="password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="Mínimo 6 caracteres"
                      required
                      minLength={6}
                    />
                  </div>
                  <Button 
                    type="submit" 
                    className="w-full text-white"
                    disabled={loading}
                    style={{ 
                      backgroundColor: settings?.primary_color || '#00cc68',
                      '--tw-bg-opacity': '1'
                    } as React.CSSProperties}
                  >
                    {loading ? "Criando conta..." : "Criar Conta"}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default AuthPage;
