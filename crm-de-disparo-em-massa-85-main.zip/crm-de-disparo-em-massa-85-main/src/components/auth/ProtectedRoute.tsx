
import { useAuth } from "@/hooks/useAuth";
import { useUserProfile } from "@/hooks/useUserProfile";
import AuthPage from "./AuthPage";
import UserApprovalPage from "./UserApprovalPage";

interface ProtectedRouteProps {
  children: React.ReactNode;
}

const ProtectedRoute = ({ children }: ProtectedRouteProps) => {
  const { user, loading: authLoading } = useAuth();
  const { profile, loading: profileLoading, isApproved } = useUserProfile();

  if (authLoading || profileLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Carregando...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return <AuthPage />;
  }

  // If user is authenticated but has no profile (edge case), show approval page
  if (user && !profile) {
    return <UserApprovalPage />;
  }

  // If the user is authenticated but not approved, show approval page
  if (user && profile && !isApproved) {
    return <UserApprovalPage />;
  }

  return <>{children}</>;
};

export default ProtectedRoute;
