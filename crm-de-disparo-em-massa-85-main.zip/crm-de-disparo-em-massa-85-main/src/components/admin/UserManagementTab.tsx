
import { useState, useEffect, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { useAppearanceSettings } from '@/hooks/useAppearanceSettings';
import { Check, X, UserPlus, Users, Clock, Edit, Trash2, Shield, ShieldOff } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { useForm } from 'react-hook-form';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';

interface UserWithEmail {
  id: string;
  role: 'admin' | 'user' | 'pending';
  approved: boolean;
  approved_at?: string;
  created_at: string;
  email?: string;
}

interface AddUserForm {
  email: string;
  password: string;
  role: 'admin' | 'user';
}

interface EditUserForm {
  email: string;
  role: 'admin' | 'user' | 'pending';
}

const UserManagementTab = () => {
  const [users, setUsers] = useState<UserWithEmail[]>([]);
  const [loading, setLoading] = useState(true);
  const [addUserOpen, setAddUserOpen] = useState(false);
  const [editUserOpen, setEditUserOpen] = useState(false);
  const [selectedUser, setSelectedUser] = useState<UserWithEmail | null>(null);
  const [deletingUserId, setDeletingUserId] = useState<string | null>(null);
  const { toast } = useToast();
  const { user: currentUser } = useAuth();
  const { settings } = useAppearanceSettings();

  const addUserForm = useForm<AddUserForm>({
    defaultValues: {
      email: '',
      password: '',
      role: 'user'
    }
  });

  const editUserForm = useForm<EditUserForm>({
    defaultValues: {
      email: '',
      role: 'user'
    }
  });

  const fetchUsers = useCallback(async () => {
    try {
      setLoading(true);
      console.log('Buscando usuários com emails reais...');
      
      const { data: usersWithEmails, error } = await supabase
        .rpc('get_users_with_emails');

      if (error) {
        console.error('Erro ao buscar usuários:', error);
        toast({
          title: "Erro",
          description: "Erro ao carregar usuários",
          variant: "destructive"
        });
        return;
      }

      console.log('Usuários carregados:', usersWithEmails);

      const formattedUsers: UserWithEmail[] = (usersWithEmails || []).map(user => {
        let role: 'admin' | 'user' | 'pending' = 'pending';
        if (user.role === 'admin' || user.role === 'user' || user.role === 'pending') {
          role = user.role;
        }

        return {
          id: user.id,
          role,
          approved: user.approved || false,
          approved_at: user.approved_at || undefined,
          created_at: user.created_at,
          email: user.email || 'Email não disponível'
        };
      });

      console.log('Usuários formatados:', formattedUsers);
      setUsers(formattedUsers);
    } catch (error) {
      console.error('Erro ao buscar usuários:', error);
      toast({
        title: "Erro",
        description: "Erro ao carregar usuários",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  }, [toast]);

  useEffect(() => {
    fetchUsers();
  }, [fetchUsers]);

  const approveUser = useCallback(async (userId: string) => {
    try {
      console.log('Aprovando usuário:', userId);
      
      // Primeiro, aprovar no perfil
      const { error: profileError } = await supabase
        .from('profiles')
        .update({
          approved: true,
          role: 'user',
          approved_at: new Date().toISOString(),
          approved_by: currentUser?.id
        })
        .eq('id', userId);

      if (profileError) {
        console.error('Erro ao aprovar usuário no perfil:', profileError);
        toast({
          title: "Erro",
          description: "Erro ao aprovar usuário no perfil",
          variant: "destructive"
        });
        return;
      }

      // Tentar confirmar o email automaticamente usando a função admin
      try {
        const { error: updateError } = await supabase.auth.admin.updateUserById(userId, {
          email_confirm: true
        });

        if (updateError) {
          console.log('Aviso ao confirmar email via admin:', updateError);
          // Se falhar, vamos tentar nossa função personalizada
          const { error: confirmError } = await supabase.rpc('confirm_user_email', {
            target_user_id: userId
          });
          
          if (confirmError) {
            console.error('Erro ao confirmar email:', confirmError);
          }
        }
      } catch (adminError) {
        console.log('Admin API não disponível, usando função personalizada');
        // Usar nossa função personalizada como fallback
        const { error: confirmError } = await supabase.rpc('confirm_user_email', {
          target_user_id: userId
        });
        
        if (confirmError) {
          console.error('Erro ao confirmar email:', confirmError);
        }
      }

      toast({
        title: "Sucesso",
        description: "Usuário aprovado com sucesso"
      });
      
      await fetchUsers();
    } catch (error) {
      console.error('Erro ao aprovar usuário:', error);
      toast({
        title: "Erro",
        description: "Erro ao aprovar usuário",
        variant: "destructive"
      });
    }
  }, [currentUser?.id, fetchUsers, toast]);

  const addUser = useCallback(async (data: AddUserForm) => {
    try {
      console.log('Criando usuário:', data.email);
      
      // Usar a função personalizada para criar usuário com email confirmado
      const { data: authData, error: authError } = await supabase.rpc('create_confirmed_user', {
        user_email: data.email,
        user_password: data.password,
        user_role: data.role
      });

      if (authError) {
        console.error('Erro ao criar usuário:', authError);
        toast({
          title: "Erro",
          description: "Erro ao criar usuário: " + authError.message,
          variant: "destructive"
        });
        return;
      }

      toast({
        title: "Sucesso",
        description: "Usuário criado e pode fazer login imediatamente"
      });

      setAddUserOpen(false);
      addUserForm.reset();
      await fetchUsers();
    } catch (error) {
      console.error('Erro ao adicionar usuário:', error);
      toast({
        title: "Erro",
        description: "Erro ao criar usuário",
        variant: "destructive"
      });
    }
  }, [currentUser?.id, fetchUsers, toast, addUserForm]);

  const editUser = useCallback(async (data: EditUserForm) => {
    if (!selectedUser) return;

    try {
      console.log('Editando usuário:', selectedUser.id, data);
      
      const { error } = await supabase
        .rpc('update_user_profile', {
          user_id: selectedUser.id,
          new_email: data.email,
          new_role: data.role
        });

      if (error) {
        console.error('Erro ao atualizar usuário:', error);
        toast({
          title: "Erro",
          description: "Erro ao atualizar usuário",
          variant: "destructive"
        });
        return;
      }

      toast({
        title: "Sucesso",
        description: "Usuário atualizado com sucesso"
      });
      
      setEditUserOpen(false);
      setSelectedUser(null);
      editUserForm.reset();
      await fetchUsers();
    } catch (error) {
      console.error('Erro ao editar usuário:', error);
      toast({
        title: "Erro",
        description: "Erro ao atualizar usuário",
        variant: "destructive"
      });
    }
  }, [selectedUser, fetchUsers, toast, editUserForm]);

  const rejectUser = useCallback(async (userId: string) => {
    try {
      console.log('Rejeitando usuário:', userId);
      setDeletingUserId(userId);
      
      // Usar a função do banco para deletar usuário e todos os dados
      const { error: deleteError } = await supabase
        .rpc('delete_user_and_data', { target_user_id: userId });

      if (deleteError) {
        console.error('Erro ao rejeitar usuário:', deleteError);
        toast({
          title: "Erro",
          description: "Erro ao rejeitar usuário: " + deleteError.message,
          variant: "destructive"
        });
        return;
      }

      toast({
        title: "Sucesso",
        description: "Usuário rejeitado e removido"
      });
      
      await fetchUsers();
    } catch (error) {
      console.error('Erro ao rejeitar usuário:', error);
      toast({
        title: "Erro",
        description: "Erro ao rejeitar usuário",
        variant: "destructive"
      });
    } finally {
      setDeletingUserId(null);
    }
  }, [fetchUsers, toast]);

  const makeAdmin = useCallback(async (userId: string) => {
    try {
      console.log('Tornando usuário admin:', userId);
      
      const { error } = await supabase
        .from('profiles')
        .update({ role: 'admin' })
        .eq('id', userId);

      if (error) {
        console.error('Erro ao tornar admin:', error);
        toast({
          title: "Erro",
          description: "Erro ao tornar usuário admin",
          variant: "destructive"
        });
        return;
      }

      toast({
        title: "Sucesso",
        description: "Usuário promovido a admin"
      });
      
      await fetchUsers();
    } catch (error) {
      console.error('Erro ao tornar admin:', error);
    }
  }, [fetchUsers, toast]);

  const removeAdmin = useCallback(async (userId: string) => {
    try {
      console.log('Removendo admin do usuário:', userId);
      
      const { error } = await supabase
        .from('profiles')
        .update({ role: 'user' })
        .eq('id', userId);

      if (error) {
        console.error('Erro ao remover admin:', error);
        toast({
          title: "Erro",
          description: "Erro ao remover privilégios de admin",
          variant: "destructive"
        });
        return;
      }

      toast({
        title: "Sucesso",
        description: "Privilégios de admin removidos"
      });
      
      await fetchUsers();
    } catch (error) {
      console.error('Erro ao remover admin:', error);
    }
  }, [fetchUsers, toast]);

  const deleteUser = useCallback(async (userId: string) => {
    try {
      setDeletingUserId(userId);
      console.log('Excluindo usuário:', userId);
      
      // Usar a função do banco para deletar usuário e todos os dados
      const { error: deleteError } = await supabase
        .rpc('delete_user_and_data', { target_user_id: userId });

      if (deleteError) {
        console.error('Erro ao excluir usuário:', deleteError);
        toast({
          title: "Erro",
          description: "Erro ao excluir usuário: " + deleteError.message,
          variant: "destructive"
        });
        return;
      }

      toast({
        title: "Sucesso",
        description: "Usuário excluído com sucesso"
      });
      
      await fetchUsers();
    } catch (error) {
      console.error('Erro ao excluir usuário:', error);
      toast({
        title: "Erro",
        description: "Erro inesperado ao excluir usuário",
        variant: "destructive"
      });
    } finally {
      setDeletingUserId(null);
    }
  }, [fetchUsers, toast]);

  const openEditDialog = useCallback((user: UserWithEmail) => {
    setSelectedUser(user);
    editUserForm.setValue('email', user.email || '');
    editUserForm.setValue('role', user.role);
    setEditUserOpen(true);
  }, [editUserForm]);

  const getRoleBadge = useCallback((role: string, approved: boolean) => {
    const primaryColor = settings?.primary_color || '#00cc68';
    const secondaryColor = settings?.secondary_color || '#004a99';
    
    if (role === 'admin') {
      return <Badge style={{ backgroundColor: primaryColor, color: 'white' }}>Admin</Badge>;
    }
    if (role === 'pending' || !approved) {
      return <Badge variant="secondary">Pendente</Badge>;
    }
    return <Badge style={{ backgroundColor: secondaryColor, color: 'white' }}>Usuário</Badge>;
  }, [settings]);

  const getStats = useCallback(() => {
    const pending = users.filter(u => u.role === 'pending' || !u.approved).length;
    const approved = users.filter(u => u.approved && u.role !== 'pending').length;
    const admins = users.filter(u => u.role === 'admin').length;

    return { pending, approved, admins, total: users.length };
  }, [users]);

  const stats = getStats();
  const primaryColor = settings?.primary_color || '#00cc68';
  const secondaryColor = settings?.secondary_color || '#004a99';

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold mb-2" style={{ color: secondaryColor }}>
          Gerenciar Usuários
        </h2>
        <p className="text-gray-600">
          Visualize, aprove e gerencie usuários do sistema
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="flex items-center p-6">
            <Users className="h-8 w-8 mr-3" style={{ color: secondaryColor }} />
            <div>
              <p className="text-2xl font-bold">{stats.total}</p>
              <p className="text-sm text-gray-600">Total de Usuários</p>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="flex items-center p-6">
            <Clock className="h-8 w-8 text-yellow-600 mr-3" />
            <div>
              <p className="text-2xl font-bold">{stats.pending}</p>
              <p className="text-sm text-gray-600">Pendentes</p>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="flex items-center p-6">
            <Check className="h-8 w-8 mr-3" style={{ color: primaryColor }} />
            <div>
              <p className="text-2xl font-bold">{stats.approved}</p>
              <p className="text-sm text-gray-600">Aprovados</p>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="flex items-center p-6">
            <Shield className="h-8 w-8 mr-3" style={{ color: primaryColor }} />
            <div>
              <p className="text-2xl font-bold">{stats.admins}</p>
              <p className="text-sm text-gray-600">Administradores</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle style={{ color: secondaryColor }}>Lista de Usuários</CardTitle>
          <Dialog open={addUserOpen} onOpenChange={setAddUserOpen}>
            <DialogTrigger asChild>
              <Button style={{ backgroundColor: primaryColor, color: 'white' }} className="hover:opacity-90">
                <UserPlus className="h-4 w-4 mr-2" />
                Adicionar Usuário
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Adicionar Novo Usuário</DialogTitle>
              </DialogHeader>
              <Form {...addUserForm}>
                <form onSubmit={addUserForm.handleSubmit(addUser)} className="space-y-4">
                  <FormField
                    control={addUserForm.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Email</FormLabel>
                        <FormControl>
                          <Input {...field} type="email" required />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={addUserForm.control}
                    name="password"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Senha</FormLabel>
                        <FormControl>
                          <Input {...field} type="password" required />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={addUserForm.control}
                    name="role"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Tipo de Usuário</FormLabel>
                        <FormControl>
                          <select {...field} className="w-full p-2 border rounded">
                            <option value="user">Usuário</option>
                            <option value="admin">Administrador</option>
                          </select>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <div className="flex justify-end gap-2">
                    <Button type="button" variant="outline" onClick={() => setAddUserOpen(false)}>
                      Cancelar
                    </Button>
                    <Button type="submit" style={{ backgroundColor: primaryColor, color: 'white' }}>
                      Criar Usuário
                    </Button>
                  </div>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {users.map((user) => (
              <div key={user.id} className="flex items-center justify-between p-4 border rounded-lg">
                <div className="flex-1">
                  <div className="flex items-center gap-3">
                    <div>
                      <p className="font-medium">{user.email || 'Email não disponível'}</p>
                      <p className="text-sm text-gray-500">
                        ID: {user.id.substring(0, 8)}... | Criado em: {new Date(user.created_at).toLocaleDateString('pt-BR')}
                      </p>
                    </div>
                    {getRoleBadge(user.role, user.approved)}
                  </div>
                </div>
                
                <div className="flex items-center gap-2">
                  {(user.role === 'pending' || !user.approved) && (
                    <>
                      <Button
                        size="sm"
                        onClick={() => approveUser(user.id)}
                        style={{ backgroundColor: primaryColor, color: 'white' }}
                        className="hover:opacity-90"
                        disabled={deletingUserId === user.id}
                      >
                        <Check className="h-4 w-4 mr-1" />
                        Aprovar
                      </Button>
                      <Button
                        size="sm"
                        variant="destructive"
                        onClick={() => rejectUser(user.id)}
                        disabled={deletingUserId === user.id}
                      >
                        <X className="h-4 w-4 mr-1" />
                        {deletingUserId === user.id ? "Rejeitando..." : "Rejeitar"}
                      </Button>
                    </>
                  )}
                  
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => openEditDialog(user)}
                    disabled={deletingUserId === user.id}
                  >
                    <Edit className="h-4 w-4 mr-1" />
                    Editar
                  </Button>
                  
                  {user.approved && user.role === 'user' && (
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => makeAdmin(user.id)}
                      style={{ borderColor: primaryColor, color: primaryColor }}
                      disabled={deletingUserId === user.id}
                    >
                      <Shield className="h-4 w-4 mr-1" />
                      Tornar Admin
                    </Button>
                  )}
                  
                  {user.role === 'admin' && user.id !== currentUser?.id && (
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => removeAdmin(user.id)}
                      disabled={deletingUserId === user.id}
                    >
                      <ShieldOff className="h-4 w-4 mr-1" />
                      Remover Admin
                    </Button>
                  )}
                  
                  {user.id !== currentUser?.id && (
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button 
                          size="sm" 
                          variant="destructive"
                          disabled={deletingUserId === user.id}
                        >
                          <Trash2 className="h-4 w-4 mr-1" />
                          {deletingUserId === user.id ? "Excluindo..." : "Excluir"}
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>Confirmar Exclusão</AlertDialogTitle>
                          <AlertDialogDescription>
                            Tem certeza que deseja excluir este usuário? Esta ação não pode ser desfeita.
                            Todos os dados relacionados (leads, templates, configurações) também serão removidos.
                            <br />
                            <strong>Email:</strong> {user.email}
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>Cancelar</AlertDialogCancel>
                          <AlertDialogAction 
                            onClick={() => deleteUser(user.id)}
                            className="bg-red-600 hover:bg-red-700"
                          >
                            Confirmar Exclusão
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  )}
                </div>
              </div>
            ))}
            
            {users.length === 0 && (
              <p className="text-center text-gray-500 py-8">
                Nenhum usuário encontrado
              </p>
            )}
          </div>
        </CardContent>
      </Card>

      <Dialog open={editUserOpen} onOpenChange={setEditUserOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Editar Usuário</DialogTitle>
          </DialogHeader>
          <Form {...editUserForm}>
            <form onSubmit={editUserForm.handleSubmit(editUser)} className="space-y-4">
              <FormField
                control={editUserForm.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Email</FormLabel>
                    <FormControl>
                      <Input {...field} type="email" required />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={editUserForm.control}
                name="role"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Tipo de Usuário</FormLabel>
                    <FormControl>
                      <select {...field} className="w-full p-2 border rounded">
                        <option value="pending">Pendente</option>
                        <option value="user">Usuário</option>
                        <option value="admin">Administrador</option>
                      </select>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <div className="flex justify-end gap-2">
                <Button type="button" variant="outline" onClick={() => setEditUserOpen(false)}>
                  Cancelar
                </Button>
                <Button type="submit" style={{ backgroundColor: primaryColor, color: 'white' }}>
                  Salvar Alterações
                </Button>
              </div>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default UserManagementTab;
