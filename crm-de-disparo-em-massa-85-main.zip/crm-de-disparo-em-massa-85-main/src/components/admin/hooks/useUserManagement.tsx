
import { useState, useCallback } from 'react';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';

export const useUserManagement = () => {
  const [loading, setLoading] = useState(true);
  const [deletingUserId, setDeletingUserId] = useState<string | null>(null);
  const { toast } = useToast();
  const { user: currentUser } = useAuth();

  const fetchUsers = useCallback(async () => {
    try {
      setLoading(true);
      console.log('Buscando usuários com emails reais...');
      
      const { data: usersWithEmails, error } = await supabase
        .rpc('get_users_with_emails');

      if (error) {
        console.error('Erro ao buscar usuários:', error);
        toast({
          title: "Erro",
          description: "Erro ao carregar usuários",
          variant: "destructive"
        });
        return [];
      }

      console.log('Usuários carregados:', usersWithEmails);

      const formattedUsers = (usersWithEmails || []).map(user => {
        let role = 'pending';
        if (user.role === 'admin' || user.role === 'user' || user.role === 'pending') {
          role = user.role;
        }

        return {
          id: user.id,
          role,
          approved: user.approved || false,
          approved_at: user.approved_at || undefined,
          created_at: user.created_at,
          email: user.email || 'Email não disponível'
        };
      });

      console.log('Usuários formatados:', formattedUsers);
      return formattedUsers;
    } catch (error) {
      console.error('Erro ao buscar usuários:', error);
      toast({
        title: "Erro",
        description: "Erro ao carregar usuários",
        variant: "destructive"
      });
      return [];
    } finally {
      setLoading(false);
    }
  }, [toast]);

  const deleteUser = useCallback(async (userId: string) => {
    try {
      setDeletingUserId(userId);
      console.log('Excluindo usuário e todos os dados relacionados:', userId);
      
      // Usar a função do banco que já existe para deletar usuário e dados
      const { error: deleteError } = await supabase
        .rpc('delete_user_and_data', { target_user_id: userId });

      if (deleteError) {
        console.error('Erro ao excluir usuário:', deleteError);
        toast({
          title: "Erro",
          description: "Erro ao excluir usuário: " + deleteError.message,
          variant: "destructive"
        });
        return false;
      }

      console.log('Usuário e dados relacionados excluídos com sucesso');
      toast({
        title: "Sucesso",
        description: "Usuário excluído com sucesso"
      });
      
      return true;
    } catch (error) {
      console.error('Erro ao excluir usuário:', error);
      toast({
        title: "Erro",
        description: "Erro inesperado ao excluir usuário",
        variant: "destructive"
      });
      return false;
    } finally {
      setDeletingUserId(null);
    }
  }, [toast]);

  const approveUser = useCallback(async (userId: string) => {
    try {
      console.log('Aprovando usuário:', userId);
      
      // Aprovar no perfil
      const { error: profileError } = await supabase
        .from('profiles')
        .update({
          approved: true,
          role: 'user',
          approved_at: new Date().toISOString(),
          approved_by: currentUser?.id
        })
        .eq('id', userId);

      if (profileError) {
        console.error('Erro ao aprovar usuário:', profileError);
        toast({
          title: "Erro",
          description: "Erro ao aprovar usuário",
          variant: "destructive"
        });
        return false;
      }

      // Confirmar email automaticamente
      try {
        const { error: confirmError } = await supabase.auth.admin.updateUserById(userId, {
          email_confirm: true
        });

        if (confirmError) {
          console.warn('Aviso ao confirmar email:', confirmError);
          toast({
            title: "Sucesso",
            description: "Usuário aprovado (pode precisar confirmar email)",
          });
        } else {
          toast({
            title: "Sucesso",
            description: "Usuário aprovado e pode fazer login imediatamente"
          });
        }
      } catch (confirmErr) {
        console.warn('Não foi possível confirmar email automaticamente:', confirmErr);
        toast({
          title: "Sucesso",
          description: "Usuário aprovado",
        });
      }
      
      return true;
    } catch (error) {
      console.error('Erro ao aprovar usuário:', error);
      return false;
    }
  }, [currentUser?.id, toast]);

  const rejectUser = useCallback(async (userId: string) => {
    try {
      console.log('Rejeitando usuário:', userId);
      setDeletingUserId(userId);
      
      // Usar a função do banco para deletar usuário e dados
      const { error: deleteError } = await supabase
        .rpc('delete_user_and_data', { target_user_id: userId });

      if (deleteError) {
        console.error('Erro ao rejeitar usuário:', deleteError);
        toast({
          title: "Erro",
          description: "Erro ao rejeitar usuário: " + deleteError.message,
          variant: "destructive"
        });
        return false;
      }

      toast({
        title: "Sucesso",
        description: "Usuário rejeitado e removido"
      });
      
      return true;
    } catch (error) {
      console.error('Erro ao rejeitar usuário:', error);
      toast({
        title: "Erro",
        description: "Erro ao rejeitar usuário",
        variant: "destructive"
      });
      return false;
    } finally {
      setDeletingUserId(null);
    }
  }, [toast]);

  return {
    loading,
    deletingUserId,
    fetchUsers,
    deleteUser,
    approveUser,
    rejectUser
  };
};
