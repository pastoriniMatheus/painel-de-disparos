
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';

export const useSavedInstances = () => {
  const { user } = useAuth();

  const getSavedInstances = async () => {
    if (!user?.id) {
      throw new Error('Usuário não autenticado');
    }

    const { data: instanciasSalvas, error: instanciasError } = await supabase
      .from('instancias_whatsapp')
      .select('id, nome, status, apikey')
      .eq('user_id', user.id);

    if (instanciasError) {
      console.error('❌ Erro ao buscar instâncias salvas:', instanciasError);
      throw new Error('Erro ao buscar instâncias salvas');
    }

    if (!instanciasSalvas || instanciasSalvas.length === 0) {
      console.log('⚠️ Nenhuma instância salva encontrada');
      throw new Error('Nenhuma instância encontrada para verificar');
    }

    console.log('📋 Instâncias salvas encontradas:', instanciasSalvas.map(i => ({
      id: i.id,
      nome: i.nome,
      statusAtual: i.status
    })));

    return instanciasSalvas;
  };

  return { getSavedInstances };
};
