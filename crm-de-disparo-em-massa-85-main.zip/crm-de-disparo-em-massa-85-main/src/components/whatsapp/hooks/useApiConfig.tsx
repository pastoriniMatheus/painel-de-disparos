
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';

export const useApiConfig = () => {
  const { user } = useAuth();

  const getApiConfig = async () => {
    if (!user?.id) {
      throw new Error('Usuário não autenticado');
    }

    const { data: configuracoes, error: configError } = await supabase
      .from('configuracoes')
      .select('url_api_whatsapp, token_api_whatsapp')
      .eq('user_id', user.id)
      .single();

    if (configError || !configuracoes) {
      console.error('❌ Erro ao buscar configurações:', configError);
      throw new Error('Configurações da API WhatsApp não encontradas');
    }

    if (!configuracoes.url_api_whatsapp || !configuracoes.token_api_whatsapp) {
      throw new Error('URL da API ou Token não configurados');
    }

    console.log('⚙️ Configurações encontradas:', {
      url: configuracoes.url_api_whatsapp,
      hasToken: !!configuracoes.token_api_whatsapp
    });

    return configuracoes;
  };

  return { getApiConfig };
};
