
import { useState } from 'react';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/hooks/useAuth';
import { useApiConfig } from './useApiConfig';
import { useSavedInstances } from './useSavedInstances';
import { evolutionApiService } from '../services/evolutionApiService';
import { instanceDatabaseService } from '../services/instanceDatabaseService';
import { statusMapper } from '../utils/statusMapper';

export const useInstanceStatusCheck = () => {
  const [isChecking, setIsChecking] = useState(false);
  const { toast } = useToast();
  const { user } = useAuth();
  const { getApiConfig } = useApiConfig();
  const { getSavedInstances } = useSavedInstances();

  const verificarStatusInstancias = async () => {
    if (!user?.id) {
      toast({
        title: "Erro",
        description: "Usuário não autenticado",
        variant: "destructive"
      });
      return;
    }

    setIsChecking(true);
    console.log('🔍 Iniciando verificação de status das instâncias...');

    try {
      // Buscar configurações da API WhatsApp
      const configuracoes = await getApiConfig();

      // Buscar instâncias salvas no banco
      const instanciasSalvas = await getSavedInstances();

      // Fazer requisição para a API Evolution
      const instanciasAPI = await evolutionApiService.fetchInstances(
        configuracoes.url_api_whatsapp,
        configuracoes.token_api_whatsapp
      );

      let instanciasAtualizadas = 0;
      let instanciasComErro = 0;

      // Atualizar status das instâncias salvas
      for (const instanciaSalva of instanciasSalvas) {
        console.log(`\n🔍 Verificando instância salva: "${instanciaSalva.nome}" (ID: ${instanciaSalva.id})`);
        console.log(`   Status atual no banco: ${instanciaSalva.status}`);
        
        // Encontrar a instância correspondente na resposta da API
        const itemAPI = instanciasAPI.find((apiItem) => {
          const instance = apiItem.instance || apiItem;
          const instanceNameAPI = instance.instanceName || instance.name;
          const match = instanceNameAPI === instanciaSalva.nome;
          if (match) {
            console.log(`   ✅ Correspondência encontrada na API: ${instanceNameAPI}`);
          }
          return match;
        });

        let novoStatus = 'desconectado';
        let apikey = instanciaSalva.apikey; // Manter apikey existente por padrão

        if (itemAPI) {
          const instance = itemAPI.instance || itemAPI;
          // Buscar status em diferentes campos possíveis
          const statusOriginalAPI = instance.status || 
                                   instance.connectionStatus || 
                                   instance.state || 
                                   'unknown';
          const apikeyFromAPI = instance.apikey || instance.token;
          
          console.log(`   📊 Status recebido da API: "${statusOriginalAPI}"`);
          console.log(`   🔑 API Key da API: ${apikeyFromAPI ? 'presente' : 'ausente'}`);
          
          // Usar o statusMapper para garantir consistência
          novoStatus = statusMapper.mapApiStatusToDatabase(statusOriginalAPI);
          
          // Atualizar apikey se vier da API
          if (apikeyFromAPI) {
            apikey = apikeyFromAPI;
          }
          
          console.log(`   🟢 Status mapeado: ${novoStatus}`);
        } else {
          console.log(`   ❌ Instância "${instanciaSalva.nome}" não encontrada na API, mantendo como desconectada`);
        }

        // Verificar se realmente precisa atualizar
        const statusMudou = instanciaSalva.status !== novoStatus;
        const apikeyMudou = instanciaSalva.apikey !== apikey;
        
        if (statusMudou || apikeyMudou) {
          console.log(`   💾 Atualizando no banco: status "${instanciaSalva.status}" → "${novoStatus}", apikey: ${apikeyMudou ? 'atualizada' : 'mantida'}`);
          
          try {
            await instanceDatabaseService.updateInstanceStatus(
              instanciaSalva.id,
              user.id,
              novoStatus,
              apikey
            );
            
            console.log(`   ✅ Instância "${instanciaSalva.nome}" atualizada com sucesso para status: ${novoStatus}`);
            instanciasAtualizadas++;
          } catch (error) {
            console.error(`   ❌ Erro ao atualizar instância "${instanciaSalva.nome}":`, error);
            instanciasComErro++;
          }
        } else {
          console.log(`   ✅ Instância "${instanciaSalva.nome}" já está atualizada (status: ${novoStatus})`);
          instanciasAtualizadas++;
        }
      }

      console.log(`\n📊 Resumo da verificação:`);
      console.log(`   ✅ Instâncias processadas: ${instanciasAtualizadas}`);
      console.log(`   ❌ Instâncias com erro: ${instanciasComErro}`);

      const mensagem = instanciasComErro > 0 
        ? `${instanciasAtualizadas} instância(s) verificadas, ${instanciasComErro} com erro`
        : `${instanciasAtualizadas} instância(s) verificadas e atualizadas`;

      toast({
        title: "Verificação Concluída",
        description: mensagem,
        variant: instanciasComErro > 0 ? "destructive" : "default"
      });

    } catch (error: any) {
      console.error('❌ Erro durante verificação de status:', error);
      let errorMessage = 'Erro inesperado na verificação';
      
      if (error.name === 'AbortError') {
        errorMessage = 'Timeout: A API demorou muito para responder';
      } else if (error.message) {
        errorMessage = error.message;
      }

      toast({
        title: "Erro na Verificação",
        description: errorMessage,
        variant: "destructive"
      });
    } finally {
      setIsChecking(false);
      console.log('🏁 Verificação de status finalizada');
    }
  };

  return {
    verificarStatusInstancias,
    isChecking
  };
};
