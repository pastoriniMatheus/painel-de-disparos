
import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";

interface AdicionarInstanciaDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess?: () => void | Promise<void>;
}

const AdicionarInstanciaDialog = ({ open, onOpenChange, onSuccess }: AdicionarInstanciaDialogProps) => {
  const [nome, setNome] = useState("");
  const [tempoEspera, setTempoEspera] = useState(5);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { user } = useAuth();

  const addMutation = useMutation({
    mutationFn: async () => {
      if (!user) throw new Error("Usuário não autenticado");
      
      const { error } = await supabase
        .from('instancias_whatsapp')
        .insert({
          nome: nome.trim(),
          tempo_espera: tempoEspera,
          status: 'desconectado',
          quantidade_envios: 0,
          user_id: user.id
        });
      
      if (error) throw error;
    },
    onSuccess: async () => {
      queryClient.invalidateQueries({ queryKey: ['instancias_whatsapp'] });
      toast({
        title: "Sucesso",
        description: "Instância adicionada com sucesso!"
      });
      setNome("");
      setTempoEspera(5);
      onOpenChange(false);
      
      if (onSuccess) {
        await onSuccess();
      }
    },
    onError: (error) => {
      console.error('Erro ao adicionar instância:', error);
      toast({
        title: "Erro",
        description: "Erro ao adicionar instância",
        variant: "destructive"
      });
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!nome.trim()) {
      toast({
        title: "Erro",
        description: "Nome da instância é obrigatório",
        variant: "destructive"
      });
      return;
    }
    
    if (tempoEspera < 1) {
      toast({
        title: "Erro",
        description: "Tempo de espera deve ser pelo menos 1 segundo",
        variant: "destructive"
      });
      return;
    }
    
    addMutation.mutate();
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Adicionar Nova Instância</DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="nome">Nome da Instância</Label>
            <Input
              id="nome"
              value={nome}
              onChange={(e) => setNome(e.target.value)}
              placeholder="Ex: WhatsApp Principal"
              maxLength={100}
            />
          </div>

          <div>
            <Label htmlFor="tempo-espera">Tempo de Espera (segundos)</Label>
            <Input
              id="tempo-espera"
              type="number"
              min="1"
              max="300"
              value={tempoEspera}
              onChange={(e) => setTempoEspera(parseInt(e.target.value) || 5)}
            />
          </div>

          <div className="flex justify-end space-x-2">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancelar
            </Button>
            <Button type="submit" disabled={addMutation.isPending}>
              {addMutation.isPending ? "Adicionando..." : "Adicionar"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default AdicionarInstanciaDialog;
