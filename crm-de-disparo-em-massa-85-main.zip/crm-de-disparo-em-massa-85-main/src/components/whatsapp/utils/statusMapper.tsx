
export const statusMapper = {
  mapApiStatusToDatabase(apiStatus: string): string {
    // Mapear status baseado no valor exato da API para o formato do banco
    switch (apiStatus) {
      case 'open':
        return 'conectado';
      case 'close':
      case 'closed':
        return 'desconectado';
      case 'connecting':
        return 'conectando';
      default:
        console.log(`   ⚪ Status desconhecido "${apiStatus}", mapeado para: desconectado`);
        return 'desconectado';
    }
  }
};
