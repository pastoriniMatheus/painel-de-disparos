
export const evolutionApiService = {
  async fetchInstances(urlApi: string, tokenApi: string) {
    const baseUrl = urlApi.endsWith('/') 
      ? urlApi.slice(0, -1) 
      : urlApi;
    
    const fullUrl = `${baseUrl}/instance/fetchInstances`;

    console.log('🌐 Fazendo requisição para Evolution API:', fullUrl);

    const response = await fetch(fullUrl, {
      method: 'GET',
      headers: {
        'apikey': tokenApi
      },
      signal: AbortSignal.timeout(15000)
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error(`❌ Erro HTTP ${response.status}:`, errorText);
      throw new Error(`HTTP ${response.status}: ${response.statusText || errorText}`);
    }

    const data = await response.json();
    console.log('📡 Resposta completa da Evolution API:', JSON.stringify(data, null, 2));

    // Processar resposta - a API retorna um array de objetos com propriedade "instance"
    let instanciasAPI = [];
    if (Array.isArray(data)) {
      instanciasAPI = data;
      console.log(`📊 Total de instâncias na API: ${instanciasAPI.length}`);
      
      // Log das instâncias da API
      instanciasAPI.forEach((item, index) => {
        const instance = item.instance || item;
        console.log(`API Instância ${index + 1}:`, {
          instanceName: instance.instanceName,
          status: instance.status,
          apikey: instance.apikey ? 'presente' : 'ausente'
        });
      });
    } else {
      console.warn('⚠️ Formato de resposta não reconhecido da Evolution API:', data);
      instanciasAPI = [];
    }

    return instanciasAPI;
  }
};
