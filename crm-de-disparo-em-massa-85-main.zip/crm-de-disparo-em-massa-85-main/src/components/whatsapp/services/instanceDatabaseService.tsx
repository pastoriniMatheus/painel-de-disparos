
import { supabase } from '@/integrations/supabase/client';

export const instanceDatabaseService = {
  async updateInstanceStatus(instanceId: string, userId: string, novoStatus: string, apikey?: string) {
    const updateData: { [key: string]: any } = {
      status: novoStatus,
      updated_at: new Date().toISOString()
    };

    // Só adicionar apikey se existir
    if (apikey) {
      updateData.apikey = apikey;
    }

    console.log('   📝 Dados para atualização:', updateData);

    const { error: updateError } = await supabase
      .from('instancias_whatsapp')
      .update(updateData)
      .eq('id', instanceId)
      .eq('user_id', userId);

    if (updateError) {
      console.error(`   ❌ Erro ao atualizar instância:`, updateError);
      throw updateError;
    }

    return true;
  }
};
