import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Plus, RefreshCw } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import AdicionarInstanciaDialog from "./AdicionarInstanciaDialog";
import { useInstanceStatusCheck } from "./hooks/useInstanceStatusCheck";

interface Instancia {
  id: string;
  nome: string;
  status: string;
  quantidade_envios: number;
  tempo_espera: number;
  apikey?: string;
  created_at: string;
  updated_at: string;
}

const InstanciasTab = () => {
  const [instancias, setInstancias] = useState<Instancia[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const { toast } = useToast();
  const { user } = useAuth();
  const { verificarStatusInstancias, isChecking } = useInstanceStatusCheck();

  useEffect(() => {
    carregarInstancias();
  }, [user]);

  const carregarInstancias = async () => {
    if (!user?.id) return;

    console.log('📋 Carregando instâncias do banco de dados...');
    try {
      const { data, error } = await supabase
        .from('instancias_whatsapp')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (error) {
        console.error('❌ Erro ao carregar instâncias:', error);
        toast({
          title: "Erro",
          description: "Erro ao carregar instâncias",
          variant: "destructive"
        });
        return;
      }

      console.log('✅ Instâncias carregadas do banco:', data?.map(i => ({
        nome: i.nome,
        status: i.status,
        apikey: i.apikey ? 'presente' : 'ausente'
      })));
      
      setInstancias(data || []);
    } catch (error) {
      console.error('❌ Erro inesperado ao carregar instâncias:', error);
      toast({
        title: "Erro",
        description: "Erro inesperado ao carregar instâncias",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleVerificarStatus = async () => {
    console.log('🔄 Iniciando verificação de status via botão...');
    try {
      await verificarStatusInstancias();
      console.log('✅ Verificação concluída, recarregando instâncias...');
      
      // Recarregar instâncias imediatamente após a verificação
      await carregarInstancias();
      
    } catch (error) {
      console.error('❌ Erro durante verificação:', error);
    }
  };

  const deletarInstancia = async (id: string) => {
    try {
      const { error } = await supabase
        .from('instancias_whatsapp')
        .delete()
        .eq('id', id)
        .eq('user_id', user?.id);

      if (error) {
        console.error('Erro ao deletar instância:', error);
        toast({
          title: "Erro",
          description: "Erro ao deletar instância",
          variant: "destructive"
        });
        return;
      }

      toast({
        title: "Sucesso",
        description: "Instância deletada com sucesso"
      });

      carregarInstancias();
    } catch (error) {
      console.error('Erro ao deletar instância:', error);
      toast({
        title: "Erro",
        description: "Erro inesperado ao deletar instância",
        variant: "destructive"
      });
    }
  };

  const getStatusBadgeVariant = (status: string) => {
    switch (status) {
      case 'conectado':
        return 'default';
      case 'conectando':
        return 'secondary';
      default:
        return 'destructive';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'conectado':
        return 'text-green-600';
      case 'conectando':
        return 'text-yellow-600';
      default:
        return 'text-red-600';
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-lg">Carregando instâncias...</div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">Instâncias WhatsApp</h2>
          <p className="text-gray-600">
            Gerencie suas instâncias do WhatsApp
          </p>
        </div>
        <div className="flex gap-2">
          <Button 
            onClick={handleVerificarStatus}
            disabled={isChecking}
            variant="outline"
          >
            <RefreshCw className={`h-4 w-4 mr-2 ${isChecking ? 'animate-spin' : ''}`} />
            {isChecking ? "Verificando..." : "Verificar Status"}
          </Button>
          <Button onClick={() => setDialogOpen(true)}>
            <Plus className="h-4 w-4 mr-2" />
            Adicionar Instância
          </Button>
        </div>
      </div>

      {instancias.length === 0 ? (
        <Card>
          <CardContent className="p-8 text-center">
            <div className="text-gray-500 mb-4">
              <Plus className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p className="text-lg mb-2">Nenhuma instância encontrada</p>
              <p className="text-sm">
                Adicione sua primeira instância do WhatsApp para começar a enviar mensagens
              </p>
            </div>
            <Button onClick={() => setDialogOpen(true)}>
              <Plus className="h-4 w-4 mr-2" />
              Adicionar Primeira Instância
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {instancias.map((instancia) => (
            <Card key={instancia.id} className="relative">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg">{instancia.nome}</CardTitle>
                  <Badge variant={getStatusBadgeVariant(instancia.status)}>
                    {instancia.status}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="text-gray-500">Envios:</span>
                    <div className="font-medium">{instancia.quantidade_envios}</div>
                  </div>
                  <div>
                    <span className="text-gray-500">Tempo espera:</span>
                    <div className="font-medium">{instancia.tempo_espera}s</div>
                  </div>
                </div>
                
                <div className="text-sm">
                  <span className="text-gray-500">Status:</span>
                  <div className={`font-medium ${getStatusColor(instancia.status)}`}>
                    {instancia.status}
                  </div>
                </div>

                {instancia.apikey && (
                  <div className="text-sm">
                    <span className="text-gray-500">API Key:</span>
                    <div className="font-mono text-xs bg-gray-100 p-1 rounded truncate">
                      {instancia.apikey.substring(0, 20)}...
                    </div>
                  </div>
                )}

                <div className="text-xs text-gray-400">
                  Criado em: {new Date(instancia.created_at).toLocaleDateString('pt-BR')}
                </div>
                
                <div className="text-xs text-gray-400">
                  Atualizado: {new Date(instancia.updated_at).toLocaleString('pt-BR')}
                </div>

                <div className="flex gap-2 pt-2">
                  <Button
                    variant="destructive"
                    size="sm"
                    onClick={() => deletarInstancia(instancia.id)}
                    className="flex-1"
                  >
                    Deletar
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <AdicionarInstanciaDialog 
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        onSuccess={carregarInstancias}
      />
    </div>
  );
};

export default InstanciasTab;
