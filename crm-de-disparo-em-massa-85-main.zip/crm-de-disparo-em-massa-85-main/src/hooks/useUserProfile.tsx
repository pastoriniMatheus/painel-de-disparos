
import { useState, useEffect } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';

export interface UserProfile {
  id: string;
  role: 'admin' | 'user' | 'pending';
  approved: boolean;
  approved_at?: string;
  approved_by?: string;
  created_at: string;
  updated_at: string;
}

export function useUserProfile() {
  const { user } = useAuth();
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) {
      setProfile(null);
      setLoading(false);
      return;
    }

    const fetchProfile = async () => {
      try {
        // Use the new security function to safely get user profile
        const { data, error } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', user.id)
          .single();

        if (error) {
          console.error('Erro ao buscar perfil:', error);
          
          // If profile doesn't exist, user might be newly registered
          if (error.code === 'PGRST116') {
            console.log('Profile not found, user might be newly registered');
            setProfile(null);
          }
          return;
        }

        // Type casting with proper validation
        const profileData: UserProfile = {
          id: data.id,
          role: (['admin', 'user', 'pending'].includes(data.role) ? data.role : 'pending') as 'admin' | 'user' | 'pending',
          approved: Boolean(data.approved),
          approved_at: data.approved_at || undefined,
          approved_by: data.approved_by || undefined,
          created_at: data.created_at,
          updated_at: data.updated_at
        };

        setProfile(profileData);
      } catch (error) {
        console.error('Erro ao buscar perfil:', error);
        setProfile(null);
      } finally {
        setLoading(false);
      }
    };

    fetchProfile();

    // Create a unique channel name to avoid conflicts
    const channelName = `profile-changes-${user.id}-${Math.random().toString(36).substr(2, 9)}`;

    // Set up real-time subscription for profile changes
    const subscription = supabase
      .channel(channelName)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'profiles',
          filter: `id=eq.${user.id}`
        },
        (payload) => {
          console.log('Profile updated:', payload);
          fetchProfile();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(subscription);
    };
  }, [user]);

  const isAdmin = profile?.role === 'admin' && profile?.approved === true;
  const isApproved = profile?.approved === true;

  return {
    profile,
    loading,
    isAdmin,
    isApproved
  };
}
