
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';

interface AppearanceSettings {
  id: string;
  favicon_url: string | null;
  logo_url: string | null;
  primary_color: string | null;
  secondary_color: string | null;
}

export function useAppearanceSettings() {
  const [settings, setSettings] = useState<AppearanceSettings | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchSettings();
    
    // Create a unique channel name to avoid conflicts
    const channelName = `appearance-changes-${Math.random().toString(36).substr(2, 9)}`;
    
    // Escutar mudanças em tempo real
    const subscription = supabase
      .channel(channelName)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'appearance_settings'
        },
        () => {
          fetchSettings();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(subscription);
    };
  }, []);

  const fetchSettings = async () => {
    try {
      const { data, error } = await supabase
        .from('appearance_settings')
        .select('*')
        .single();

      if (error && error.code !== 'PGRST116') {
        console.error('Erro ao buscar configurações:', error);
        return;
      }

      setSettings(data);
      
      // Aplicar favicon se existir
      if (data?.favicon_url) {
        const link = document.querySelector("link[rel*='icon']") || document.createElement('link');
        link.setAttribute('rel', 'icon');
        link.setAttribute('href', data.favicon_url);
        link.setAttribute('type', 'image/png');
        document.head.appendChild(link);
      }

      // Aplicar cores CSS customizadas
      if (data?.primary_color || data?.secondary_color) {
        const root = document.documentElement;
        if (data.primary_color) {
          root.style.setProperty('--color-primary', data.primary_color);
        }
        if (data.secondary_color) {
          root.style.setProperty('--color-secondary', data.secondary_color);
        }
      }
    } catch (error) {
      console.error('Erro ao buscar configurações:', error);
    } finally {
      setLoading(false);
    }
  };

  return { settings, loading };
}
