export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  public: {
    Tables: {
      appearance_settings: {
        Row: {
          created_at: string
          favicon_url: string | null
          id: string
          logo_url: string | null
          primary_color: string | null
          secondary_color: string | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          favicon_url?: string | null
          id?: string
          logo_url?: string | null
          primary_color?: string | null
          secondary_color?: string | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          favicon_url?: string | null
          id?: string
          logo_url?: string | null
          primary_color?: string | null
          secondary_color?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      configuracoes: {
        Row: {
          created_at: string
          id: string
          tipo_api_whatsapp: string | null
          token_api_whatsapp: string | null
          updated_at: string
          url_api_whatsapp: string | null
          user_id: string | null
          webhook_envio: string | null
          webhook_verificacao: string | null
          webhook_verificacao_instancia: string | null
          webhook_verificacao_instancia_habilitado: boolean | null
          webhook_verificacao_instancia_minutos: number | null
        }
        Insert: {
          created_at?: string
          id?: string
          tipo_api_whatsapp?: string | null
          token_api_whatsapp?: string | null
          updated_at?: string
          url_api_whatsapp?: string | null
          user_id?: string | null
          webhook_envio?: string | null
          webhook_verificacao?: string | null
          webhook_verificacao_instancia?: string | null
          webhook_verificacao_instancia_habilitado?: boolean | null
          webhook_verificacao_instancia_minutos?: number | null
        }
        Update: {
          created_at?: string
          id?: string
          tipo_api_whatsapp?: string | null
          token_api_whatsapp?: string | null
          updated_at?: string
          url_api_whatsapp?: string | null
          user_id?: string | null
          webhook_envio?: string | null
          webhook_verificacao?: string | null
          webhook_verificacao_instancia?: string | null
          webhook_verificacao_instancia_habilitado?: boolean | null
          webhook_verificacao_instancia_minutos?: number | null
        }
        Relationships: []
      }
      disparo_leads: {
        Row: {
          created_at: string
          data_processamento: string | null
          disparo_id: string
          erro_detalhes: string | null
          id: string
          lead_id: string
          status: string
        }
        Insert: {
          created_at?: string
          data_processamento?: string | null
          disparo_id: string
          erro_detalhes?: string | null
          id?: string
          lead_id: string
          status?: string
        }
        Update: {
          created_at?: string
          data_processamento?: string | null
          disparo_id?: string
          erro_detalhes?: string | null
          id?: string
          lead_id?: string
          status?: string
        }
        Relationships: [
          {
            foreignKeyName: "disparo_leads_disparo_id_fkey"
            columns: ["disparo_id"]
            isOneToOne: false
            referencedRelation: "disparos_massa"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "disparo_leads_lead_id_fkey"
            columns: ["lead_id"]
            isOneToOne: false
            referencedRelation: "leads"
            referencedColumns: ["id"]
          },
        ]
      }
      disparos_agendados: {
        Row: {
          conteudo: string
          created_at: string
          data_agendada: string
          id: string
          imagem_url: string | null
          leads_selecionados: Json
          status: string | null
          user_id: string | null
        }
        Insert: {
          conteudo: string
          created_at?: string
          data_agendada: string
          id?: string
          imagem_url?: string | null
          leads_selecionados: Json
          status?: string | null
          user_id?: string | null
        }
        Update: {
          conteudo?: string
          created_at?: string
          data_agendada?: string
          id?: string
          imagem_url?: string | null
          leads_selecionados?: Json
          status?: string | null
          user_id?: string | null
        }
        Relationships: []
      }
      disparos_massa: {
        Row: {
          conteudo: string
          created_at: string
          data_conclusao: string | null
          data_inicio: string
          id: string
          imagem_url: string | null
          leads_enviados: number
          leads_erro: number
          status: string
          total_leads: number
          updated_at: string
          user_id: string
        }
        Insert: {
          conteudo: string
          created_at?: string
          data_conclusao?: string | null
          data_inicio?: string
          id?: string
          imagem_url?: string | null
          leads_enviados?: number
          leads_erro?: number
          status?: string
          total_leads?: number
          updated_at?: string
          user_id: string
        }
        Update: {
          conteudo?: string
          created_at?: string
          data_conclusao?: string | null
          data_inicio?: string
          id?: string
          imagem_url?: string | null
          leads_enviados?: number
          leads_erro?: number
          status?: string
          total_leads?: number
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      historico_disparos: {
        Row: {
          conteudo: string
          data_envio: string
          id: string
          imagem_url: string | null
          lead_id: string | null
          nome_lead: string
          status_envio: string | null
          telefone_lead: string
          user_id: string | null
        }
        Insert: {
          conteudo: string
          data_envio?: string
          id?: string
          imagem_url?: string | null
          lead_id?: string | null
          nome_lead: string
          status_envio?: string | null
          telefone_lead: string
          user_id?: string | null
        }
        Update: {
          conteudo?: string
          data_envio?: string
          id?: string
          imagem_url?: string | null
          lead_id?: string | null
          nome_lead?: string
          status_envio?: string | null
          telefone_lead?: string
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "historico_disparos_lead_id_fkey"
            columns: ["lead_id"]
            isOneToOne: false
            referencedRelation: "leads"
            referencedColumns: ["id"]
          },
        ]
      }
      instancias_whatsapp: {
        Row: {
          apikey: string | null
          created_at: string
          id: string
          nome: string
          quantidade_envios: number
          status: string
          tempo_espera: number
          updated_at: string
          user_id: string | null
        }
        Insert: {
          apikey?: string | null
          created_at?: string
          id?: string
          nome: string
          quantidade_envios?: number
          status?: string
          tempo_espera?: number
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          apikey?: string | null
          created_at?: string
          id?: string
          nome?: string
          quantidade_envios?: number
          status?: string
          tempo_espera?: number
          updated_at?: string
          user_id?: string | null
        }
        Relationships: []
      }
      leads: {
        Row: {
          campanha: string | null
          categoria: string
          cidade: string
          created_at: string
          data_hora: string
          delete_reason: string | null
          deleted_at: string | null
          enviado: boolean | null
          erro: string | null
          estado: string
          id: string
          nome: string
          telefone: string
          updated_at: string
          url: string | null
          user_id: string | null
          verificado: boolean | null
        }
        Insert: {
          campanha?: string | null
          categoria: string
          cidade: string
          created_at?: string
          data_hora: string
          delete_reason?: string | null
          deleted_at?: string | null
          enviado?: boolean | null
          erro?: string | null
          estado: string
          id?: string
          nome: string
          telefone: string
          updated_at?: string
          url?: string | null
          user_id?: string | null
          verificado?: boolean | null
        }
        Update: {
          campanha?: string | null
          categoria?: string
          cidade?: string
          created_at?: string
          data_hora?: string
          delete_reason?: string | null
          deleted_at?: string | null
          enviado?: boolean | null
          erro?: string | null
          estado?: string
          id?: string
          nome?: string
          telefone?: string
          updated_at?: string
          url?: string | null
          user_id?: string | null
          verificado?: boolean | null
        }
        Relationships: []
      }
      profiles: {
        Row: {
          approved: boolean | null
          approved_at: string | null
          approved_by: string | null
          created_at: string
          email: string | null
          id: string
          role: string | null
          updated_at: string
        }
        Insert: {
          approved?: boolean | null
          approved_at?: string | null
          approved_by?: string | null
          created_at?: string
          email?: string | null
          id: string
          role?: string | null
          updated_at?: string
        }
        Update: {
          approved?: boolean | null
          approved_at?: string | null
          approved_by?: string | null
          created_at?: string
          email?: string | null
          id?: string
          role?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      templates_mensagens: {
        Row: {
          conteudo: string
          created_at: string
          id: string
          imagem_url: string | null
          nome: string
          updated_at: string
          user_id: string | null
        }
        Insert: {
          conteudo: string
          created_at?: string
          id?: string
          imagem_url?: string | null
          nome: string
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          conteudo?: string
          created_at?: string
          id?: string
          imagem_url?: string | null
          nome?: string
          updated_at?: string
          user_id?: string | null
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      confirm_user_email: {
        Args: { target_user_id: string }
        Returns: boolean
      }
      create_confirmed_user: {
        Args: { user_email: string; user_password: string; user_role: string }
        Returns: string
      }
      delete_user_and_data: {
        Args: { target_user_id: string }
        Returns: boolean
      }
      get_current_user_role: {
        Args: Record<PropertyKey, never>
        Returns: string
      }
      get_users_with_emails: {
        Args: Record<PropertyKey, never>
        Returns: {
          id: string
          email: string
          role: string
          approved: boolean
          approved_at: string
          created_at: string
        }[]
      }
      is_approved_admin: {
        Args: Record<PropertyKey, never>
        Returns: boolean
      }
      process_disparo_completion: {
        Args: { disparo_uuid: string }
        Returns: Json
      }
      process_webhook_confirmation: {
        Args: { lead_uuid: string; new_status: string; error_details?: string }
        Returns: Json
      }
      update_disparo_counters: {
        Args: { disparo_uuid: string }
        Returns: undefined
      }
      update_user_profile: {
        Args: { user_id: string; new_email?: string; new_role?: string }
        Returns: boolean
      }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DefaultSchema = Database[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof Database },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof (Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        Database[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends { schema: keyof Database }
  ? (Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      Database[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof Database },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends { schema: keyof Database }
  ? Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof Database },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends { schema: keyof Database }
  ? Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof Database },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends { schema: keyof Database }
  ? Database[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof Database },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends { schema: keyof Database }
  ? Database[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
