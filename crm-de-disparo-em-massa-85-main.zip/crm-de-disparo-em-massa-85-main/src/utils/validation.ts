
// Input validation and sanitization utilities
export const phoneRegex = /^(\+55\s?)?(\(?[0-9]{2}\)?\s?)?[0-9]{1}\s?[0-9]{4,5}-?[0-9]{4}$/;
export const urlRegex = /^https?:\/\/(www\.)?[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_\+.~#?&//=]*)$/;

export const sanitizeString = (input: string): string => {
  return input
    .trim()
    .replace(/[<>]/g, '') // Remove potential HTML tags
    .replace(/['"]/g, '') // Remove quotes to prevent injection
    .substring(0, 500); // Limit length
};

export const sanitizePhone = (phone: string): string => {
  // Remove all non-numeric characters except + and spaces
  return phone.replace(/[^\d\s\+\(\)\-]/g, '').trim();
};

export const sanitizeUrl = (url: string): string => {
  const trimmed = url.trim();
  if (!trimmed) return '';
  
  // Ensure URL starts with http:// or https://
  if (!trimmed.startsWith('http://') && !trimmed.startsWith('https://')) {
    return `https://${trimmed}`;
  }
  return trimmed;
};

export const validatePhone = (phone: string): boolean => {
  const sanitized = sanitizePhone(phone);
  // More flexible phone validation to accept formats like "(85) 9 9745-7029"
  const flexiblePhoneRegex = /^(\+55\s?)?(\(?[0-9]{2}\)?\s?)?[0-9]{1}\s?[0-9]{4,5}-?[0-9]{4}$/;
  return flexiblePhoneRegex.test(sanitized);
};

export const validateUrl = (url: string): boolean => {
  if (!url.trim()) return true; // URL is optional
  const sanitized = sanitizeUrl(url);
  return urlRegex.test(sanitized);
};

export const validateEmail = (email: string): boolean => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email.trim());
};

// Webhook URL validation - only allow specific domains for security
const allowedWebhookDomains = [
  'api.example.com',
  'webhook.site',
  'hooks.zapier.com',
  'localhost',
  '127.0.0.1',
  // Add your allowed domains here
];

export const validateWebhookUrl = (url: string): { isValid: boolean; error?: string } => {
  if (!url.trim()) {
    return { isValid: false, error: 'URL é obrigatória' };
  }

  try {
    const urlObj = new URL(sanitizeUrl(url));
    
    if (!['http:', 'https:'].includes(urlObj.protocol)) {
      return { isValid: false, error: 'URL deve usar protocolo HTTP ou HTTPS' };
    }

    // In production, you might want to enable domain validation
    // const isAllowedDomain = allowedWebhookDomains.some(domain => 
    //   urlObj.hostname === domain || urlObj.hostname.endsWith(`.${domain}`)
    // );
    
    // if (!isAllowedDomain && !urlObj.hostname.includes('localhost')) {
    //   return { isValid: false, error: 'Domínio não está na lista de permitidos' };
    // }

    return { isValid: true };
  } catch {
    return { isValid: false, error: 'URL inválida' };
  }
};

// CSV sanitization
export const sanitizeCsvData = (csvText: string): string => {
  return csvText
    .split('\n')
    .map(line => 
      line.split(',')
        .map(cell => sanitizeString(cell))
        .join(',')
    )
    .join('\n');
};
