
// Secure error handling utilities
export interface AppError {
  message: string;
  code?: string;
  details?: any;
}

export const createSafeError = (error: any, fallbackMessage: string = "Ocorreu um erro inesperado"): AppError => {
  // Log the full error for debugging (in production, this should go to a secure logging service)
  console.error('[Error]', error);

  // Return a sanitized error message
  if (error?.message) {
    // Don't expose database or system errors to users
    if (error.message.includes('duplicate key') || error.message.includes('violates')) {
      return { message: "Este registro já existe ou há um conflito de dados" };
    }
    
    if (error.message.includes('permission') || error.message.includes('policy')) {
      return { message: "Você não tem permissão para realizar esta ação" };
    }
    
    if (error.message.includes('network') || error.message.includes('fetch')) {
      return { message: "Erro de conexão. Tente novamente." };
    }
    
    // For known application errors, return the message
    if (error.message.startsWith('Campos obrigatórios') || 
        error.message.startsWith('URL') || 
        error.message.startsWith('Telefone')) {
      return { message: error.message };
    }
  }

  return { message: fallbackMessage };
};

export const logSecurityEvent = (event: string, details: any) => {
  const securityLog = {
    timestamp: new Date().toISOString(),
    event,
    details: typeof details === 'object' ? JSON.stringify(details) : details,
    userAgent: navigator.userAgent,
    url: window.location.href
  };
  
  console.warn('[Security Event]', securityLog);
  // In production, send this to a security monitoring service
};
