
/**
 * Security utility functions for input sanitization and validation
 */

/**
 * Sanitize text input by removing potentially dangerous characters
 */
export function sanitizeText(input: string): string {
  if (!input || typeof input !== 'string') return '';
  
  return input
    .trim()
    .replace(/[<>]/g, '') // Remove basic HTML characters
    .replace(/javascript:/gi, '') // Remove javascript: protocol
    .replace(/on\w+=/gi, '') // Remove event handlers
    .slice(0, 1000); // Limit length
}

/**
 * Sanitize phone number to only allow digits, spaces, hyphens, and parentheses
 */
export function sanitizePhoneNumber(phone: string): string {
  if (!phone || typeof phone !== 'string') return '';
  
  return phone
    .replace(/[^\d\s\-\(\)\+]/g, '')
    .trim()
    .slice(0, 20);
}

/**
 * Sanitize email input
 */
export function sanitizeEmail(email: string): string {
  if (!email || typeof email !== 'string') return '';
  
  return email
    .trim()
    .toLowerCase()
    .slice(0, 254); // RFC 5321 limit
}

/**
 * Validate and sanitize URL
 */
export function sanitizeUrl(url: string): string {
  if (!url || typeof url !== 'string') return '';
  
  const trimmed = url.trim();
  
  // Only allow https URLs for webhooks
  if (!trimmed.startsWith('https://')) {
    throw new Error('URL deve usar HTTPS');
  }
  
  try {
    const urlObj = new URL(trimmed);
    // Only allow specific protocols
    if (!['https:'].includes(urlObj.protocol)) {
      throw new Error('Protocolo não permitido');
    }
    return urlObj.toString();
  } catch {
    throw new Error('URL inválida');
  }
}

/**
 * Sanitize CSV content to prevent injection attacks
 */
export function sanitizeCsvContent(content: string): string {
  if (!content || typeof content !== 'string') return '';
  
  return content
    .split('\n')
    .map(line => {
      // Remove cells that start with potentially dangerous characters
      return line
        .split(',')
        .map(cell => {
          const trimmed = cell.trim();
          // Remove leading dangerous characters
          if (trimmed.startsWith('=') || trimmed.startsWith('+') || 
              trimmed.startsWith('-') || trimmed.startsWith('@')) {
            return `'${trimmed}`;
          }
          return sanitizeText(trimmed);
        })
        .join(',');
    })
    .join('\n')
    .slice(0, 100000); // Limit total size
}

/**
 * Rate limiting helper for client-side operations
 */
export class SimpleRateLimit {
  private requests: number[] = [];
  
  constructor(private maxRequests: number, private windowMs: number) {}
  
  canMakeRequest(): boolean {
    const now = Date.now();
    // Remove old requests outside the window
    this.requests = this.requests.filter(time => now - time < this.windowMs);
    
    if (this.requests.length >= this.maxRequests) {
      return false;
    }
    
    this.requests.push(now);
    return true;
  }
  
  getRemainingRequests(): number {
    return Math.max(0, this.maxRequests - this.requests.length);
  }
}
