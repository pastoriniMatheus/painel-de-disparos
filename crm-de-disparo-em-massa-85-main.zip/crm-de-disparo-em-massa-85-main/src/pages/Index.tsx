import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Database, MessageSquare, Upload, Settings, History, FileText, BarChart, Smartphone, Users, Calendar } from "lucide-react";
import Header from "@/components/layout/Header";
import { useUserProfile } from "@/hooks/useUserProfile";
import LeadsTab from "@/components/leads/LeadsTab";
import ImportTab from "@/components/leads/ImportTab";
import DisparoTab from "@/components/leads/DisparoTab";
import AjustesTab from "@/components/leads/AjustesTab";
import HistoricoTab from "@/components/leads/HistoricoTab";
import TemplatesTab from "@/components/leads/TemplatesTab";
import DashboardTab from "@/components/leads/DashboardTab";
import InstanciasTab from "@/components/whatsapp/InstanciasTab";
import UserManagementTab from "@/components/admin/UserManagementTab";
import AgendamentoTab from "@/components/leads/AgendamentoTab";

const Index = () => {
  const [activeTab, setActiveTab] = useState("dashboard");
  const { isAdmin } = useUserProfile();

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="p-4">
        <div className="max-w-7xl mx-auto">
          <div className="mb-6">
            <p className="text-gray-600">
              Gerencie seus leads e realize disparos via WhatsApp
            </p>
          </div>

          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className={`grid w-full ${isAdmin ? 'grid-cols-5 lg:grid-cols-10' : 'grid-cols-5 lg:grid-cols-9'} mb-6`}>
              <TabsTrigger value="dashboard" className="flex items-center gap-2">
                <BarChart className="h-4 w-4" />
                <span className="hidden sm:inline">Dashboard</span>
              </TabsTrigger>
              <TabsTrigger value="leads" className="flex items-center gap-2">
                <Database className="h-4 w-4" />
                <span className="hidden sm:inline">Leads</span>
              </TabsTrigger>
              <TabsTrigger value="import" className="flex items-center gap-2">
                <Upload className="h-4 w-4" />
                <span className="hidden sm:inline">Importar</span>
              </TabsTrigger>
              <TabsTrigger value="disparo" className="flex items-center gap-2">
                <MessageSquare className="h-4 w-4" />
                <span className="hidden sm:inline">Disparos</span>
              </TabsTrigger>
              <TabsTrigger value="instancias" className="flex items-center gap-2">
                <Smartphone className="h-4 w-4" />
                <span className="hidden sm:inline">Instâncias</span>
              </TabsTrigger>
              <TabsTrigger value="templates" className="flex items-center gap-2">
                <FileText className="h-4 w-4" />
                <span className="hidden sm:inline">Templates</span>
              </TabsTrigger>
              <TabsTrigger value="historico" className="flex items-center gap-2">
                <History className="h-4 w-4" />
                <span className="hidden sm:inline">Histórico</span>
              </TabsTrigger>
              <TabsTrigger value="ajustes" className="flex items-center gap-2">
                <Settings className="h-4 w-4" />
                <span className="hidden sm:inline">Ajustes</span>
              </TabsTrigger>
              <TabsTrigger value="agendamentos" className="flex items-center gap-2">
                <Calendar className="h-4 w-4" />
                <span className="hidden sm:inline">Agenda</span>
              </TabsTrigger>
              {isAdmin && (
                <TabsTrigger value="usuarios" className="flex items-center gap-2">
                  <Users className="h-4 w-4" />
                  <span className="hidden sm:inline">Usuários</span>
                </TabsTrigger>
              )}
            </TabsList>

            <TabsContent value="dashboard">
              <DashboardTab />
            </TabsContent>

            <TabsContent value="leads">
              <LeadsTab />
            </TabsContent>

            <TabsContent value="import">
              <ImportTab />
            </TabsContent>

            <TabsContent value="disparo">
              <DisparoTab />
            </TabsContent>

            <TabsContent value="instancias">
              <InstanciasTab />
            </TabsContent>

            <TabsContent value="templates">
              <TemplatesTab />
            </TabsContent>

            <TabsContent value="historico">
              <HistoricoTab />
            </TabsContent>

            <TabsContent value="ajustes">
              <AjustesTab />
            </TabsContent>

            <TabsContent value="agendamentos">
              <AgendamentoTab />
            </TabsContent>

            {isAdmin && (
              <TabsContent value="usuarios">
                <UserManagementTab />
              </TabsContent>
            )}
          </Tabs>
        </div>
      </div>
    </div>
  );
};

export default Index;
